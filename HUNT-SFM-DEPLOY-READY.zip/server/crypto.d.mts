import type { IncomingMessage, ServerResponse } from 'node:http';

export interface CryptoApi {
  /** answers /api/live/* requests; resolves true when the request was handled */
  handle(req: IncomingMessage, res: ServerResponse): Promise<boolean>;
  status(): Record<string, unknown>;
  start(): Promise<void> | null;
  close(): void;
  refreshTickers(): Promise<string>;
  refreshUniverse(): Promise<unknown>;
  getCandles(symbol: string, interval: string, since?: number): Promise<unknown>;
  universe(): { coins: unknown[]; rankSource: string; updatedAt: number };
  tickers(): unknown[];
}

export function createCryptoApi(
  env?: Record<string, string | undefined>,
  opts?: { fetch?: typeof fetch; WebSocket?: unknown; log?: (m: string) => void; cacheFile?: string | null },
): CryptoApi;
