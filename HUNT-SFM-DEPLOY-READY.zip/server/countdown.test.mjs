// Run: node --experimental-strip-types --test server/countdown.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import { secondsToClose, fmtCountdown } from '../src/lib/countdown.ts';

const MIN = 60_000;
const open = Date.UTC(2026, 10, 21, 12, 0, 0);

test('forming candle: seconds left, rounded up so it ends on 00:01 -> flip', () => {
  assert.equal(secondsToClose(open, MIN, open + 40_000), 20);
  assert.equal(secondsToClose(open, MIN, open + 59_001), 1);
  assert.equal(secondsToClose(open, MIN, open), 60);
  assert.equal(secondsToClose(open, 4 * 60 * MIN, open + 3_600_000), 3 * 3600);
});

test('clock ahead of the candle (skew) never shows more than one interval', () => {
  assert.equal(secondsToClose(open, MIN, open - 30_000), 60);
});

test('after the close the timer keeps counting on the same grid while the next candle is on its way', () => {
  assert.equal(secondsToClose(open, MIN, open + MIN + 5_000), 55); // next close = open + 2 min
  assert.equal(secondsToClose(open, 15 * MIN, open + 15 * MIN + 20_000), 15 * 60 - 20);
});

test('market closed / feed down (candle ended long ago) -> no timer', () => {
  assert.equal(secondsToClose(open, MIN, open + 5 * MIN), null);
  assert.equal(secondsToClose(open, 15 * MIN, open + 15 * MIN + 61_000), null);
  assert.equal(secondsToClose(open, 4 * 60 * MIN, open + 2 * 24 * 3_600_000), null); // weekend
});

test('format: MM:SS under an hour, H:MM:SS above', () => {
  assert.equal(fmtCountdown(0), '00:00');
  assert.equal(fmtCountdown(5), '00:05');
  assert.equal(fmtCountdown(59), '00:59');
  assert.equal(fmtCountdown(600), '10:00');
  assert.equal(fmtCountdown(3599), '59:59');
  assert.equal(fmtCountdown(3725), '1:02:05');
  assert.equal(fmtCountdown(4 * 3600), '4:00:00');
});
