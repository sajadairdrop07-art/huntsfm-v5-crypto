// Live crypto market-data hub (server side). The browser only talks to /api/live/*.
// Free, no API key. Top-N coins by market cap, real-time via exchange WebSocket, automatic failover between exchanges.
//
//   GET /api/live/universe                       the coins (rank, name, market cap) — refreshed every 10 min
//   GET /api/live/tickers                        24h ticker of every coin in the universe
//   GET /api/live/candles?symbol=BTCUSDT&interval=15m[&since=<ms>]
//   GET /api/live/stream/tickers                 Server-Sent Events: all tickers, ~1 update per second
//   GET /api/live/stream/candles?symbol=&interval=   Server-Sent Events: the forming candle of one chart in real time
//   GET /api/live/status
//
// Data path
//   ranking   CoinGecko -> CoinPaprika -> (24h quote volume from the exchanges)
//   prices    Binance WebSocket (all tickers + kline of the open chart)  ->  REST polling of Binance / Bybit / OKX / Gate.io
//   candles   REST: Binance -> Bybit -> OKX -> Gate.io (first one that has the pair and answers)
// Base URLs can be overridden with env vars (mirror / reverse proxy) — see README.

import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';

export const INTERVAL_MS = { '1m': 60_000, '5m': 300_000, '15m': 900_000, '1h': 3_600_000, '4h': 14_400_000, '1d': 86_400_000 };
const FULL = 1000; // candles in a full history window
const BUCKETS = [8, 24, 80, 240, 800]; // quantised "recent" windows => better cache hits
const UA = 'Mozilla/5.0 (compatible; huntsfm/2.0)';

/** stablecoins and 1:1 wrappers add nothing to a chart list; extend with EXCLUDE_SYMBOLS=AAA,BBB */
export const STABLE = new Set(
  'USDT USDC DAI FDUSD TUSD USDE USDS PYUSD USDD USD1 BUSD USDP GUSD FRAX LUSD EURC EURT USDG RLUSD BFUSD USDY SUSDE SUSDS USDX CRVUSD GHO USDB USDT0 USDF AUSD USDTB'.split(' '),
);
export const WRAPPED = new Set('WBTC WETH STETH WSTETH WEETH WBETH CBBTC CBETH RETH WBNB SOLVBTC LBTC EZETH RSETH METH SWETH BNSOL JITOSOL'.split(' '));

function httpError(status, message) {
  const e = new Error(message);
  e.status = status;
  return e;
}

const num = (v, d) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);
const fin = Number.isFinite;
const baseOf = (symbol) => symbol.slice(0, -4); // BTCUSDT -> BTC

/* ------------------------------------------------------------------ parsers (pure, unit-tested) */

const tk = (price, open, high, low, volume, changePct) => ({
  price,
  changePct: changePct ?? (open > 0 ? ((price - open) / open) * 100 : 0),
  high,
  low,
  volume, // 24h quote (USDT) volume
});

const LEVERAGED = /(UP|DOWN|BULL|BEAR)USDT$/;

export function parseBinanceTickers(rows) {
  const out = new Map();
  if (!Array.isArray(rows)) throw httpError(502, 'binance: unexpected tickers payload');
  for (const r of rows) {
    const s = r?.symbol;
    if (typeof s !== 'string' || !s.endsWith('USDT') || s.length < 7 || LEVERAGED.test(s)) continue;
    const p = Number(r.lastPrice);
    if (!(p > 0)) continue;
    out.set(s, tk(p, Number(r.openPrice), Number(r.highPrice), Number(r.lowPrice), Number(r.quoteVolume) || 0, fin(Number(r.priceChangePercent)) ? Number(r.priceChangePercent) : undefined));
  }
  return out;
}

export function parseBinanceKlines(rows) {
  if (!Array.isArray(rows)) throw httpError(502, 'binance: unexpected klines payload');
  const out = [];
  for (const r of rows) {
    const [t, o, h, l, c] = [Number(r[0]), Number(r[1]), Number(r[2]), Number(r[3]), Number(r[4])];
    if (![t, o, h, l, c].every(fin)) continue;
    out.push({ t, o, h, l, c, v: Number(r[7]) || 0 }); // index 7 = quote asset volume
  }
  return out.sort((a, b) => a.t - b.t);
}

export function parseBybitTickers(json) {
  if (json?.retCode !== 0 || !Array.isArray(json?.result?.list)) throw httpError(502, `bybit: ${json?.retMsg ?? 'unexpected payload'}`);
  const out = new Map();
  for (const r of json.result.list) {
    const s = r?.symbol;
    if (typeof s !== 'string' || !s.endsWith('USDT') || LEVERAGED.test(s)) continue;
    const p = Number(r.lastPrice);
    if (!(p > 0)) continue;
    const pct = Number(r.price24hPcnt);
    out.set(s, tk(p, Number(r.prevPrice24h), Number(r.highPrice24h), Number(r.lowPrice24h), Number(r.turnover24h) || 0, fin(pct) ? pct * 100 : undefined));
  }
  return out;
}

export function parseBybitKlines(json) {
  if (json?.retCode !== 0 || !Array.isArray(json?.result?.list)) throw httpError(502, `bybit: ${json?.retMsg ?? 'unexpected payload'}`);
  const out = [];
  for (const r of json.result.list) {
    const [t, o, h, l, c] = [Number(r[0]), Number(r[1]), Number(r[2]), Number(r[3]), Number(r[4])];
    if (![t, o, h, l, c].every(fin)) continue;
    out.push({ t, o, h, l, c, v: Number(r[6]) || 0 }); // turnover = quote volume
  }
  return out.sort((a, b) => a.t - b.t); // Bybit returns newest first
}

export function parseOkxTickers(json) {
  if (json?.code !== '0' || !Array.isArray(json?.data)) throw httpError(502, `okx: ${json?.msg || 'unexpected payload'}`);
  const out = new Map();
  for (const r of json.data) {
    const id = r?.instId;
    if (typeof id !== 'string' || !id.endsWith('-USDT')) continue;
    const p = Number(r.last);
    if (!(p > 0)) continue;
    out.set(id.replace('-', ''), tk(p, Number(r.open24h), Number(r.high24h), Number(r.low24h), Number(r.volCcy24h) || 0));
  }
  return out;
}

export function parseOkxKlines(json) {
  if (json?.code !== '0' || !Array.isArray(json?.data)) throw httpError(502, `okx: ${json?.msg || 'unexpected payload'}`);
  const out = [];
  for (const r of json.data) {
    const [t, o, h, l, c] = [Number(r[0]), Number(r[1]), Number(r[2]), Number(r[3]), Number(r[4])];
    if (![t, o, h, l, c].every(fin)) continue;
    out.push({ t, o, h, l, c, v: Number(r[7]) || Number(r[6]) * c || 0 }); // volCcyQuote
  }
  return out.sort((a, b) => a.t - b.t);
}

export function parseGateTickers(rows) {
  if (!Array.isArray(rows)) throw httpError(502, 'gate: unexpected tickers payload');
  const out = new Map();
  for (const r of rows) {
    const pair = r?.currency_pair;
    if (typeof pair !== 'string' || !pair.endsWith('_USDT') || LEVERAGED.test(pair.replace('_', ''))) continue;
    const p = Number(r.last);
    if (!(p > 0)) continue;
    const pct = Number(r.change_percentage);
    out.set(pair.replace('_', ''), tk(p, 0, Number(r.high_24h), Number(r.low_24h), Number(r.quote_volume) || 0, fin(pct) ? pct : 0));
  }
  return out;
}

export function parseGateKlines(rows) {
  if (!Array.isArray(rows)) throw httpError(502, 'gate: unexpected candles payload');
  const out = [];
  for (const r of rows) {
    // Gate API v4: [t(sec), quote_volume, CLOSE, HIGH, LOW, OPEN, base_volume, window_closed]
    const t = Number(r[0]) * 1000;
    const [c, h, l, o] = [Number(r[2]), Number(r[3]), Number(r[4]), Number(r[5])];
    if (![t, o, h, l, c].every(fin)) continue;
    out.push({ t, o, h, l, c, v: Number(r[1]) || 0 });
  }
  return out.sort((a, b) => a.t - b.t);
}

export function parseCoinGecko(rows) {
  if (!Array.isArray(rows)) throw httpError(502, 'coingecko: unexpected payload');
  return rows
    .filter((r) => r && typeof r.symbol === 'string' && r.market_cap_rank > 0)
    .map((r) => ({ base: r.symbol.toUpperCase(), name: r.name || r.symbol.toUpperCase(), rank: r.market_cap_rank, mcap: Number(r.market_cap) || 0, image: r.image || '' }))
    .sort((a, b) => a.rank - b.rank);
}

export function parsePaprika(rows) {
  if (!Array.isArray(rows)) throw httpError(502, 'coinpaprika: unexpected payload');
  return rows
    .filter((r) => r && typeof r.symbol === 'string' && r.rank > 0)
    .map((r) => ({
      base: r.symbol.toUpperCase(),
      name: r.name || r.symbol.toUpperCase(),
      rank: r.rank,
      mcap: Number(r.quotes?.USD?.market_cap) || 0,
      image: r.id ? `https://static.coinpaprika.com/coin/${r.id}/logo.png` : '',
    }))
    .sort((a, b) => a.rank - b.rank)
    .slice(0, 400);
}

/** turn a ranking + the exchanges' tradable USDT pairs into the final universe (exported for tests) */
export function buildUniverse(ranking, tradable, count, exclude) {
  const out = [];
  const seen = new Set();
  for (const r of ranking) {
    if (exclude.has(r.base) || seen.has(r.base)) continue;
    const symbol = `${r.base}USDT`;
    if (!tradable.has(symbol)) continue;
    seen.add(r.base);
    out.push({ symbol, base: r.base, name: r.name, rank: out.length + 1, mcapRank: r.rank, mcap: r.mcap, image: r.image });
    if (out.length >= count) break;
  }
  return out;
}

/** merge the forming candle (from WebSocket / last price) into a REST candle list */
export function overlayLive(candles, live, price, ms, now = Date.now()) {
  if (!candles.length) return candles;
  const out = candles.slice();
  const last = out[out.length - 1];
  if (live && live.t >= last.t && live.t + ms > now - ms) {
    if (live.t === last.t) out[out.length - 1] = live;
    else if (live.t > last.t) out.push(live);
    return out;
  }
  if (price > 0 && last.t + ms > now) out[out.length - 1] = { ...last, c: price, h: Math.max(last.h, price), l: Math.min(last.l, price) };
  return out;
}

/* ------------------------------------------------------------------ exchanges */

function splitList(v, def) {
  const l = String(v ?? '')
    .split(',')
    .map((s) => s.trim().replace(/\/+$/, ''))
    .filter(Boolean);
  return l.length ? l : def;
}

function makeProviders(env) {
  const BINANCE_INT = { '1m': '1m', '5m': '5m', '15m': '15m', '1h': '1h', '4h': '4h', '1d': '1d' };
  const BYBIT_INT = { '1m': '1', '5m': '5', '15m': '15', '1h': '60', '4h': '240', '1d': 'D' };
  const OKX_INT = { '1m': '1m', '5m': '5m', '15m': '15m', '1h': '1H', '4h': '4H', '1d': '1Dutc' };
  return [
    {
      id: 'binance',
      label: 'Binance',
      bases: splitList(env.BINANCE_REST, ['https://data-api.binance.vision', 'https://api.binance.com', 'https://api-gcp.binance.com']),
      async tickers(get) {
        return parseBinanceTickers(await get('/api/v3/ticker/24hr'));
      },
      async candles(get, symbol, interval, limit) {
        return parseBinanceKlines(await get(`/api/v3/klines?symbol=${symbol}&interval=${BINANCE_INT[interval]}&limit=${Math.min(limit, 1000)}`));
      },
    },
    {
      id: 'bybit',
      label: 'Bybit',
      bases: splitList(env.BYBIT_REST, ['https://api.bybit.com', 'https://api.bytick.com']),
      async tickers(get) {
        return parseBybitTickers(await get('/v5/market/tickers?category=spot'));
      },
      async candles(get, symbol, interval, limit) {
        return parseBybitKlines(await get(`/v5/market/kline?category=spot&symbol=${symbol}&interval=${BYBIT_INT[interval]}&limit=${Math.min(limit, 1000)}`));
      },
    },
    {
      id: 'okx',
      label: 'OKX',
      bases: splitList(env.OKX_REST, ['https://www.okx.com', 'https://aws.okx.com']),
      async tickers(get) {
        return parseOkxTickers(await get('/api/v5/market/tickers?instType=SPOT'));
      },
      async candles(get, symbol, interval, limit) {
        return parseOkxKlines(await get(`/api/v5/market/candles?instId=${baseOf(symbol)}-USDT&bar=${OKX_INT[interval]}&limit=${Math.min(limit, 300)}`));
      },
    },
    {
      id: 'gate.io',
      label: 'Gate.io',
      bases: splitList(env.GATE_REST, ['https://api.gateio.ws']),
      async tickers(get) {
        return parseGateTickers(await get('/api/v4/spot/tickers'));
      },
      async candles(get, symbol, interval, limit) {
        return parseGateKlines(await get(`/api/v4/spot/candlesticks?currency_pair=${baseOf(symbol)}_USDT&interval=${interval}&limit=${Math.min(limit, 1000)}`));
      },
    },
  ];
}

/* ------------------------------------------------------------------ Binance WebSocket */

/**
 * One WebSocket to Binance: all-market mini tickers (every ~1 s) + kline streams on demand.
 * Reconnects with back-off, rotates between the endpoints, and a watchdog drops a silent connection.
 */
function createBinanceStream({ WS, urls, onTickers, onKline, log }) {
  let sock = null;
  let open = false;
  let stopped = true;
  let urlIdx = 0;
  let backoff = 1000;
  let lastMsg = 0;
  let reconnectTimer;
  let watchdog;
  let msgId = 0;
  const wanted = new Set();

  const send = (method, params) => {
    if (!open || !sock || !params.length) return;
    try {
      sock.send(JSON.stringify({ method, params, id: ++msgId }));
    } catch {
      /* the close handler reconnects */
    }
  };

  function handle(raw) {
    let msg;
    try {
      msg = JSON.parse(typeof raw === 'string' ? raw : String(raw));
    } catch {
      return;
    }
    const data = msg && msg.stream && msg.data !== undefined ? msg.data : msg;
    if (Array.isArray(data)) onTickers(data);
    else if (data && data.e === 'kline' && data.k) onKline(data.k);
    else if (data && data.e === '24hrMiniTicker') onTickers([data]);
  }

  function scheduleReconnect() {
    if (stopped) return;
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(connect, backoff);
    reconnectTimer.unref?.();
    backoff = Math.min(backoff * 2, 30_000);
  }

  function connect() {
    if (stopped || !WS) return;
    const url = urls[urlIdx % urls.length];
    let s;
    try {
      s = new WS(url);
    } catch (e) {
      log(`[live] websocket cannot start (${e?.message})`);
      urlIdx++;
      scheduleReconnect();
      return;
    }
    sock = s;
    const connectTimeout = setTimeout(() => {
      if (!open && sock === s) {
        try {
          s.close();
        } catch {
          /* ignore */
        }
      }
    }, 10_000);
    connectTimeout.unref?.();
    s.onopen = () => {
      if (sock !== s) return;
      clearTimeout(connectTimeout);
      open = true;
      backoff = 1000;
      lastMsg = Date.now();
      send('SUBSCRIBE', ['!miniTicker@arr', ...wanted]);
    };
    s.onmessage = (ev) => {
      lastMsg = Date.now();
      handle(ev.data);
    };
    s.onerror = () => {};
    s.onclose = () => {
      clearTimeout(connectTimeout);
      if (sock !== s) return;
      sock = null;
      open = false;
      urlIdx++;
      scheduleReconnect();
    };
  }

  return {
    start() {
      if (!stopped) return;
      stopped = false;
      connect();
      watchdog = setInterval(() => {
        if (open && Date.now() - lastMsg > 15_000 && sock) {
          try {
            sock.close();
          } catch {
            /* ignore */
          }
          // some stacks never fire `close` on a dead socket: drop it ourselves
          const dead = sock;
          setTimeout(() => {
            if (sock === dead) {
              sock = null;
              open = false;
              urlIdx++;
              scheduleReconnect();
            }
          }, 2000).unref?.();
        }
      }, 5000);
      watchdog.unref?.();
    },
    stop() {
      stopped = true;
      clearTimeout(reconnectTimer);
      clearInterval(watchdog);
      open = false;
      try {
        sock?.close();
      } catch {
        /* ignore */
      }
      sock = null;
    },
    subscribe(stream) {
      if (wanted.has(stream)) return;
      wanted.add(stream);
      send('SUBSCRIBE', [stream]);
    },
    unsubscribe(stream) {
      if (!wanted.delete(stream)) return;
      send('UNSUBSCRIBE', [stream]);
    },
    healthy: () => open && Date.now() - lastMsg < 6000,
    state: () => ({ open, lastMessageAgoMs: lastMsg ? Date.now() - lastMsg : null, streams: wanted.size, endpoint: urls[urlIdx % urls.length] }),
  };
}

/* ------------------------------------------------------------------ the hub */

export function createCryptoApi(env = {}, opts = {}) {
  const f = opts.fetch ?? globalThis.fetch;
  const WS = opts.WebSocket === undefined ? globalThis.WebSocket : opts.WebSocket;
  const log = opts.log ?? ((m) => console.warn(m));
  const COUNT = Math.max(1, Math.min(250, num(env.TOP_N, 60)));
  const TIMEOUT = num(env.LIVE_TIMEOUT_MS, 8000);
  const REST_TICKER_MS = num(env.TICKER_POLL_MS, 5000);
  const MAX_STREAMS = num(env.MAX_STREAMS, 300);
  const exclude = new Set([...STABLE, ...WRAPPED, ...splitList(env.EXCLUDE_SYMBOLS, []).map((s) => s.toUpperCase())]);
  const cacheFile = opts.cacheFile ?? (env.UNIVERSE_CACHE || null);
  const wsEnabled = !!WS && env.LIVE_WS !== '0';

  /* ---- exchange access with sticky base URL + temporary blocking of a failing exchange */
  const providers = makeProviders(env).map((p) => ({
    ...p,
    baseIdx: 0,
    blockedUntil: 0,
    lastError: '',
    symbols: new Set(),
    async get(pathAndQuery) {
      let lastErr;
      for (let k = 0; k < this.bases.length; k++) {
        const idx = (this.baseIdx + k) % this.bases.length;
        try {
          const j = await fetchJson(this.bases[idx] + pathAndQuery);
          this.baseIdx = idx;
          return j;
        } catch (e) {
          lastErr = e;
          if (e.status === 429) break; // rate limited: other mirrors share the limit
        }
      }
      throw lastErr;
    },
  }));
  const providerById = new Map(providers.map((p) => [p.id, p]));

  async function fetchJson(url, headers = {}) {
    let r;
    try {
      r = await f(url, { headers: { Accept: 'application/json', 'User-Agent': UA, ...headers }, signal: AbortSignal.timeout(TIMEOUT) });
    } catch (e) {
      throw httpError(502, `network: ${e?.cause?.code || e?.name || e?.message || 'error'}`);
    }
    if (!r.ok) {
      const e = httpError(r.status === 429 || r.status === 418 ? 429 : 502, `http ${r.status}`);
      e.upstream = r.status;
      e.retryAfter = Number(r.headers?.get?.('retry-after')) || 0;
      throw e;
    }
    try {
      return await r.json();
    } catch {
      throw httpError(502, 'invalid json');
    }
  }

  function noteFailure(p, e) {
    p.lastError = e?.message || 'error';
    let ms = 15_000;
    if (e?.status === 429) ms = Math.max(60_000, (e.retryAfter || 0) * 1000);
    else if (e?.upstream === 451 || e?.upstream === 403) ms = 10 * 60_000; // geo-blocked: will not fix itself soon
    p.blockedUntil = Date.now() + ms;
  }

  /* ---- state */
  let universe = { coins: [], rankSource: 'none', updatedAt: 0 };
  let universeSet = new Set();
  const tickers = new Map(); // symbol -> { symbol, price, changePct, high, low, volume, t }
  let tickersVersion = 0;
  let tickersAt = 0;
  let tickerSource = null; // provider id of the last REST ticker snapshot
  const liveK = new Map(); // `${symbol}|${interval}` -> { c, at } latest kline from WebSocket
  const cache = new Map();
  const inflight = new Map();
  let started = false;
  let warm = null;
  const timers = new Set();
  const sseClients = new Set();

  const later = (fn, ms) => {
    const t = setTimeout(() => {
      timers.delete(t);
      fn();
    }, ms);
    t.unref?.();
    timers.add(t);
    return t;
  };

  try {
    if (cacheFile) {
      const j = JSON.parse(readFileSync(cacheFile, 'utf8'));
      if (Array.isArray(j.coins) && j.coins.length) setUniverse(j.coins, j.rankSource || 'cache', j.updatedAt || 0);
    }
  } catch {
    /* no cache yet */
  }

  function setUniverse(coins, rankSource, updatedAt = Date.now()) {
    universe = { coins, rankSource, updatedAt };
    universeSet = new Set(coins.map((c) => c.symbol));
    for (const k of [...tickers.keys()]) if (!universeSet.has(k)) tickers.delete(k);
  }

  /* ---- tickers */
  const allTickers = new Map(); // every USDT pair of the last REST snapshot (used to build the universe)

  function putTicker(symbol, t, now = Date.now()) {
    if (universeSet.size && !universeSet.has(symbol)) return;
    tickers.set(symbol, { symbol, ...t, t: now });
    tickersVersion++;
    tickersAt = now;
  }

  async function refreshTickers() {
    const now = Date.now();
    const order = providers.filter((p) => p.blockedUntil <= now);
    // prefer the exchange that served us last time
    order.sort((a, b) => (a.id === tickerSource ? -1 : b.id === tickerSource ? 1 : 0));
    let lastErr = httpError(502, 'all exchanges are unreachable');
    for (const p of order) {
      try {
        const map = await p.tickers(p.get.bind(p));
        if (!map.size) throw httpError(502, `${p.id}: empty tickers`);
        p.lastError = '';
        p.symbols = new Set(map.keys());
        allTickers.clear();
        for (const [s, t] of map) allTickers.set(s, t);
        tickerSource = p.id;
        const t = Date.now();
        // only overwrite what the WebSocket has not updated within the last 2 s
        for (const [s, v] of map) {
          const cur = tickers.get(s);
          if (!cur || t - cur.t > 2000 || !stream?.healthy()) putTicker(s, v, t);
        }
        tickersAt = t;
        return p.id;
      } catch (e) {
        lastErr = e;
        noteFailure(p, e);
      }
    }
    throw lastErr;
  }

  /* ---- universe */
  async function fetchRanking() {
    const headers = env.COINGECKO_API_KEY ? { 'x-cg-demo-api-key': env.COINGECKO_API_KEY } : {};
    const cg = splitList(env.COINGECKO_URL, ['https://api.coingecko.com'])[0];
    try {
      const rows = await fetchJson(`${cg}/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1&sparkline=false`, headers);
      const r = parseCoinGecko(rows);
      if (r.length >= 20) return { ranking: r, source: 'coingecko' };
    } catch (e) {
      log(`[live] CoinGecko ranking unavailable (${e.message}) -> trying CoinPaprika`);
    }
    try {
      const pp = splitList(env.PAPRIKA_URL, ['https://api.coinpaprika.com'])[0];
      const r = parsePaprika(await fetchJson(`${pp}/v1/tickers?quotes=USD`));
      if (r.length >= 20) return { ranking: r, source: 'coinpaprika' };
    } catch (e) {
      log(`[live] CoinPaprika ranking unavailable (${e.message}) -> ranking by 24h volume`);
    }
    return null;
  }

  async function refreshUniverse() {
    if (!allTickers.size) await refreshTickers(); // need the tradable pairs first
    const tradable = new Set();
    for (const p of providers) for (const s of p.symbols) tradable.add(s);
    if (!tradable.size) for (const s of allTickers.keys()) tradable.add(s);
    const ranked = await fetchRanking();
    let coins;
    let rankSource;
    if (ranked) {
      coins = buildUniverse(ranked.ranking, tradable, COUNT, exclude);
      rankSource = ranked.source;
    }
    if (!coins || coins.length < Math.min(20, COUNT)) {
      // no market-cap ranking (or it matched almost nothing): rank by 24h quote volume
      const byVol = [...allTickers.entries()].sort((a, b) => b[1].volume - a[1].volume).map(([s], i) => ({ base: baseOf(s), name: baseOf(s), rank: i + 1, mcap: 0, image: '' }));
      coins = buildUniverse(byVol, tradable, COUNT, exclude);
      rankSource = 'volume';
    }
    if (!coins.length) throw httpError(502, 'universe is empty');
    setUniverse(coins, rankSource);
    // seed tickers for the new universe straight from the last REST snapshot
    const t = Date.now();
    for (const c of coins) {
      const v = allTickers.get(c.symbol);
      if (v && !tickers.has(c.symbol)) putTicker(c.symbol, v, t);
    }
    try {
      if (cacheFile) {
        mkdirSync(path.dirname(cacheFile), { recursive: true });
        writeFileSync(cacheFile, JSON.stringify(universe));
      }
    } catch {
      /* read-only file system: fine */
    }
    return universe;
  }

  /* ---- WebSocket */
  const stream = wsEnabled
    ? createBinanceStream({
        WS,
        log,
        urls: splitList(env.BINANCE_WS, ['wss://stream.binance.com:9443/stream?streams=!miniTicker@arr', 'wss://data-stream.binance.vision/stream?streams=!miniTicker@arr']),
        onTickers(rows) {
          const now = Date.now();
          for (const r of rows) {
            const s = r?.s;
            const price = Number(r?.c);
            if (typeof s !== 'string' || !universeSet.has(s) || !(price > 0)) continue;
            putTicker(s, tk(price, Number(r.o), Number(r.h), Number(r.l), Number(r.q) || 0), now);
          }
          tickerSource = 'binance';
        },
        onKline(k) {
          const iv = k.i;
          const symbol = k.s;
          const c = { t: Number(k.t), o: Number(k.o), h: Number(k.h), l: Number(k.l), c: Number(k.c), v: Number(k.q) || 0 };
          if (![c.t, c.o, c.h, c.l, c.c].every(fin)) return;
          const key = `${symbol}|${iv}`;
          liveK.set(key, { c, at: Date.now() });
          const sub = candleSubs.get(key);
          if (sub) for (const cb of sub.cbs) cb({ source: 'binance', candle: c, closed: !!k.x });
        },
      })
    : null;

  /* ---- candles */
  async function cached(key, ttl, fn) {
    const hit = cache.get(key);
    const now = Date.now();
    if (hit && now - hit.at < ttl) return { ...hit.value, stale: false, fetchedAt: hit.at };
    if (inflight.has(key)) return inflight.get(key);
    const p = (async () => {
      try {
        const value = await fn();
        const entry = { at: Date.now(), value };
        cache.set(key, entry);
        if (cache.size > 400) cache.delete(cache.keys().next().value);
        return { ...value, stale: false, fetchedAt: entry.at };
      } catch (e) {
        if (hit && Date.now() - hit.at < 120_000) return { ...hit.value, stale: true, fetchedAt: hit.at };
        throw e;
      } finally {
        inflight.delete(key);
      }
    })();
    inflight.set(key, p);
    return p;
  }

  function candleOrder(symbol) {
    const now = Date.now();
    const ok = providers.filter((p) => p.blockedUntil <= now);
    const rank = (p) => (p.symbols.has(symbol) ? 0 : p.symbols.size ? 2 : 1) + (p.id === tickerSource ? -0.5 : 0);
    return ok.sort((a, b) => rank(a) - rank(b)).filter((p) => !p.symbols.size || p.symbols.has(symbol) || true);
  }

  async function fetchCandles(symbol, interval, limit) {
    let lastErr = httpError(502, 'no exchange could deliver candles');
    for (const p of candleOrder(symbol)) {
      if (p.symbols.size && !p.symbols.has(symbol)) continue; // exchange does not list this pair
      try {
        const candles = await p.candles(p.get.bind(p), symbol, interval, limit);
        if (!candles.length) throw httpError(502, `${p.id}: no candles for ${symbol}`);
        p.lastError = '';
        return { candles, source: p.id };
      } catch (e) {
        lastErr = e;
        if (e.status === 429 || e.upstream === 451 || e.upstream === 403 || /network/.test(e.message)) noteFailure(p, e);
      }
    }
    throw lastErr;
  }

  const pickLimit = (since, ms) => {
    if (!since) return FULL;
    const need = Math.ceil((Date.now() - since) / ms) + 3;
    return BUCKETS.find((b) => b >= need) ?? FULL;
  };

  async function getCandles(symbol, interval, since) {
    const ms = INTERVAL_MS[interval];
    const limit = pickLimit(since, ms);
    const r = await cached(`c|${symbol}|${interval}|${limit}`, 1500, () => fetchCandles(symbol, interval, limit));
    const now = Date.now();
    const k = liveK.get(`${symbol}|${interval}`);
    const t = tickers.get(symbol);
    const live = k && now - k.at < 8000 && r.source === 'binance' ? k.c : null;
    const price = t && now - t.t < 8000 ? t.price : 0;
    const candles = overlayLive(r.candles, live, r.source === 'binance' || !live ? price : 0, ms, now);
    const last = candles[candles.length - 1];
    return {
      candles,
      source: r.source,
      stale: r.stale,
      price: last ? last.c : null,
      quoteTime: r.stale ? r.fetchedAt : now,
      fetchedAt: r.fetchedAt,
    };
  }

  /* ---- per-chart realtime subscriptions (shared by all SSE clients) */
  const candleSubs = new Map(); // key -> { cbs:Set, timer, lastSig }

  function subscribeCandles(symbol, interval, cb) {
    const key = `${symbol}|${interval}`;
    let sub = candleSubs.get(key);
    if (!sub) {
      sub = { cbs: new Set(), timer: null, lastSig: '' };
      candleSubs.set(key, sub);
      stream?.subscribe(`${symbol.toLowerCase()}@kline_${interval}`);
      // safety net: when the WebSocket is down (or never delivers this pair) poll REST every 2 s
      const poll = async () => {
        const wsFresh = stream?.healthy() && liveK.get(key) && Date.now() - liveK.get(key).at < 5000;
        if (!wsFresh && sub.cbs.size) {
          try {
            const r = await getCandles(symbol, interval, Date.now() - 4 * INTERVAL_MS[interval]);
            const c = r.candles[r.candles.length - 1];
            const sig = c ? `${c.t}|${c.o}|${c.h}|${c.l}|${c.c}|${c.v}` : '';
            if (c && sig !== sub.lastSig) {
              sub.lastSig = sig;
              for (const fn of sub.cbs) fn({ source: r.source, candle: c, closed: c.t + INTERVAL_MS[interval] <= Date.now() });
            }
          } catch {
            /* the client reports the connection state from its own REST polling */
          }
        }
        if (candleSubs.get(key) === sub && sub.cbs.size) sub.timer = later(poll, 2000);
      };
      sub.timer = later(poll, 2000);
    }
    sub.cbs.add(cb);
    return () => {
      sub.cbs.delete(cb);
      if (!sub.cbs.size) {
        clearTimeout(sub.timer);
        candleSubs.delete(key);
        liveK.delete(key);
        stream?.unsubscribe(`${symbol.toLowerCase()}@kline_${interval}`);
      }
    };
  }

  /* ---- lifecycle */
  function loop(fn, okMs, failMs) {
    const run = async () => {
      let ms = okMs();
      try {
        await fn();
      } catch (e) {
        ms = failMs;
        log(`[live] ${fn.name}: ${e.message}`);
      }
      if (started) later(run, ms);
    };
    return run;
  }

  function start() {
    if (started) return warm;
    started = true;
    stream?.start();
    warm = (async () => {
      try {
        await refreshTickers();
      } catch (e) {
        log(`[live] first ticker snapshot failed: ${e.message}`);
      }
      try {
        await refreshUniverse();
      } catch (e) {
        log(`[live] universe not built yet: ${e.message}`);
      }
    })();
    warm.then(() => {
      if (!started) return;
      // tickers: fast REST polling only while the WebSocket is not delivering; otherwise a 60 s resync
      later(
        loop(
          async function pollTickers() {
            await refreshTickers();
          },
          () => (stream?.healthy() ? 60_000 : REST_TICKER_MS),
          Math.min(REST_TICKER_MS, 5000),
        ),
        REST_TICKER_MS,
      );
      // ranking: retry quickly until it works, then every 10 minutes
      later(
        loop(
          async function refreshRanking() {
            await refreshUniverse();
          },
          () => 10 * 60_000,
          15_000,
        ),
        universe.coins.length ? 10 * 60_000 : 15_000,
      );
    });
    return warm;
  }

  function close() {
    started = false;
    stream?.stop();
    for (const t of timers) clearTimeout(t);
    timers.clear();
    for (const res of sseClients) {
      try {
        res.end();
      } catch {
        /* ignore */
      }
    }
    sseClients.clear();
    candleSubs.clear();
  }

  /* ---- HTTP */
  const tickerRows = () => universe.coins.map((c) => tickers.get(c.symbol)).filter(Boolean);
  const tickerOut = (t) => ({ symbol: t.symbol, price: t.price, changePct: t.changePct, high: t.high, low: t.low, volume: t.volume });
  const transport = () => (stream?.healthy() ? 'ws' : 'rest');

  function status() {
    const now = Date.now();
    return {
      provider: 'binance-ws + rest failover (binance, bybit, okx, gate.io); ranking: coingecko / coinpaprika',
      transport: transport(),
      websocket: stream ? stream.state() : { enabled: false },
      universe: { count: universe.coins.length, rankSource: universe.rankSource, updatedAt: universe.updatedAt },
      tickers: { count: tickers.size, ageMs: tickersAt ? now - tickersAt : null, source: tickerSource },
      exchanges: providers.map((p) => ({ id: p.id, pairs: p.symbols.size, blockedForMs: Math.max(0, p.blockedUntil - now), lastError: p.lastError })),
      streams: { sseClients: sseClients.size, candleSubscriptions: candleSubs.size },
    };
  }

  const baseHeaders = { 'cache-control': 'no-store', 'access-control-allow-origin': '*' };
  const send = (res, code, body) => {
    res.writeHead(code, { ...baseHeaders, 'content-type': 'application/json' });
    res.end(JSON.stringify(body));
  };

  function openSse(req, res) {
    if (sseClients.size >= MAX_STREAMS) {
      send(res, 503, { error: 'too many live connections' });
      return null;
    }
    res.writeHead(200, { ...baseHeaders, 'content-type': 'text/event-stream; charset=utf-8', connection: 'keep-alive', 'x-accel-buffering': 'no' });
    res.write('retry: 2000\n\n');
    sseClients.add(res);
    const ping = setInterval(() => res.write(': ping\n\n'), 15_000);
    ping.unref?.();
    const cleanup = [];
    const done = () => {
      clearInterval(ping);
      sseClients.delete(res);
      for (const fn of cleanup) fn();
      cleanup.length = 0;
    };
    req.on('close', done);
    res.on('close', done);
    return { push: (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`), onClose: (fn) => cleanup.push(fn) };
  }

  const validSymbol = (s) => /^[A-Z0-9]{1,20}USDT$/.test(s) && (!universeSet.size || universeSet.has(s));

  /** returns true when the request was an /api/live/* request (and has been answered) */
  async function handle(req, res) {
    const url = new URL(req.url ?? '/', 'http://localhost');
    if (!url.pathname.startsWith('/api/live/')) return false;
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { ...baseHeaders, 'access-control-allow-methods': 'GET, OPTIONS' });
      res.end();
      return true;
    }
    if (req.method !== 'GET') {
      send(res, 405, { error: 'method not allowed' });
      return true;
    }
    try {
      if (!started) start();
      // the very first request waits (briefly) for the first snapshot instead of answering "empty"
      if (!universe.coins.length && warm) await Promise.race([warm, new Promise((r) => setTimeout(r, 6000))]);

      if (url.pathname === '/api/live/universe') {
        if (!universe.coins.length) throw httpError(503, 'universe is not ready yet');
        send(res, 200, { coins: universe.coins, rankSource: universe.rankSource, updatedAt: universe.updatedAt });
      } else if (url.pathname === '/api/live/tickers') {
        const rows = tickerRows();
        if (!rows.length) throw httpError(503, 'no ticker data yet');
        send(res, 200, { tickers: rows.map(tickerOut), source: tickerSource, transport: transport(), refreshMs: transport() === 'ws' ? 1000 : REST_TICKER_MS, universeAt: universe.updatedAt, t: tickersAt });
      } else if (url.pathname === '/api/live/candles') {
        const symbol = (url.searchParams.get('symbol') ?? '').toUpperCase();
        const interval = url.searchParams.get('interval') ?? '';
        if (!validSymbol(symbol) || !(interval in INTERVAL_MS)) throw httpError(400, 'unknown symbol or interval');
        const s = Number(url.searchParams.get('since'));
        const v = await getCandles(symbol, interval, Number.isFinite(s) && s > 0 ? s : undefined);
        send(res, 200, {
          symbol,
          interval,
          source: v.source,
          stale: v.stale,
          transport: transport(),
          refreshMs: transport() === 'ws' ? 1000 : 2000,
          fetchedAt: v.fetchedAt,
          price: v.price,
          quoteTime: v.quoteTime,
          candles: v.candles.map((c) => [c.t, c.o, c.h, c.l, c.c, c.v]),
        });
      } else if (url.pathname === '/api/live/stream/tickers') {
        const sse = openSse(req, res);
        if (!sse) return true;
        let sent = -1;
        const flush = () => {
          if (sent === tickersVersion) return;
          sent = tickersVersion;
          const rows = tickerRows();
          if (rows.length) sse.push('tickers', { tickers: rows.map((t) => [t.symbol, t.price, t.changePct, t.high, t.low, t.volume]), source: tickerSource, transport: transport(), universeAt: universe.updatedAt, t: tickersAt });
        };
        flush();
        const iv = setInterval(flush, 1000);
        sse.onClose(() => clearInterval(iv));
      } else if (url.pathname === '/api/live/stream/candles') {
        const symbol = (url.searchParams.get('symbol') ?? '').toUpperCase();
        const interval = url.searchParams.get('interval') ?? '';
        if (!validSymbol(symbol) || !(interval in INTERVAL_MS)) throw httpError(400, 'unknown symbol or interval');
        const sse = openSse(req, res);
        if (!sse) return true;
        sse.push('hello', { symbol, interval, transport: transport() });
        // throttle: the exchange can push several updates per second; one per 250 ms is plenty for a chart
        let pending = null;
        let timer = null;
        const unsub = subscribeCandles(symbol, interval, (m) => {
          pending = m;
          if (timer) return;
          timer = setTimeout(() => {
            timer = null;
            const p = pending;
            pending = null;
            if (p) sse.push('candle', { symbol, interval, source: p.source, closed: p.closed, c: [p.candle.t, p.candle.o, p.candle.h, p.candle.l, p.candle.c, p.candle.v] });
          }, 250);
          timer.unref?.();
        });
        sse.onClose(() => {
          clearTimeout(timer);
          unsub();
        });
      } else if (url.pathname === '/api/live/status') {
        send(res, 200, status());
      } else {
        send(res, 404, { error: 'not found' });
      }
    } catch (e) {
      if (!res.headersSent) send(res, e.status || 502, { error: e.message || 'error' });
    }
    return true;
  }

  return { handle, status, start, close, refreshTickers, refreshUniverse, getCandles, subscribeCandles, universe: () => universe, tickers: () => tickerRows() };
}
