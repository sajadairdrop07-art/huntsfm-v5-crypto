// node --test server/crypto.test.mjs   (no network: exchanges, CoinGecko and the WebSocket are mocked)
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {
  createCryptoApi,
  buildUniverse,
  overlayLive,
  parseBinanceTickers,
  parseBinanceKlines,
  parseBybitTickers,
  parseBybitKlines,
  parseOkxTickers,
  parseOkxKlines,
  parseGateTickers,
  parseGateKlines,
  parseCoinGecko,
  parsePaprika,
  STABLE,
  WRAPPED,
} from './crypto.mjs';

/* ------------------------------------------------------------------ fixtures */

const BASES = ['BTC', 'ETH', 'XRP', 'BNB', 'SOL', 'DOGE', 'TRX', 'ADA', 'LINK', 'AVAX'];
// 120 coins: 10 real names + COIN001.. ; stablecoins/wrapped coins are mixed in on purpose
const COINS = [
  ...BASES,
  'USDT', 'USDC', 'WBTC', 'STETH',
  ...Array.from({ length: 110 }, (_, i) => `C${String(i + 1).padStart(3, '0')}`),
];

const geckoRows = () => COINS.map((b, i) => ({ symbol: b.toLowerCase(), name: `${b} coin`, market_cap_rank: i + 1, market_cap: 1e12 / (i + 1), image: `https://img/${b}.png` }));
const binanceTickers = () => [
  ...COINS.filter((b) => b !== 'USDT').map((b, i) => ({ symbol: `${b}USDT`, lastPrice: String(100 + i), openPrice: '100', highPrice: String(110 + i), lowPrice: '90', priceChangePercent: String(i - 5), quoteVolume: String(1e6 * (200 - i)) })),
  { symbol: 'BTCUPUSDT', lastPrice: '5', openPrice: '5', highPrice: '5', lowPrice: '5', priceChangePercent: '0', quoteVolume: '1' }, // leveraged token: ignored
  { symbol: 'ETHBTC', lastPrice: '0.05', openPrice: '0.05', highPrice: '0.05', lowPrice: '0.05', priceChangePercent: '0', quoteVolume: '1' }, // not a USDT pair
];
const bybitTickers = () => ({ retCode: 0, result: { list: COINS.map((b) => ({ symbol: `${b}USDT`, lastPrice: '101', prevPrice24h: '100', highPrice24h: '110', lowPrice24h: '90', price24hPcnt: '0.01', turnover24h: '5000000' })) } });

const ivMs = { '1m': 60_000, '5m': 300_000, '15m': 900_000, '1h': 3_600_000, '4h': 14_400_000, '1d': 86_400_000 };
function binanceKlines(interval, n = 10, price = 107) {
  const ms = ivMs[interval];
  const start = Math.floor(Date.now() / ms) * ms - (n - 1) * ms;
  return Array.from({ length: n }, (_, i) => {
    const t = start + i * ms;
    const base = 100 + i;
    return [t, String(base), String(base + 2), String(base - 1), String(i === n - 1 ? price : base + 1), '1', t + ms - 1, String(1000 + i), 10, '1', '1', '0'];
  });
}

/** mock fetch: `plan` maps a host to a handler(url) -> body | number (HTTP error code) | Error */
function mockFetch(plan) {
  const calls = [];
  const fn = async (url) => {
    const u = new URL(url);
    calls.push(String(url));
    const h = plan[u.host];
    if (!h) throw new TypeError('fetch failed');
    const out = h(u);
    if (out instanceof Error) throw out;
    if (typeof out === 'number') return new Response('{}', { status: out });
    return new Response(JSON.stringify(out), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  fn.calls = calls;
  return fn;
}

const healthyPlan = () => ({
  'data-api.binance.vision': (u) => (u.pathname === '/api/v3/ticker/24hr' ? binanceTickers() : u.pathname === '/api/v3/klines' ? binanceKlines(u.searchParams.get('interval'), 10) : 404),
  'api.coingecko.com': () => geckoRows(),
});

class FakeWS {
  static last = null;
  constructor(url) {
    this.url = url;
    this.sent = [];
    FakeWS.last = this;
    queueMicrotask(() => this.onopen?.());
  }
  send(m) { this.sent.push(JSON.parse(m)); }
  close() { this.onclose?.(); }
  push(obj) { this.onmessage?.({ data: JSON.stringify(obj) }); }
}

const quiet = { log: () => {}, cacheFile: null };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** SSE reader that never drops a chunk: one read is kept pending across polls */
function sseReader(res) {
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let pending = null;
  const r = { buf: '' };
  r.until = async (re, ms = 4000) => {
    const end = Date.now() + ms;
    while (!re.test(r.buf) && Date.now() < end) {
      pending ??= reader.read().then((x) => { pending = null; return x; });
      const x = await Promise.race([pending, sleep(100).then(() => null)]);
      if (x && !x.done) r.buf += dec.decode(x.value);
      if (x?.done) break;
    }
    return re.test(r.buf);
  };
  return r;
}

async function serve(api) {
  const server = http.createServer(async (req, res) => {
    if (!(await api.handle(req, res))) { res.writeHead(404); res.end(); }
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { base, close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(r); }) };
}

/* ------------------------------------------------------------------ parsers */

test('binance parsers: tickers skip leveraged tokens and non-USDT pairs; klines use quote volume', () => {
  const m = parseBinanceTickers(binanceTickers());
  assert.ok(m.has('BTCUSDT'));
  assert.ok(!m.has('BTCUPUSDT'));
  assert.ok(!m.has('ETHBTC'));
  assert.equal(m.get('BTCUSDT').volume, 1e6 * 200);
  const k = parseBinanceKlines(binanceKlines('1m', 3));
  assert.equal(k.length, 3);
  assert.deepEqual(Object.keys(k[0]), ['t', 'o', 'h', 'l', 'c', 'v']);
  assert.equal(k[0].v, 1000);
  assert.ok(k[0].t < k[2].t);
  assert.throws(() => parseBinanceTickers({}), /unexpected/);
});

test('bybit parsers: percent is converted, klines are sorted oldest first', () => {
  const m = parseBybitTickers(bybitTickers());
  assert.equal(Math.round(m.get('BTCUSDT').changePct * 100) / 100, 1);
  const k = parseBybitKlines({ retCode: 0, result: { list: [[2000, '2', '3', '1', '2.5', '1', '77'], [1000, '1', '2', '0.5', '1.5', '1', '55']] } });
  assert.deepEqual(k.map((c) => c.t), [1000, 2000]);
  assert.equal(k[0].v, 55);
  assert.throws(() => parseBybitTickers({ retCode: 10001, retMsg: 'nope' }), /nope/);
});

test('okx parsers: instId BTC-USDT becomes BTCUSDT', () => {
  const m = parseOkxTickers({ code: '0', data: [{ instId: 'BTC-USDT', last: '50', open24h: '40', high24h: '55', low24h: '39', volCcy24h: '1234' }, { instId: 'BTC-USD', last: '1' }] });
  assert.deepEqual([...m.keys()], ['BTCUSDT']);
  assert.equal(m.get('BTCUSDT').changePct, 25);
  const k = parseOkxKlines({ code: '0', data: [['2000', '2', '3', '1', '2', '5', '9', '88', '1'], ['1000', '1', '2', '1', '1', '5', '9', '77', '1']] });
  assert.deepEqual(k.map((c) => [c.t, c.v]), [[1000, 77], [2000, 88]]);
});

test('gate.io parsers: candle column order is [t, quote_vol, close, high, low, open]', () => {
  const k = parseGateKlines([[1700000000, '999', '12', '15', '9', '10', '5', true]]);
  assert.deepEqual(k[0], { t: 1_700_000_000_000, o: 10, h: 15, l: 9, c: 12, v: 999 });
  const m = parseGateTickers([{ currency_pair: 'ETH_USDT', last: '3000', change_percentage: '-2.5', high_24h: '3100', low_24h: '2900', quote_volume: '777' }, { currency_pair: 'ETH_BTC', last: '1' }]);
  assert.deepEqual([...m.keys()], ['ETHUSDT']);
  assert.equal(m.get('ETHUSDT').changePct, -2.5);
});

test('ranking parsers keep rank order', () => {
  const g = parseCoinGecko([{ symbol: 'eth', name: 'Ethereum', market_cap_rank: 2, market_cap: 5 }, { symbol: 'btc', name: 'Bitcoin', market_cap_rank: 1, market_cap: 9 }, { symbol: 'x', market_cap_rank: null }]);
  assert.deepEqual(g.map((r) => r.base), ['BTC', 'ETH']);
  const p = parsePaprika([{ id: 'eth-ethereum', symbol: 'ETH', name: 'Ethereum', rank: 2, quotes: { USD: { market_cap: 5 } } }, { id: 'btc-bitcoin', symbol: 'BTC', name: 'Bitcoin', rank: 1, quotes: { USD: { market_cap: 9 } } }]);
  assert.deepEqual(p.map((r) => r.base), ['BTC', 'ETH']);
  assert.match(p[0].image, /btc-bitcoin/);
});

/* ------------------------------------------------------------------ universe */

test('buildUniverse: top N, no stablecoins / wrapped coins / duplicates, only tradable pairs', () => {
  const ranking = parseCoinGecko(geckoRows());
  const tradable = new Set(COINS.map((b) => `${b}USDT`));
  tradable.delete('C005USDT'); // not listed on any exchange
  const exclude = new Set([...STABLE, ...WRAPPED]);
  const u = buildUniverse(ranking, tradable, 60, exclude);
  assert.equal(u.length, 60);
  const bases = u.map((c) => c.base);
  for (const bad of ['USDT', 'USDC', 'WBTC', 'STETH', 'C005']) assert.ok(!bases.includes(bad), bad);
  assert.equal(new Set(bases).size, 60);
  assert.deepEqual(u.map((c) => c.rank), Array.from({ length: 60 }, (_, i) => i + 1)); // contiguous ranks
  assert.equal(u[0].symbol, 'BTCUSDT');
  assert.equal(buildUniverse(ranking, tradable, 50, exclude).length, 50);
});

/* ------------------------------------------------------------------ overlayLive */

test('overlayLive: pushed candle replaces / appends, last price patches the forming bar', () => {
  const ms = 60_000;
  const now = 10 * ms + 5000;
  const cs = [{ t: 8 * ms, o: 1, h: 2, l: 1, c: 2, v: 1 }, { t: 9 * ms, o: 2, h: 3, l: 2, c: 3, v: 1 }, { t: 10 * ms, o: 3, h: 4, l: 3, c: 3.5, v: 1 }];
  const same = overlayLive(cs, { t: 10 * ms, o: 3, h: 5, l: 3, c: 4.8, v: 9 }, 0, ms, now);
  assert.equal(same.length, 3);
  assert.equal(same[2].c, 4.8);
  const next = overlayLive(cs, { t: 11 * ms, o: 3.5, h: 3.6, l: 3.4, c: 3.6, v: 1 }, 0, ms, 11 * ms + 1000);
  assert.equal(next.length, 4);
  const byPrice = overlayLive(cs, null, 6, ms, now);
  assert.equal(byPrice[2].c, 6);
  assert.equal(byPrice[2].h, 6);
  assert.equal(cs[2].c, 3.5); // input untouched
});

/* ------------------------------------------------------------------ HTTP API */

test('default universe is the top 60; TOP_N changes it', async () => {
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch(healthyPlan()) });
  const s = await serve(api);
  try {
    const j = await (await fetch(`${s.base}/api/live/universe`)).json();
    assert.equal(j.coins.length, 60);
    assert.equal(j.rankSource, 'coingecko');
    assert.equal(j.coins[0].symbol, 'BTCUSDT');
    assert.ok(j.coins.every((c) => !['USDT', 'USDC', 'WBTC', 'STETH'].includes(c.base)));
  } finally {
    api.close();
    await s.close();
  }
  const api50 = createCryptoApi({ LIVE_WS: '0', TOP_N: '50' }, { ...quiet, fetch: mockFetch(healthyPlan()) });
  const s2 = await serve(api50);
  try {
    assert.equal((await (await fetch(`${s2.base}/api/live/universe`)).json()).coins.length, 50);
  } finally {
    api50.close();
    await s2.close();
  }
});

test('tickers: one row per coin of the universe, nothing else', async () => {
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch(healthyPlan()) });
  const s = await serve(api);
  try {
    const u = await (await fetch(`${s.base}/api/live/universe`)).json();
    const t = await (await fetch(`${s.base}/api/live/tickers`)).json();
    assert.equal(t.tickers.length, 60);
    assert.deepEqual(new Set(t.tickers.map((x) => x.symbol)), new Set(u.coins.map((c) => c.symbol)));
    assert.equal(t.transport, 'rest');
    const btc = t.tickers.find((x) => x.symbol === 'BTCUSDT');
    assert.ok(btc.price > 0 && Number.isFinite(btc.changePct) && btc.volume > 0);
  } finally {
    api.close();
    await s.close();
  }
});

test('candles: validation, shape, and the forming candle carries the latest price', async () => {
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch(healthyPlan()) });
  const s = await serve(api);
  try {
    assert.equal((await fetch(`${s.base}/api/live/candles?symbol=BTCUSDT&interval=2m`)).status, 400);
    assert.equal((await fetch(`${s.base}/api/live/candles?symbol=NOPE&interval=1m`)).status, 400);
    assert.equal((await fetch(`${s.base}/api/live/candles?symbol=../../etc&interval=1m`)).status, 400);
    assert.equal((await fetch(`${s.base}/api/live/candles?symbol=BTCUSDT&interval=1m`, { method: 'POST' })).status, 405);
    for (const interval of ['1m', '5m', '15m', '1h', '4h', '1d']) {
      const r = await fetch(`${s.base}/api/live/candles?symbol=btcusdt&interval=${interval}`);
      assert.equal(r.status, 200, interval);
      const j = await r.json();
      assert.equal(j.source, 'binance');
      assert.equal(j.stale, false);
      assert.equal(j.candles.length, 10);
      assert.equal(j.candles[0].length, 6);
      assert.ok(j.candles.every((c, i, a) => i === 0 || c[0] > a[i - 1][0]));
    }
  } finally {
    api.close();
    await s.close();
  }
});

test('failover: Binance geo-blocked (451) -> Bybit serves tickers and candles; blocked exchange is skipped afterwards', async () => {
  const fetchImpl = mockFetch({
    'data-api.binance.vision': () => 451,
    'api.binance.com': () => 451,
    'api-gcp.binance.com': () => 451,
    'api.bybit.com': (u) => (u.pathname === '/v5/market/tickers' ? bybitTickers() : { retCode: 0, result: { list: binanceKlines('15m', 10).map((r) => [r[0], r[1], r[2], r[3], r[4], r[5], r[7]]).reverse() } }),
    'api.coingecko.com': () => geckoRows(),
  });
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: fetchImpl });
  const s = await serve(api);
  try {
    const t = await (await fetch(`${s.base}/api/live/tickers`)).json();
    assert.equal(t.source, 'bybit');
    assert.equal(t.tickers.length, 60);
    const c = await (await fetch(`${s.base}/api/live/candles?symbol=ETHUSDT&interval=15m`)).json();
    assert.equal(c.source, 'bybit');
    assert.ok(c.candles[0][0] < c.candles[9][0]); // oldest first even though Bybit sends newest first
    const st = await (await fetch(`${s.base}/api/live/status`)).json();
    assert.ok(st.exchanges.find((e) => e.id === 'binance').blockedForMs > 60_000);
  } finally {
    api.close();
    await s.close();
  }
});

test('CoinGecko down -> CoinPaprika ranking; both down -> ranking by 24h volume', async () => {
  const paprika = () => COINS.map((b, i) => ({ id: `${b.toLowerCase()}-x`, symbol: b, name: b, rank: i + 1, quotes: { USD: { market_cap: 1e9 - i } } }));
  const a1 = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch({ ...healthyPlan(), 'api.coingecko.com': () => 429, 'api.coinpaprika.com': paprika }) });
  const s1 = await serve(a1);
  try {
    const j = await (await fetch(`${s1.base}/api/live/universe`)).json();
    assert.equal(j.rankSource, 'coinpaprika');
    assert.equal(j.coins.length, 60);
  } finally {
    a1.close();
    await s1.close();
  }
  const a2 = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch({ ...healthyPlan(), 'api.coingecko.com': () => 500 }) });
  const s2 = await serve(a2);
  try {
    const j = await (await fetch(`${s2.base}/api/live/universe`)).json();
    assert.equal(j.rankSource, 'volume');
    assert.equal(j.coins.length, 60);
    assert.ok(!j.coins.some((c) => ['USDC', 'WBTC', 'STETH'].includes(c.base)));
  } finally {
    a2.close();
    await s2.close();
  }
});

test('everything down: clear 503/502 instead of a hang or a crash', async () => {
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch({}) });
  const s = await serve(api);
  try {
    const r = await fetch(`${s.base}/api/live/tickers`);
    assert.ok([502, 503].includes(r.status));
    assert.ok((await r.json()).error);
  } finally {
    api.close();
    await s.close();
  }
});

/* ------------------------------------------------------------------ real time */

test('WebSocket ticks update the tickers instantly and reach the SSE stream', async () => {
  FakeWS.last = null;
  const api = createCryptoApi({}, { ...quiet, fetch: mockFetch(healthyPlan()), WebSocket: FakeWS });
  const s = await serve(api);
  try {
    await fetch(`${s.base}/api/live/universe`); // starts the hub + opens the WebSocket
    await sleep(20);
    const ws = FakeWS.last;
    assert.ok(ws, 'websocket was opened');
    assert.ok(ws.sent.some((m) => m.method === 'SUBSCRIBE' && m.params.includes('!miniTicker@arr')));

    const ctrl = new AbortController();
    const res = await fetch(`${s.base}/api/live/stream/tickers`, { signal: ctrl.signal });
    assert.match(res.headers.get('content-type'), /text\/event-stream/);
    const sse = sseReader(res);
    const readUntil = sse.until;
    assert.ok(await readUntil(/event: tickers/), 'initial snapshot event');

    ws.push({ stream: '!miniTicker@arr', data: [{ e: '24hrMiniTicker', s: 'BTCUSDT', c: '123456.78', o: '100000', h: '130000', l: '99000', q: '5e9' }, { e: '24hrMiniTicker', s: 'NOTINLIST', c: '1', o: '1', h: '1', l: '1', q: '1' }] });
    assert.ok(await readUntil(/123456\.78/), 'pushed price arrives over SSE');
    assert.ok(!/NOTINLIST/.test(sse.buf));

    const rest = await (await fetch(`${s.base}/api/live/tickers`)).json();
    assert.equal(rest.transport, 'ws');
    assert.equal(rest.tickers.find((t) => t.symbol === 'BTCUSDT').price, 123456.78);
    ctrl.abort();
  } finally {
    api.close();
    await s.close();
  }
});

test('candle stream: kline pushed by the WebSocket is relayed (throttled) and the stream is subscribed / released', async () => {
  FakeWS.last = null;
  const api = createCryptoApi({}, { ...quiet, fetch: mockFetch(healthyPlan()), WebSocket: FakeWS });
  const s = await serve(api);
  try {
    await fetch(`${s.base}/api/live/universe`);
    await sleep(20);
    const ws = FakeWS.last;
    const ctrl = new AbortController();
    const res = await fetch(`${s.base}/api/live/stream/candles?symbol=BTCUSDT&interval=1m`, { signal: ctrl.signal });
    const sse = sseReader(res);
    const readUntil = sse.until;
    assert.ok(await readUntil(/event: hello/));
    assert.ok(ws.sent.some((m) => m.method === 'SUBSCRIBE' && m.params.includes('btcusdt@kline_1m')));

    const t = Math.floor(Date.now() / 60_000) * 60_000;
    for (let i = 0; i < 5; i++) ws.push({ stream: 'btcusdt@kline_1m', data: { e: 'kline', k: { t, s: 'BTCUSDT', i: '1m', o: '100', h: '101', l: '99', c: String(100 + i), q: '5000', x: false } } });
    assert.ok(await readUntil(/event: candle[\s\S]*"c":\[\d+,100,101,99,104,5000\]/), 'latest of the burst arrives');
    const events = sse.buf.split('event: candle').length - 1;
    assert.ok(events >= 1 && events <= 2, `burst of 5 was throttled (got ${events})`);

    ws.push({ stream: 'btcusdt@kline_1m', data: { e: 'kline', k: { t, s: 'BTCUSDT', i: '1m', o: '100', h: '101', l: '99', c: '100.5', q: '5100', x: true } } });
    assert.ok(await readUntil(/"closed":true/), 'closed flag is forwarded');

    ctrl.abort();
    await sleep(100);
    assert.ok(ws.sent.some((m) => m.method === 'UNSUBSCRIBE' && m.params.includes('btcusdt@kline_1m')), 'last viewer gone -> stream released');
    assert.equal(api.status().streams.candleSubscriptions, 0);
  } finally {
    api.close();
    await s.close();
  }
});

test('without WebSocket the candle stream still ticks from REST polling', async () => {
  let n = 0;
  const plan = healthyPlan();
  plan['data-api.binance.vision'] = (u) => {
    if (u.pathname === '/api/v3/ticker/24hr') return binanceTickers();
    n++;
    return binanceKlines(u.searchParams.get('interval'), 10, 107 + n); // price moves on every REST call
  };
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch(plan) });
  const s = await serve(api);
  try {
    await fetch(`${s.base}/api/live/universe`);
    const ctrl = new AbortController();
    const res = await fetch(`${s.base}/api/live/stream/candles?symbol=BTCUSDT&interval=1m`, { signal: ctrl.signal });
    const sse = sseReader(res);
    assert.ok(await sse.until(/event: candle/, 7000));
    ctrl.abort();
  } finally {
    api.close();
    await s.close();
  }
});

test('status reports exchanges, transport and universe', async () => {
  const api = createCryptoApi({ LIVE_WS: '0' }, { ...quiet, fetch: mockFetch(healthyPlan()) });
  const s = await serve(api);
  try {
    await fetch(`${s.base}/api/live/universe`);
    const st = await (await fetch(`${s.base}/api/live/status`)).json();
    assert.equal(st.universe.count, 60);
    assert.equal(st.transport, 'rest');
    assert.deepEqual(st.exchanges.map((e) => e.id), ['binance', 'bybit', 'okx', 'gate.io']);
  } finally {
    api.close();
    await s.close();
  }
});
