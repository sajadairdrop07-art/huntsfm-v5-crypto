import type { Candle, TickerInfo } from '@/types';
import btc1m from './btc-1m.json';
import eth1m from './eth-1m.json';
import sol1m from './sol-1m.json';
import btc5m from './btc-5m.json';
import btc15m from './btc-15m.json';
import btc4h from './btc-4h.json';
import btc1d from './btc-1d.json';
import hourly1h from './hourly-1h.json';

type Row = [number, number, number, number, number, number];
interface Bundle {
  candles: Row[];
  asOf: number;
}

export const SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'DOGEUSDT'] as const;

const bundles: Record<string, Bundle> = {
  'BTCUSDT-1m': btc1m as Bundle,
  'ETHUSDT-1m': eth1m as Bundle,
  'SOLUSDT-1m': sol1m as Bundle,
  'BTCUSDT-5m': btc5m as Bundle,
  'BTCUSDT-15m': btc15m as Bundle,
  'BTCUSDT-4h': btc4h as Bundle,
  'BTCUSDT-1d': btc1d as Bundle,
};

const hourlyMap = hourly1h as unknown as Record<string, { candles: Row[] }>;

export function hasBundle(symbol: string, interval: string): boolean {
  return !!bundles[`${symbol}-${interval}`] || (interval === '1h' && !!hourlyMap[symbol]);
}

export function getBundle(symbol: string, interval: string): Candle[] {
  const raw = bundles[`${symbol}-${interval}`]?.candles ?? (interval === '1h' ? hourlyMap[symbol]?.candles : null);
  if (!raw) return [];
  return raw.map(([t, o, h, l, c, v]) => ({ t, o, h, l, c, v }));
}

export function bundleAsOf(symbol: string, interval: string): number | null {
  if (bundles[`${symbol}-${interval}`]) return bundles[`${symbol}-${interval}`].asOf;
  const rows = hourlyMap[symbol]?.candles;
  if (interval === '1h' && rows?.length) return rows[rows.length - 1][0];
  return null;
}

/** derive pseudo-24h tickers from bundled hourly data (offline fallback) */
export function fallbackTickers(): TickerInfo[] {
  return SYMBOLS.map((s) => {
    const cs = getBundle(s, '1h');
    if (cs.length < 2) {
      return { symbol: s, price: 0, changePct: 0, high: 0, low: 0, volume: 0 };
    }
    const last24 = cs.slice(-25);
    const cur = cs[cs.length - 1];
    const ref = last24[0];
    return {
      symbol: s,
      price: cur.c,
      changePct: ((cur.c - ref.c) / ref.c) * 100,
      high: Math.max(...last24.map((c) => c.h)),
      low: Math.min(...last24.map((c) => c.l)),
      volume: last24.reduce((sum, c) => sum + c.v, 0),
    };
  });
}
