import { useEffect, useMemo, useState } from 'react';
import type { Candle, Coin, CoinTicker, ConnState, TickerInfo } from '@/types';
import { bundleAsOf, fallbackTickers, getBundle, SYMBOLS } from '@/data/bundles';
import {
  applyCandle,
  fetchCandles,
  fetchTickers,
  fetchUniverse,
  INTERVAL_MS,
  mergeCandles,
  openCandleStream,
  openTickerStream,
  sameTail,
  type StreamHandle,
  type Transport,
} from '@/lib/liveCrypto';

const REST_POLL_FAST_MS = 3_000; // chart REST polling while the real-time stream is down
const REST_POLL_SLOW_MS = 20_000; // reconcile / back-fill while the stream is up
const MAX_CANDLES = 1500;
const GOOD_FOR_MS = 45_000; // no successful answer for this long => "stale"
const DEAD_AFTER_MS = 120_000; // ... => "offline"
const UNIVERSE_KEY = 'huntsfm.universe.v1';

interface MarketView {
  /** everything, including the still-forming candle (for the chart) */
  candles: Candle[];
  /** only closed candles (for signals / structure / backtest, so nothing repaints) */
  closed: Candle[];
  /** changes only when the dataset is replaced (symbol/interval/snapshot -> live) */
  key: string;
}

function buildView(candles: Candle[], ms: number, key: string, prev?: MarketView): MarketView {
  const last = candles[candles.length - 1];
  const forming = !!last && last.t + ms > Date.now();
  const closed = forming ? candles.slice(0, -1) : candles;
  if (prev && prev.key === key && prev.closed.length === closed.length && closed.length > 0) {
    const a = prev.closed[prev.closed.length - 1];
    const b = closed[closed.length - 1];
    if (a.t === b.t && a.c === b.c) return { candles, closed: prev.closed, key };
  }
  return { candles, closed, key };
}

/**
 * Live candles of one coin.
 * Shows the bundled snapshot instantly when there is one (BTC/ETH/SOL ...), then replaces it with the exchange history
 * from /api/live/candles and keeps it real time through a Server-Sent-Events stream of the forming candle. A slow REST
 * poll back-fills gaps (hidden tab, reconnects); when the stream is down the poll speeds up to 3 s, so the chart is
 * never frozen. If the server is unreachable the snapshot stays on screen and the connection state says so.
 */
export function useMarketData(symbol: string, interval: string) {
  const [view, setView] = useState<MarketView>(() => ({ candles: [], closed: [], key: 'init' }));
  const [conn, setConn] = useState<ConnState>('connecting');
  const [lastUpdate, setLastUpdate] = useState<number>(Date.now());
  const [asOf, setAsOf] = useState<number | null>(null);
  const [source, setSource] = useState<string | null>(null);
  const [transport, setTransport] = useState<Transport>('rest');

  useEffect(() => {
    const ms = INTERVAL_MS[interval] ?? 60_000;
    const bundle = getBundle(symbol, interval);
    const bundleTime = bundleAsOf(symbol, interval);

    let epoch = 0;
    let current: Candle[] = bundle;
    let haveFull = false;
    let lastSource: string | null = null;
    let lastGood = 0; // last time anything valid arrived (REST answer or pushed candle)
    let sseOpen = false;
    let serverWs = false; // the server itself gets its prices over a WebSocket (not REST polling)
    let failures = 0;
    let stopped = false;
    let timer: number | undefined;
    let sse: StreamHandle | null = null;
    let ctrl = new AbortController();
    const keyOf = () => `${symbol}|${interval}|${epoch}`;

    setView(buildView(bundle, ms, keyOf()));
    setAsOf(bundleTime);
    setLastUpdate(bundleTime ?? Date.now());
    setConn('connecting');
    setSource(null);
    setTransport('rest');

    const publish = (next: Candle[], replaced: boolean) => {
      next = next.length > MAX_CANDLES ? next.slice(-MAX_CANDLES) : next;
      if (replaced || next.length !== current.length || !sameTail(current, next)) {
        current = next;
        const key = keyOf();
        setView((prev) => buildView(next, ms, key, prev));
      }
    };

    // "realtime" = pushed to us by the server AND the server is fed by an exchange WebSocket
    const applyTransport = () => setTransport(sseOpen && serverWs ? 'ws' : 'rest');

    const evalConn = (stale = false) => {
      const age = Date.now() - lastGood;
      setConn(stale || age > GOOD_FOR_MS ? (age > DEAD_AFTER_MS ? 'offline' : 'stale') : 'live');
    };

    const schedule = (delay: number) => {
      if (!stopped) {
        window.clearTimeout(timer);
        timer = window.setTimeout(tick, delay);
      }
    };

    const startStream = () => {
      if (stopped || sse || !haveFull) return;
      sse = openCandleStream(
        symbol,
        interval,
        (c) => {
          if (stopped || !haveFull) return;
          lastGood = Date.now();
          publish(applyCandle(current, c), false);
          setLastUpdate(lastGood);
          setConn('live');
        },
        (open) => {
          if (stopped) return;
          if (open !== sseOpen) {
            sseOpen = open;
            applyTransport();
            if (!open) schedule(500); // stream dropped: fall back to fast REST polling right away
          }
        },
      );
    };

    const stopStream = () => {
      sse?.close();
      sse = null;
      sseOpen = false;
    };

    async function tick() {
      if (stopped) return;
      if (document.hidden) {
        schedule(REST_POLL_SLOW_MS);
        return;
      }
      try {
        const sinceT = haveFull && current.length ? current[current.length - 1].t : undefined;
        const res = await fetchCandles(symbol, interval, ctrl.signal, sinceT);
        if (stopped) return;
        if (!res.candles.length) throw new Error('no candles');
        failures = 0;

        // another exchange took over under us: the series differ slightly, so reload the full history once
        if (haveFull && lastSource && res.source !== lastSource) {
          haveFull = false;
          lastSource = res.source;
          schedule(0);
          return;
        }
        lastSource = res.source;

        let replaced = false;
        let next: Candle[];
        if (!haveFull) {
          next = res.candles;
          haveFull = true;
          replaced = true;
          epoch += 1;
        } else {
          next = mergeCandles(current, res.candles);
        }
        publish(next, replaced);

        lastGood = Date.now();
        setLastUpdate(res.quoteTime ?? lastGood);
        setAsOf(null);
        setSource(res.source);
        serverWs = res.transport === 'ws';
        applyTransport();
        evalConn(res.stale);
        startStream();
        schedule(sseOpen ? REST_POLL_SLOW_MS : REST_POLL_FAST_MS);
      } catch (e) {
        if (stopped || (e instanceof DOMException && e.name === 'AbortError')) return;
        failures += 1;
        if (!haveFull) setConn(bundle.length ? 'snapshot' : 'offline');
        else evalConn(failures >= 3);
        schedule(Math.min(REST_POLL_FAST_MS * 2 ** Math.min(failures, 4), 30_000));
      }
    }

    const onVisibility = () => {
      if (stopped) return;
      if (document.hidden) {
        stopStream(); // do not hold a server connection for a tab nobody is looking at
        return;
      }
      schedule(0); // back-fill what was missed, then the stream is re-opened by tick()
    };
    document.addEventListener('visibilitychange', onVisibility);

    // the connection badge also has to age without any event arriving
    const watchdog = window.setInterval(() => {
      if (haveFull && !document.hidden) evalConn();
    }, 5_000);

    tick();
    return () => {
      stopped = true;
      ctrl.abort();
      ctrl = new AbortController();
      window.clearTimeout(timer);
      window.clearInterval(watchdog);
      document.removeEventListener('visibilitychange', onVisibility);
      stopStream();
    };
  }, [symbol, interval]);

  return {
    candles: view.candles,
    closedCandles: view.closed,
    datasetKey: view.key,
    conn,
    lastUpdate,
    asOf,
    source,
    transport,
  };
}

/* ------------------------------------------------------------------ universe + tickers */

const FALLBACK_NAMES: Record<string, string> = { BTC: 'Bitcoin', ETH: 'Ethereum', SOL: 'Solana', BNB: 'BNB', XRP: 'XRP', DOGE: 'Dogecoin' };

function fallbackCoins(): Coin[] {
  return SYMBOLS.map((s, i) => {
    const base = s.replace(/USDT$/, '');
    return { symbol: s, base, name: FALLBACK_NAMES[base] ?? base, rank: i + 1, mcapRank: i + 1, mcap: 0, image: '' };
  });
}

function loadCachedUniverse(): Coin[] | null {
  try {
    const j = JSON.parse(localStorage.getItem(UNIVERSE_KEY) ?? 'null') as { coins?: Coin[] } | null;
    return j?.coins?.length ? j.coins : null;
  } catch {
    return null;
  }
}

/**
 * The top coins by market cap with a live 24h ticker for every one of them.
 * Primary path: one Server-Sent-Events stream (~1 update/s for all coins). A watchdog falls back to REST when the
 * stream is silent, and the first paint comes from a REST call so the list never waits for the stream.
 */
export function useTickers() {
  const [coins, setCoins] = useState<Coin[]>(() => loadCachedUniverse() ?? fallbackCoins());
  const [universeLive, setUniverseLive] = useState(false);
  const [rankSource, setRankSource] = useState<string | null>(null);
  const [raw, setRaw] = useState<TickerInfo[]>(() => fallbackTickers());
  const [live, setLive] = useState(false);
  const [transport, setTransport] = useState<Transport>('rest');
  const [tickerSource, setTickerSource] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState(0);

  // universe: now, then every 10 minutes (retry sooner on failure)
  useEffect(() => {
    let stopped = false;
    let timer: number | undefined;
    const ctrl = new AbortController();
    const run = async () => {
      let next = 10 * 60_000;
      try {
        const u = await fetchUniverse(ctrl.signal);
        if (stopped) return;
        if (u.coins.length) {
          setCoins(u.coins);
          setUniverseLive(true);
          setRankSource(u.rankSource);
          try {
            localStorage.setItem(UNIVERSE_KEY, JSON.stringify({ coins: u.coins }));
          } catch {
            /* private mode / quota: not needed */
          }
        }
      } catch {
        if (stopped) return;
        next = 15_000;
      }
      if (!stopped) timer = window.setTimeout(run, next);
    };
    run();
    return () => {
      stopped = true;
      ctrl.abort();
      window.clearTimeout(timer);
    };
  }, []);

  // tickers: stream + REST safety net
  useEffect(() => {
    let stopped = false;
    let lastMsg = 0;
    let sse: StreamHandle | null = null;
    let timer: number | undefined;
    const ctrl = new AbortController();

    const accept = (s: { tickers: TickerInfo[]; source: string | null; transport: Transport; t: number }) => {
      if (stopped || !s.tickers.length) return;
      lastMsg = Date.now();
      setRaw(s.tickers);
      setLive(true);
      setTransport(s.transport);
      setTickerSource(s.source);
      setUpdatedAt(lastMsg);
    };

    const restOnce = async () => {
      try {
        accept(await fetchTickers(ctrl.signal));
      } catch {
        if (!stopped && Date.now() - lastMsg > 30_000) setLive(false);
      }
    };

    const open = () => {
      if (stopped || sse || document.hidden) return;
      sse = openTickerStream(accept, () => {});
    };
    const close = () => {
      sse?.close();
      sse = null;
    };

    restOnce();
    open();
    // silent stream (proxy buffering, server restart, blocked SSE) -> poll REST every 5 s until it speaks again
    const watchdog = window.setInterval(() => {
      if (document.hidden) return;
      if (Date.now() - lastMsg > 6_000) void restOnce();
    }, 5_000);
    const onVisibility = () => {
      if (document.hidden) {
        close();
      } else {
        open();
        void restOnce();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      stopped = true;
      ctrl.abort();
      window.clearTimeout(timer);
      window.clearInterval(watchdog);
      document.removeEventListener('visibilitychange', onVisibility);
      close();
    };
  }, []);

  const tickers = useMemo<CoinTicker[]>(() => {
    const by = new Map(raw.map((t) => [t.symbol, t]));
    const out: CoinTicker[] = [];
    for (const c of coins) {
      const t = by.get(c.symbol);
      if (t && t.price > 0) out.push({ ...t, base: c.base, name: c.name, rank: c.rank, mcap: c.mcap, image: c.image });
    }
    return out;
  }, [raw, coins]);

  return { coins, tickers, live, transport, tickerSource, universeLive, rankSource, updatedAt };
}
