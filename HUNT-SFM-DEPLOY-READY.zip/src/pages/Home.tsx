import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { toast, Toaster } from 'sonner';
import { BookOpen, FlaskConical, Waypoints } from 'lucide-react';
import type { StrategyKind } from '@/types';
import { useMarketData, useTickers } from '@/hooks/useMarketData';
import { evalNow, STRATEGY_META } from '@/lib/strategies';
import { analyzeSmartMoney } from '@/lib/smartMoney';
import { decimalsFor, fmtDateTime, fmtPct, fmtPrice, fmtTimeSec, symbolBase } from '@/lib/format';
import { INTERVAL_MS, INTERVALS } from '@/lib/liveCrypto';
import { Header } from '@/components/Header';
import { TickerBar } from '@/components/TickerBar';
import { SidebarControls } from '@/components/SidebarControls';
import { ChartPanel } from '@/components/ChartPanel';
import { SignalPanel } from '@/components/SignalPanel';
import { RiskPanel } from '@/components/RiskPanel';
import { BacktestPanel } from '@/components/BacktestPanel';
import { SmartPanel } from '@/components/SmartPanel';

type Tab = 'backtest' | 'structure' | 'guide';

const SOURCE_LABEL: Record<string, string> = { binance: 'Binance', bybit: 'Bybit', okx: 'OKX', 'gate.io': 'Gate.io' };

const GUIDE: { title: string; body: string }[] = [
  {
    title: 'RTM — Read The Market',
    body: 'در RTM زون فقط محل برگشت قبلی نیست؛ باید دلیل حرکت را بخوانید: کندل‌های پایه، کندل مومنتوم، سرعت خروج از زون و باقی‌ماندن سفارش‌های انجام‌نشده. زون قوی‌تر است که خروج از آن تمیزتر، سریع‌تر و با دامنه بیشتر باشد. ورود یا با لیمیت در لبه زون است یا با بستن کندل تأیید پس از بازگشت قیمت.',
  },
  {
    title: 'SMC — ساختار، نقدینگی، Order Block و FVG',
    body: 'ساختار با شکست Swing High/Low خوانده می‌شود: BOS ادامه روند و CHoCH تغییر ماهیت است. Order Block آخرین کندل مخالف قبل از حرکت ایجادکننده ساختار است و FVG گپ ناشی از عدم تعادل خریدار/فروشنده. قیمت معمولاً برای جمع‌کردن نقدینگی به پشت سقف/کف قبلی می‌رود و بعد مسیر اصلی را آغاز می‌کند.',
  },
  {
    title: 'فیلترهای سیگنال دقیق',
    body: 'سیگنال فقط وقتی صادر می‌شود که ساختار هم‌جهت، زون فعال، تست/ریتست زون و بستن کندل تأیید وجود داشته باشد. خرید در بخش پایین محدوده و فروش در بخش بالای محدوده اولویت دارد. جلسه لندن/نیویورک امتیاز بیشتری می‌گیرد و زونی که قیمت از لبه دور آن عبور کند باطل است.',
  },
  {
    title: 'حد ضرر و هدف',
    body: 'حد ضرر پشت لبه دور زون یا سایه سوییپ قرار می‌گیرد، نه داخل بدنه کندل. هدف اول معمولاً نقدینگی مقابل و هدف دوم امتداد حرکت است. اگر فاصله تا نقدینگی کمتر از حداقل R:R منطقی باشد، سیستم هدف را با ضریب R تنظیم می‌کند. بک‌تست برای کالیبراسیون است، نه تضمین سود.',
  },
];

const SEL_KEY = 'huntsfm.sel.v1';
const FAV_KEY = 'huntsfm.fav.v1';
const DEFAULT_SYMBOL = 'BTCUSDT';

function readSel(): { symbol: string; interval: string } {
  try {
    const j = JSON.parse(localStorage.getItem(SEL_KEY) ?? 'null') as { symbol?: string; interval?: string } | null;
    if (j?.symbol && /^[A-Z0-9]{1,20}USDT$/.test(j.symbol) && j.interval && (INTERVALS as readonly string[]).includes(j.interval)) return { symbol: j.symbol, interval: j.interval };
  } catch {
    /* no storage: defaults */
  }
  return { symbol: DEFAULT_SYMBOL, interval: '15m' };
}

function readFavs(): string[] {
  try {
    const j = JSON.parse(localStorage.getItem(FAV_KEY) ?? '[]') as unknown;
    return Array.isArray(j) ? j.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

/** the price scale of a dataset is fixed from its median close, so the axis does not flip while a coin crosses a threshold */
function datasetDecimals(candles: { c: number }[]): number {
  if (!candles.length) return 2;
  const tail = candles.slice(-200).map((c) => c.c).sort((a, b) => a - b);
  return decimalsFor(tail[Math.floor(tail.length / 2)]);
}

export default function Home() {
  const [{ symbol: savedSymbol, interval }, setSel] = useState(readSel);
  const [favorites, setFavorites] = useState<string[]>(readFavs);
  const [strategy, setStrategy] = useState<StrategyKind>('rtmSmc');
  const [showEma, setShowEma] = useState(false);
  const [showVolume, setShowVolume] = useState(false);
  const [tab, setTab] = useState<Tab>('backtest');

  const { coins, tickers, live: tickersLive, transport: tickerTransport, universeLive } = useTickers();
  // a saved coin that dropped out of the top list (or was never in it) falls back to BTC
  const symbol = universeLive && coins.length && !coins.some((c) => c.symbol === savedSymbol) ? DEFAULT_SYMBOL : savedSymbol;
  const { candles, closedCandles, datasetKey, conn, lastUpdate, asOf, source, transport } = useMarketData(symbol, interval);
  const coin = coins.find((c) => c.symbol === symbol);
  const ticker = tickers.find((t) => t.symbol === symbol);
  const decimals = useMemo(() => datasetDecimals(closedCandles.length ? closedCandles : candles), [closedCandles, candles]);
  const isLive = conn === 'live' || conn === 'stale';
  const sourceLabel = source ? (SOURCE_LABEL[source] ?? source) : 'منبع زنده';

  const setSymbol = useCallback((s: string) => setSel((p) => (p.symbol === s ? p : { ...p, symbol: s })), []);
  const setInterval_ = useCallback((i: string) => setSel((p) => (p.interval === i ? p : { ...p, interval: i })), []);
  const toggleFavorite = useCallback((s: string) => {
    setFavorites((prev) => {
      const next = prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s];
      save(FAV_KEY, next);
      return next;
    });
  }, []);
  useEffect(() => save(SEL_KEY, { symbol, interval }), [symbol, interval]);
  // signals/structure/backtest only see CLOSED candles, so a live forming candle can never repaint a signal
  const analysis = useMemo(() => analyzeSmartMoney(closedCandles), [closedCandles]);
  const signals = analysis.signals;
  const events = analysis.markers;
  const current = useMemo(() => {
    const s = signals.length ? signals[signals.length - 1] : null;
    if (s && s.dir) return s;
    return evalNow(strategy, closedCandles);
  }, [signals, strategy, closedCandles]);

  const prevKey = useRef<{ ds: string; key: string } | null>(null);
  useEffect(() => {
    const key = current.dir ? `${symbol}-${strategy}-${current.dir}-${current.time}` : '';
    const prev = prevKey.current;
    // a new dataset (symbol/interval change, snapshot -> live) is a silent baseline, not a new signal
    if (key && prev && prev.ds === datasetKey && prev.key !== key) {
      toast.success(`سیگنال ${current.dir === 'long' ? 'خرید' : 'فروش'} ${symbolBase(symbol)}`, {
        description: `ورود ${current.entry != null ? fmtPrice(current.entry, decimals) : '—'} · حد ضرر ${current.sl != null ? fmtPrice(current.sl, decimals) : '—'} · RTM/SMC`,
      });
    }
    prevKey.current = { ds: datasetKey, key };
  }, [current, symbol, strategy, decimals, datasetKey]);

  const last = candles.length ? candles[candles.length - 1] : null;

  return (
    <div className="scanlines flex min-h-100dvh flex-col">
      <Toaster theme="dark" position="top-center" richColors />
      <Header conn={conn} transport={transport} />
      <TickerBar tickers={tickers} />

      <div className="grid flex-1 grid-cols-1 items-start gap-3 p-3 lg:grid-cols-[264px_minmax(0,1fr)_316px]">
        <aside className="panel order-2 lg:order-1 lg:h-full">
          <SidebarControls
            symbol={symbol}
            setSymbol={setSymbol}
            interval={interval}
            setInterval={setInterval_}
            strategy={strategy}
            setStrategy={setStrategy}
            tickers={tickers}
            favorites={favorites}
            toggleFavorite={toggleFavorite}
            universeCount={coins.length}
            showEma={showEma}
            setShowEma={setShowEma}
            showVolume={showVolume}
            setShowVolume={setShowVolume}
          />
        </aside>

        <main className="panel order-1 flex min-h-0 flex-col lg:order-2">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b hairline px-3 py-2">
            <div className="flex items-center gap-3">
              <h2 className="text-base font-extrabold text-slate-100">
                {symbolBase(symbol)}
                <span className="label-en ml-2 text-[10px] font-normal text-slate-500">USDT{coin ? ` · ${coin.name}` : ''}</span>
              </h2>
              {last && (
                <span className={`num text-sm font-bold ${last.c >= last.o ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {fmtPrice(last.c, decimals)}
                </span>
              )}
              {ticker && (
                <span className={`num text-[11px] ${ticker.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{fmtPct(ticker.changePct)} · ۲۴h</span>
              )}
            </div>
            <div className="num flex flex-wrap items-center gap-3 text-[10px] text-slate-500">
              <span>{interval}</span>
              <span>{candles.length.toLocaleString('en-US')} کندل</span>
              {isLive && (
                <span className="text-emerald-400">
                  LIVE · {sourceLabel}{transport === 'ws' ? ' · لحظه‌ای' : ' · هر چند ثانیه'}
                </span>
              )}
              <span>{isLive ? 'آخرین به‌روزرسانی' : 'داده تا'} {fmtTimeSec(lastUpdate)}</span>
            </div>
          </div>

          <div className="min-h-[380px] flex-1 p-1">
            {candles.length ? (
              <ChartPanel
                candles={candles}
                signals={signals}
                events={events}
                strategy={strategy}
                showEma={showEma}
                showVolume={showVolume}
                decimals={decimals}
                datasetKey={datasetKey}
                intervalMs={INTERVAL_MS[interval]}
              />
            ) : (
              <div className="flex h-full items-center justify-center text-[12px] text-slate-500">
                {conn === 'connecting' ? 'در حال دریافت کندل‌ها از صرافی…' : 'داده‌ای برای این ارز/تایم‌فریم دریافت نشد؛ اتصال سرور را بررسی کنید.'}
              </div>
            )}
          </div>

          <div className="border-t hairline">
            <div className="flex items-center gap-1 border-b hairline px-2 pt-2">
              <TabBtn active={tab === 'backtest'} onClick={() => setTab('backtest')} icon={<FlaskConical className="h-3.5 w-3.5" />} label="بک‌تست" />
              <TabBtn active={tab === 'structure'} onClick={() => setTab('structure')} icon={<Waypoints className="h-3.5 w-3.5" />} label="ساختار و زون‌ها" />
              <TabBtn active={tab === 'guide'} onClick={() => setTab('guide')} icon={<BookOpen className="h-3.5 w-3.5" />} label="راهنمای RTM/SMC" />
            </div>
            <div className="h-[330px]">
              {tab === 'backtest' && <BacktestPanel key={`${strategy}-${symbol}-${interval}`} candles={closedCandles} strategy={strategy} />}
              {tab === 'structure' && <SmartPanel candles={closedCandles} interval={interval} analysis={analysis} />}
              {tab === 'guide' && (
                <div className="grid h-full grid-cols-1 gap-2 overflow-y-auto p-4 md:grid-cols-2">
                  {GUIDE.map((g) => (
                    <article key={g.title} className="rounded border hairline bg-[#0a0f1c] p-3">
                      <h3 className="mb-1 text-[12px] font-bold text-cyan-200">{g.title}</h3>
                      <p className="text-[11px] leading-5 text-slate-400">{g.body}</p>
                    </article>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>

        <aside className="order-3 flex flex-col gap-3 lg:h-full">
          <div className="panel min-h-[300px] flex-1">
            <SignalPanel signal={current} strategyLabel={STRATEGY_META[strategy].label} />
          </div>
          <div className="panel">
            <RiskPanel signal={current} symbol={symbol} />
          </div>
        </aside>
      </div>

      <footer className="border-t hairline px-4 py-2 text-center text-[10px] leading-4 text-slate-600">
        HUNT SFM یک ابزار تحلیل ساختار بازار است، نه سیگنال تضمینی یا مشاور سرمایه‌گذاری. در معاملات ارز دیجیتال، به‌ویژه با اهرم، امکان از دست رفتن بخشی یا کل سرمایه وجود دارد.{' '}
        {isLive
          ? `داده زنده از ${sourceLabel}${transport === 'ws' ? ' (WebSocket، لحظه‌ای)' : ' (دریافت دوره‌ای هر چند ثانیه)'}؛ قیمت‌ها ممکن است با صرافی شما اندکی تفاوت داشته باشند. سیگنال‌ها فقط روی کندل بسته‌شده محاسبه می‌شوند.`
          : `داده محلی${asOf ? ` تا ${fmtDateTime(asOf)}` : ''}؛ اتصال زنده برقرار نیست و ممکن است نسبت به بازار تأخیر داشته باشد.`}
        {tickersLive ? ` لیست ${coins.length} ارز برتر بازار${tickerTransport === 'ws' ? ' لحظه‌ای' : ''} به‌روز می‌شود.` : ''}
      </footer>
    </div>
  );
}

function TabBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`focus-ring flex items-center gap-1.5 rounded-t border-b-2 px-3 py-2 text-[11px] transition-colors ${
        active
          ? 'border-cyan-400 bg-cyan-500/5 text-cyan-300'
          : 'border-transparent text-slate-500 hover:text-slate-300'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
