import { memo } from 'react';
import type { CoinTicker } from '@/types';
import { fmtCompact, fmtPct, fmtPrice } from '@/lib/format';

const MARQUEE_COINS = 30;

export const TickerBar = memo(function TickerBar({ tickers }: { tickers: CoinTicker[] }) {
  const top = tickers.slice(0, MARQUEE_COINS);
  const items = [...top, ...top]; // duplicated for a seamless marquee
  return (
    <div className="relative overflow-hidden border-y hairline bg-[#0a0f1c]" aria-label="نمایشگر زنده قیمت‌ها">
      <div className="ticker-track py-1.5" dir="ltr" style={{ animationDuration: `${Math.max(40, top.length * 3)}s` }}>
        {items.map((t, i) => {
          const up = t.changePct >= 0;
          return (
            <span key={`${t.symbol}-${i}`} className="mx-4 inline-flex items-center gap-2 whitespace-nowrap text-[11px]">
              <span className="label-en text-[10px] text-cyan-300/80">{t.base}</span>
              <span className="num text-slate-200">{fmtPrice(t.price)}</span>
              <span className={`num ${up ? 'text-emerald-400' : 'text-rose-400'}`}>{fmtPct(t.changePct)}</span>
              <span className="num text-slate-500">V {fmtCompact(t.volume)}</span>
              <span className="text-slate-700">/</span>
            </span>
          );
        })}
      </div>
    </div>
  );
});
