import { Crosshair, Layers, ShieldAlert, Waypoints } from 'lucide-react';
import type { Candle } from '@/types';
import type { SmartAnalysis } from '@/lib/smartMoney';
import { fmtPrice, fmtTime } from '@/lib/format';
import { decimalsFor } from '@/lib/format';

interface Props {
  candles: Candle[];
  interval: string;
  analysis: SmartAnalysis;
}

export function SmartPanel({ candles, interval, analysis }: Props) {
  const last = candles[candles.length - 1];
  const decimals = decimalsFor(last?.c ?? 0);
  const bias = analysis.trend === 'long' ? 'صعودی' : analysis.trend === 'short' ? 'نزولی' : 'خنثی';
  const biasCls = analysis.trend === 'long' ? 'text-emerald-400' : analysis.trend === 'short' ? 'text-rose-400' : 'text-slate-400';
  const ratioPct = Math.round(analysis.premiumRatio * 100);
  const location = last && last.c <= (analysis.rangeHigh + analysis.rangeLow) / 2 ? 'دیسکانت' : 'پریمیوم';

  return (
    <div className="grid h-full grid-cols-1 gap-3 overflow-y-auto p-4 lg:grid-cols-3">
      <section className="panel-2 p-3">
        <h3 className="mb-2 flex items-center gap-2 text-[11px] font-bold text-slate-300">
          <Waypoints className="h-3.5 w-3.5 text-cyan-300" />
          گرایش و موقعیت قیمت
        </h3>
        <div className="rounded border hairline bg-[#0a0f1c] p-3">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-500">جهت ساختار</span>
            <span className={`font-bold ${biasCls}`}>{bias}</span>
          </div>
          <div className="mt-3">
            <div className="num mb-1 flex justify-between text-[10px] text-slate-500">
              <span>Discount</span>
              <span>{ratioPct}٪</span>
              <span>Premium</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-slate-800">
              <div
                className={`h-full ${analysis.trend === 'short' ? 'bg-rose-400' : 'bg-emerald-400'}`}
                style={{ width: `${Math.max(2, Math.min(98, ratioPct))}%` }}
              />
            </div>
            <p className="mt-2 text-[10px] leading-4 text-slate-500">
              قیمت فعلی در بخش {location} محدوده اخیر است. خرید در دیسکانت و فروش در پریمیوم فیلتر شده است.
            </p>
          </div>
          <div className="num mt-3 space-y-1 border-t hairline pt-2 text-[11px]">
            <Row k="سقف محدوده" v={fmtPrice(analysis.rangeHigh, decimals)} />
            <Row k="کف محدوده" v={fmtPrice(analysis.rangeLow, decimals)} />
            <Row k="تایم‌فریم" v={interval} />
          </div>
        </div>
      </section>

      <section className="panel-2 p-3">
        <h3 className="mb-2 flex items-center gap-2 text-[11px] font-bold text-slate-300">
          <Layers className="h-3.5 w-3.5 text-fuchsia-300" />
          زون‌های فعال ({analysis.zones.length})
        </h3>
        {analysis.zones.length === 0 ? (
          <p className="text-[11px] leading-5 text-slate-500">
            زون فعالی که هنوز استفاده نشده باشد پیدا نشد. این وضعیت معمولاً یعنی بازار از زون‌ها عبور کرده یا داده برای ساختار جدید کافی نیست.
          </p>
        ) : (
          <ul className="space-y-1.5">
            {analysis.zones.map((z) => {
              const distance = last ? (z.dir === 'long' ? last.c - z.top : z.bottom - last.c) : 0;
              const touched = last ? last.l <= z.top && last.h >= z.bottom : false;
              return (
                <li key={z.id} className="rounded border hairline bg-[#0a0f1c] p-2 text-[11px]">
                  <div className="flex items-center justify-between">
                    <span className={z.dir === 'long' ? 'text-emerald-400' : 'text-rose-400'}>
                      {z.kind === 'OB' ? 'Order Block' : 'FVG'} {z.dir === 'long' ? 'تقاضا' : 'عرضه'}
                    </span>
                    <span className="num text-slate-500">قدرت {z.strength.toFixed(1)}</span>
                  </div>
                  <div className="num mt-1 flex justify-between text-slate-400">
                    <span>{fmtPrice(z.bottom, decimals)} — {fmtPrice(z.top, decimals)}</span>
                    <span>{touched ? 'در حال تست' : `${last ? ((Math.abs(distance) / last.c) * 100).toFixed(2) : '0'}٪`}</span>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section className="panel-2 p-3">
        <h3 className="mb-2 flex items-center gap-2 text-[11px] font-bold text-slate-300">
          <Crosshair className="h-3.5 w-3.5 text-amber-300" />
          آخرین ساختارها
        </h3>
        {analysis.structures.length === 0 ? (
          <p className="text-[11px] leading-5 text-slate-500">هنوز BOS/CHoCH معتبر در داده فعلی تشکیل نشده است.</p>
        ) : (
          <ul className="space-y-1.5">
            {analysis.structures.map((s, idx) => (
              <li key={`${s.t}-${idx}`} className="flex items-center justify-between rounded border hairline bg-[#0a0f1c] px-2.5 py-1.5 text-[11px]">
                <span className={s.dir === 'long' ? 'text-emerald-400' : 'text-rose-400'}>
                  {s.kind === 'CHoCH' ? 'تغییر ماهیت' : 'شکست ساختار'} {s.dir === 'long' ? 'صعودی' : 'نزولی'}
                </span>
                <span className="num text-slate-500">{fmtTime(s.t)}</span>
                <span className="num text-slate-300">{fmtPrice(s.price, decimals)}</span>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-2 flex items-start gap-1.5 text-[10px] leading-4 text-slate-600">
          <ShieldAlert className="mt-0.5 h-3 w-3 shrink-0 text-amber-400/70" />
          عبور قیمت از لبه دور زون، باطل‌شدن آن زون است؛ سیگنال فقط با بستن کندل تأیید ثبت می‌شود.
        </p>
      </section>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-500">{k}</span>
      <span className="text-slate-200">{v}</span>
    </div>
  );
}
