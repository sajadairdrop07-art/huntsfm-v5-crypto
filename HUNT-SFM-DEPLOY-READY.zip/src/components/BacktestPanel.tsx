import { useEffect, useRef, useState, type ReactNode } from 'react';
import { LineSeries, ColorType, createChart, type UTCTimestamp } from 'lightweight-charts';
import { FlaskConical } from 'lucide-react';
import type { BacktestResult, Candle, StrategyKind } from '@/types';
import { runBacktest } from '@/lib/backtest';
import { fmtDateTime, fmtPct, fmtPrice, fmtTime } from '@/lib/format';

interface Props {
  candles: Candle[];
  strategy: StrategyKind;
}

export function BacktestPanel({ candles, strategy }: Props) {
  const [fee, setFee] = useState(0.05);
  const [rr, setRr] = useState(0); // 0 = use strategy default
  const [result, setResult] = useState<BacktestResult | null>(null);
  const [ranAt, setRanAt] = useState<number | null>(null);
  const eqHost = useRef<HTMLDivElement>(null);

  const run = () => {
    const r = runBacktest(strategy, candles, { feePct: fee, riskReward: rr || undefined });
    setResult(r);
    setRanAt(Date.now());
  };

  // equity chart
  useEffect(() => {
    if (!result || !eqHost.current) return;
    const host = eqHost.current;
    host.innerHTML = '';
    const chart = createChart(host, {
      autoSize: true,
      height: 140,
      layout: { background: { type: ColorType.Solid, color: 'transparent' }, textColor: '#7e8db0', fontFamily: "'JetBrains Mono', monospace", fontSize: 10, attributionLogo: false },
      grid: { vertLines: { visible: false }, horzLines: { color: 'rgba(26,37,64,0.4)' } },
      rightPriceScale: { borderColor: '#1a2540' },
      timeScale: { borderColor: '#1a2540', timeVisible: true },
    });
    const line = chart.addSeries(LineSeries, {
      color: result.netR >= 0 ? '#34d399' : '#f87171',
      lineWidth: 2,
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false,
    });
    line.setData(
      result.equity.map((p) => ({ time: Math.floor(p.t / 1000) as UTCTimestamp, value: p.r }))
    );
    chart.timeScale().fitContent();
    return () => chart.remove();
  }, [result]);

  return (
    <div className="flex h-full flex-col gap-3 p-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="label-en text-[10px] text-slate-500">BACKTEST / بک‌تست</h2>
          <p className="mt-1 text-[11px] text-slate-400">
            اجرای کورانه روی {candles.length.toLocaleString('en-US')} کندل؛ ورود در باز شدن کندل بعد، هزینه رفت‌وبرگشت و خروج زمانی
          </p>
        </div>
        <div className="flex items-end gap-3">
          <label className="block">
            <span className="mb-1 block text-[10px] text-slate-500">هزینه رفت‌وبرگشت (٪)</span>
            <input
              type="number" step={0.01} min={0} max={1} value={fee}
              onChange={(e) => setFee(Number(e.target.value))}
              className="focus-ring num w-20 rounded border hairline bg-[#0a0f1c] px-2 py-1.5 text-sm text-slate-200" dir="ltr"
            />
          </label>
          <label className="block">
            <span className="mb-1 block text-[10px] text-slate-500">R:R ثابت (۰=خودکار)</span>
            <input
              type="number" step={0.5} min={0} max={6} value={rr}
              onChange={(e) => setRr(Number(e.target.value))}
              className="focus-ring num w-20 rounded border hairline bg-[#0a0f1c] px-2 py-1.5 text-sm text-slate-200" dir="ltr"
            />
          </label>
          <button
            onClick={run}
            className="focus-ring flex items-center gap-2 rounded bg-cyan-500/90 px-4 py-1.5 text-sm font-bold text-[#050810] transition-colors hover:bg-cyan-400"
          >
            <FlaskConical className="h-4 w-4" />
            اجرای بک‌تست
          </button>
        </div>
      </div>

      {!result && (
        <div className="flex flex-1 items-center justify-center rounded border border-dashed hairline p-8 text-center text-[12px] leading-6 text-slate-500">
          بک‌تست هنوز اجرا نشده است.
          <br />
          نتایج شامل نرخ برد، فاکتور سود، حداکثر افت سرمایه و منحنی سود خواهد بود.
        </div>
      )}

      {result && (
        <>
          <div className="grid grid-cols-3 gap-2 md:grid-cols-6">
            <Stat l="معاملات" v={String(result.total)} />
            <Stat l="نرخ برد" v={result.winRate.toFixed(1) + '٪'} good={result.winRate >= 50} />
            <Stat
              l="فاکتور سود"
              v={result.profitFactor === Infinity ? '∞' : result.profitFactor.toFixed(2)}
              good={result.profitFactor >= 1}
            />
            <Stat l="خالص (R)" v={result.netR.toFixed(2)} good={result.netR >= 0} />
            <Stat l="میانگین R" v={result.avgR.toFixed(2)} good={result.avgR >= 0} />
            <Stat l="حداکثر افت" v={result.maxDrawdownR.toFixed(2) + 'R'} warn={result.maxDrawdownR > 5} />
          </div>

          <div className="panel overflow-hidden">
            <div className="border-b hairline px-3 py-1.5 text-[10px] text-slate-500">منحنی انباشته سود/زیان (واحد R)</div>
            <div ref={eqHost} className="h-[140px]" dir="ltr" />
          </div>

          <div className="min-h-0 flex-1 overflow-auto rounded border hairline">
            <table className="num w-full text-[11px]">
              <thead>
                <tr className="bg-[#0a0f1c] text-slate-500">
                  <Th>جهت</Th><Th>ورود</Th><Th>خروج</Th><Th>حاصل</Th><Th>٪</Th><Th>علت خروج</Th><Th>زمان</Th>
                </tr>
              </thead>
              <tbody>
                {result.trades.slice(-18).reverse().map((t, i) => (
                  <tr key={i} className="border-t hairline text-slate-300">
                    <Td cls={t.dir === 'long' ? 'text-emerald-400' : 'text-rose-400'}>{t.dir === 'long' ? 'خرید' : 'فروش'}</Td>
                    <Td>{fmtPrice(t.entry)}</Td>
                    <Td>{fmtPrice(t.exit)}</Td>
                    <Td cls={t.resultR > 0 ? 'text-emerald-400' : 'text-rose-400'}>{t.resultR.toFixed(2)}R</Td>
                    <Td cls={t.pnlPct > 0 ? 'text-emerald-400/80' : 'text-rose-400/80'}>{fmtPct(t.pnlPct)}</Td>
                    <Td>{t.exitReason === 'tp' ? 'حد سود' : t.exitReason === 'sl' ? 'حد ضرر' : 'زمان'}</Td>
                    <Td>{fmtTime(t.exitTime)}</Td>
                  </tr>
                ))}
              </tbody>
            </table>
            {result.trades.length === 0 && (
              <p className="p-4 text-center text-[11px] text-slate-500">
                هیچ معامله‌ای در این بازه و تایم‌فریم تشکیل نشد — تایم‌فریم/استراتژی دیگری را امتحان کنید.
              </p>
            )}
          </div>
          <p className="num text-[10px] text-slate-600">
            اجرا: {ranAt ? fmtDateTime(ranAt) : '—'} · اگر SL و TP در یک کندل لمس شوند، حالت محافظه‌کارانه (SL) ثبت می‌شود.
          </p>
        </>
      )}
    </div>
  );
}

function Stat({ l, v, good, warn }: { l: string; v: string; good?: boolean; warn?: boolean }) {
  return (
    <div className="rounded border hairline bg-[#0a0f1c] px-2 py-2 text-center">
      <div className="text-[10px] text-slate-500">{l}</div>
      <div className={`num text-sm font-semibold ${good === undefined ? 'text-slate-200' : good ? 'text-emerald-400' : 'text-rose-400'} ${warn ? 'text-amber-400' : ''}`}>
        {v}
      </div>
    </div>
  );
}
function Th({ children }: { children: ReactNode }) {
  return <th className="px-2 py-1.5 text-right font-normal">{children}</th>;
}
function Td({ children, cls }: { children: ReactNode; cls?: string }) {
  return <td className={`px-2 py-1.5 ${cls ?? ''}`}>{children}</td>;
}
