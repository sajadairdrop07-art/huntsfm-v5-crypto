import { Activity, BarChart3, LineChart as LineChartIcon, Search, Star, Waypoints } from 'lucide-react';
import { memo, useMemo, useState, type ReactNode } from 'react';
import type { CoinTicker, StrategyKind } from '@/types';
import { ACTIVE_STRATEGIES, STRATEGY_META } from '@/lib/strategies';
import { fmtCompact, fmtPct, fmtPrice, fmtUsd } from '@/lib/format';
import { INTERVALS } from '@/lib/liveCrypto';

interface Props {
  symbol: string;
  setSymbol: (s: string) => void;
  interval: string;
  setInterval: (i: string) => void;
  strategy: StrategyKind;
  setStrategy: (k: StrategyKind) => void;
  tickers: CoinTicker[];
  favorites: string[];
  toggleFavorite: (symbol: string) => void;
  universeCount: number;
  showEma: boolean;
  setShowEma: (b: boolean) => void;
  showVolume: boolean;
  setShowVolume: (b: boolean) => void;
}

const STRAT_ICON: Partial<Record<StrategyKind, ReactNode>> = {
  rtmSmc: <Waypoints className="h-4 w-4" />,
};

export function SidebarControls(p: Props) {
  const meta = STRATEGY_META[p.strategy];
  const current = p.tickers.find((t) => t.symbol === p.symbol);
  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto p-3">
      {/* strategy selector */}
      <section>
        <h2 className="label-en mb-2 text-[10px] text-slate-500">STRATEGY / استراتژی</h2>
        <div className="grid grid-cols-1 gap-1.5">
          {ACTIVE_STRATEGIES.map((k) => (
            <button
              key={k}
              onClick={() => p.setStrategy(k)}
              className={`focus-ring flex flex-col items-center gap-1 rounded-md border px-1 py-2 text-[11px] font-semibold transition-colors ${
                p.strategy === k
                  ? 'border-cyan-500/50 bg-cyan-500/10 text-cyan-300'
                  : 'hairline bg-[#0c1220] text-slate-400 hover:border-slate-600 hover:text-slate-200'
              }`}
            >
              {STRAT_ICON[k] ?? <Activity className="h-4 w-4" />}
              {STRATEGY_META[k].label}
            </button>
          ))}
        </div>
        <p className="mt-1.5 text-[10px] leading-4 text-slate-500">{meta.desc}</p>
      </section>

      {/* coin card */}
      {current && (
        <section className="rounded border hairline bg-[#0a0f1c] p-2 text-[10px] leading-4 text-slate-500">
          <div className="flex items-center justify-between">
            <span className="num text-slate-300">{current.name}</span>
            <span className="num">#{current.rank}</span>
          </div>
          <div className="num flex justify-between"><span>ارزش بازار</span><span className="text-slate-300">{fmtUsd(current.mcap)}</span></div>
          <div className="num flex justify-between"><span>حجم ۲۴h</span><span className="text-slate-300">${fmtCompact(current.volume)}</span></div>
          <div className="num flex justify-between"><span>سقف ۲۴h</span><span className="text-slate-300">{fmtPrice(current.high)}</span></div>
          <div className="num flex justify-between"><span>کف ۲۴h</span><span className="text-slate-300">{fmtPrice(current.low)}</span></div>
        </section>
      )}

      {/* interval */}
      <section>
        <h2 className="label-en mb-2 text-[10px] text-slate-500">TIMEFRAME / تایم‌فریم</h2>
        <div className="flex flex-wrap gap-1.5">
          {INTERVALS.map((iv) => (
            <button
              key={iv}
              onClick={() => p.setInterval(iv)}
              className={`focus-ring num rounded border px-2.5 py-1 text-[11px] transition-colors ${
                p.interval === iv
                  ? 'border-cyan-500/50 bg-cyan-500/10 text-cyan-300'
                  : 'hairline bg-[#0c1220] text-slate-400 hover:text-slate-200'
              }`}
            >
              {iv}
            </button>
          ))}
        </div>
      </section>

      {/* overlays */}
      <section>
        <h2 className="label-en mb-2 text-[10px] text-slate-500">OVERLAYS / نمایش</h2>
        <div className="flex gap-1.5">
          <Toggle on={p.showEma} onClick={() => p.setShowEma(!p.showEma)} label="EMA" icon={<LineChartIcon className="h-3.5 w-3.5" />} />
          <Toggle on={p.showVolume} onClick={() => p.setShowVolume(!p.showVolume)} label="حجم" icon={<BarChart3 className="h-3.5 w-3.5" />} />
        </div>
      </section>

      {/* watchlist */}
      <Watchlist tickers={p.tickers} symbol={p.symbol} setSymbol={p.setSymbol} favorites={p.favorites} toggleFavorite={p.toggleFavorite} count={p.universeCount} />
    </div>
  );
}

type SortKey = 'rank' | 'change' | 'volume';

function Watchlist({ tickers, symbol, setSymbol, favorites, toggleFavorite, count }: { tickers: CoinTicker[]; symbol: string; setSymbol: (s: string) => void; favorites: string[]; toggleFavorite: (s: string) => void; count: number }) {
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<SortKey>('rank');
  const [onlyFav, setOnlyFav] = useState(false);
  const favSet = useMemo(() => new Set(favorites), [favorites]);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    let list = tickers;
    if (onlyFav) list = list.filter((t) => favSet.has(t.symbol));
    if (needle) list = list.filter((t) => t.base.toLowerCase().includes(needle) || t.name.toLowerCase().includes(needle));
    const sorted = [...list];
    if (sort === 'change') sorted.sort((a, b) => b.changePct - a.changePct);
    else if (sort === 'volume') sorted.sort((a, b) => b.volume - a.volume);
    else sorted.sort((a, b) => a.rank - b.rank);
    return sorted;
  }, [tickers, q, sort, onlyFav, favSet]);

  const SORTS: [SortKey, string][] = [['rank', 'رتبه'], ['change', 'تغییر ٪'], ['volume', 'حجم']];

  return (
    <section className="flex min-h-0 flex-1 flex-col">
      <h2 className="label-en mb-2 text-[10px] text-slate-500">
        WATCHLIST / دیده‌بان <span className="num text-slate-600">· {count || tickers.length} ارز</span>
      </h2>
      <div className="relative mb-1.5">
        <Search className="pointer-events-none absolute right-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجوی ارز (BTC، Solana ...)"
          aria-label="جستجوی ارز"
          className="focus-ring w-full rounded border hairline bg-[#0a0f1c] py-1.5 pl-2 pr-7 text-[11px] text-slate-200 placeholder:text-slate-600"
          dir="ltr"
        />
      </div>
      <div className="mb-1.5 flex items-center gap-1">
        {SORTS.map(([k, label]) => (
          <button
            key={k}
            onClick={() => setSort(k)}
            className={`focus-ring rounded border px-2 py-0.5 text-[10px] transition-colors ${sort === k ? 'border-cyan-500/50 bg-cyan-500/10 text-cyan-300' : 'hairline bg-[#0c1220] text-slate-500 hover:text-slate-300'}`}
          >
            {label}
          </button>
        ))}
        <button
          onClick={() => setOnlyFav(!onlyFav)}
          aria-pressed={onlyFav}
          title="فقط علاقه‌مندی‌ها"
          className={`focus-ring mr-auto flex items-center gap-1 rounded border px-2 py-0.5 text-[10px] transition-colors ${onlyFav ? 'border-amber-400/50 bg-amber-400/10 text-amber-300' : 'hairline bg-[#0c1220] text-slate-500 hover:text-slate-300'}`}
        >
          <Star className="h-3 w-3" />
          {favorites.length}
        </button>
      </div>
      <ul className="max-h-[420px] min-h-[160px] space-y-1 overflow-y-auto pr-0.5" role="listbox" aria-label="فهرست ارزها">
        {rows.map((t) => (
          <CoinRow key={t.symbol} t={t} active={t.symbol === symbol} fav={favSet.has(t.symbol)} onSelect={setSymbol} onFav={toggleFavorite} />
        ))}
        {!rows.length && <li className="py-6 text-center text-[11px] text-slate-600">{onlyFav ? 'هنوز ارزی را ستاره‌دار نکرده‌اید.' : 'ارزی پیدا نشد.'}</li>}
      </ul>
    </section>
  );
}

const CoinRow = memo(function CoinRow({ t, active, fav, onSelect, onFav }: { t: CoinTicker; active: boolean; fav: boolean; onSelect: (s: string) => void; onFav: (s: string) => void }) {
  const up = t.changePct >= 0;
  return (
    <li role="option" aria-selected={active}>
      <div
        className={`flex w-full items-center gap-1.5 rounded border px-1.5 py-1.5 text-[12px] transition-colors ${active ? 'border-cyan-500/50 bg-cyan-500/10' : 'hairline bg-[#0c1220] hover:border-slate-600'}`}
      >
        <button onClick={() => onFav(t.symbol)} aria-label={fav ? 'حذف از علاقه‌مندی' : 'افزودن به علاقه‌مندی'} className="focus-ring shrink-0 rounded p-0.5">
          <Star className={`h-3.5 w-3.5 ${fav ? 'fill-amber-300 text-amber-300' : 'text-slate-600 hover:text-slate-400'}`} />
        </button>
        <button onClick={() => onSelect(t.symbol)} className="focus-ring flex min-w-0 flex-1 items-center justify-between gap-2 rounded" dir="ltr">
          <span className="flex shrink-0 items-center gap-1.5">
            {t.image ? (
              <img src={t.image} alt="" loading="lazy" width={16} height={16} className="h-4 w-4 shrink-0 rounded-full" onError={(e) => { (e.currentTarget as HTMLImageElement).style.visibility = 'hidden'; }} />
            ) : (
              <span className="num w-4 shrink-0 text-center text-[9px] text-slate-600">{t.rank}</span>
            )}
            <span className="label-en shrink-0 text-[11px] font-semibold text-slate-300">{t.base}</span>
          </span>
          <span className="flex min-w-0 items-center gap-1.5">
            <span className="num truncate text-slate-200">{fmtPrice(t.price)}</span>
            <span className={`num w-[52px] shrink-0 text-right text-[10px] ${up ? 'text-emerald-400' : 'text-rose-400'}`}>{fmtPct(t.changePct)}</span>
          </span>
        </button>
      </div>
    </li>
  );
});

function Toggle({ on, onClick, label, icon }: { on: boolean; onClick: () => void; label: string; icon: ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={on}
      className={`focus-ring flex items-center gap-1.5 rounded border px-2.5 py-1.5 text-[11px] transition-colors ${
        on ? 'border-cyan-500/50 bg-cyan-500/10 text-cyan-300' : 'hairline bg-[#0c1220] text-slate-400 hover:text-slate-200'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
