import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import type { Signal } from '@/types';
import { fmtPrice, fmtTime } from '@/lib/format';
import { decimalsFor } from '@/lib/format';

const DIR_LABEL: Record<string, { text: string; cls: string; ring: string }> = {
  long: { text: 'سیگنال خرید', cls: 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10', ring: '#34d399' },
  short: { text: 'سیگنال فروش', cls: 'text-rose-400 border-rose-500/40 bg-rose-500/10', ring: '#f87171' },
};

export function SignalPanel({ signal, strategyLabel }: { signal: Signal; strategyLabel: string }) {
  const decimals = decimalsFor(signal.entry ?? signal.sl ?? signal.tp ?? 0);
  const dir = signal.dir ? DIR_LABEL[signal.dir] : null;
  const rr =
    signal.dir && signal.entry != null && signal.sl != null && signal.tp != null
      ? Math.abs(signal.tp - signal.entry) / Math.abs(signal.entry - signal.sl)
      : null;

  return (
    <div className="panel-2 flex h-full flex-col gap-3 p-4">
      <div className="flex items-center justify-between">
        <h2 className="label-en text-[10px] text-slate-500">SIGNAL / سیگنال</h2>
        <span className="num text-[10px] text-slate-500">{fmtTime(signal.time)}</span>
      </div>

      {dir ? (
        <div className={`rounded-md border px-4 py-3 text-center text-lg font-bold ${dir.cls}`}>
          {dir.text}
          <span className="num mr-2 text-xs font-normal opacity-70">{strategyLabel}</span>
        </div>
      ) : (
        <div className="rounded-md border border-slate-600/40 bg-slate-500/5 px-4 py-3 text-center text-sm text-slate-400">
          بدون سیگنال فعال — در حال پایش شرایط
        </div>
      )}

      {/* score gauge */}
      <div className="flex items-center gap-3">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-800" role="meter" aria-valuenow={signal.score} aria-valuemin={0} aria-valuemax={100}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${signal.score}%`, background: dir ? dir.ring : '#475569' }}
          />
        </div>
        <span className="num text-xs text-slate-300">{signal.score}٪</span>
      </div>

      {/* levels */}
      {signal.entry != null && (
        <div className="grid grid-cols-3 gap-2 text-center">
          {[
            { l: 'ورود', v: signal.entry, c: 'text-cyan-300' },
            { l: 'حد ضرر', v: signal.sl!, c: 'text-rose-400' },
            { l: 'حد سود', v: signal.tp!, c: 'text-emerald-400' },
          ].map((x) => (
            <div key={x.l} className="rounded border hairline bg-[#0a0f1c] px-1 py-2">
              <div className="text-[10px] text-slate-500">{x.l}</div>
              <div className={`num text-[13px] font-semibold ${x.c}`}>{fmtPrice(x.v, decimals)}</div>
            </div>
          ))}
        </div>
      )}

      {rr != null && (
        <div className="num flex items-center justify-between rounded border hairline bg-[#0a0f1c] px-3 py-1.5 text-[11px]">
          <span className="text-slate-500">نسبت ریسک به بازده</span>
          <span className="text-slate-200">1 : {rr.toFixed(2)}</span>
        </div>
      )}

      {signal.tp2 != null && (
        <div className="num flex items-center justify-between rounded border hairline bg-[#0a0f1c] px-3 py-1.5 text-[11px]">
          <span className="text-slate-500">هدف دوم / نقدینگی دورتر</span>
          <span className="text-emerald-300">{fmtPrice(signal.tp2, decimals)}</span>
        </div>
      )}

      {signal.note && (
        <div className="flex items-start gap-2 rounded border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-[11px] leading-5 text-amber-200/90">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
          {signal.note}
        </div>
      )}

      {/* checklist */}
      <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto">
        {signal.reasons.map((r, i) => (
          <div key={i} className="flex items-center gap-2 text-[11px] text-slate-400">
            {r.ok ? (
              <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-400/80" />
            ) : (
              <XCircle className="h-3.5 w-3.5 shrink-0 text-slate-500/70" />
            )}
            <span className={r.ok ? '' : 'text-slate-500'}>{r.label}</span>
          </div>
        ))}
      </div>

      <p className="border-t hairline pt-2 text-[10px] leading-4 text-slate-600">
        این سیگنال خروجی یک مدل قاعده‌محور است، نه پیش‌بینی تضمینی. همیشه مدیریت ریسک را رعایت کنید.
      </p>
    </div>
  );
}
