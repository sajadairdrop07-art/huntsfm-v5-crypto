import { useEffect, useRef } from 'react';
import {
  CandlestickSeries,
  ColorType,
  createChart,
  createSeriesMarkers,
  HistogramSeries,
  LineSeries,
  LineStyle,
  type IChartApi,
  type IPriceLine,
  type ISeriesApi,
  type ISeriesMarkersPluginApi,
  type SeriesMarker,
  type Time,
  type UTCTimestamp,
} from 'lightweight-charts';
import type { Candle, Signal, StrategyKind } from '@/types';
import type { SmartMarker } from '@/lib/smartMoney';
import { closes, ema } from '@/lib/indicators';
import { fmtCountdown, secondsToClose } from '@/lib/countdown';

interface Props {
  candles: Candle[];
  signals: (Signal | null)[];
  events: SmartMarker[];
  strategy: StrategyKind;
  showEma: boolean;
  showVolume: boolean;
  decimals?: number;
  height?: number;
  /** changes only when the dataset is replaced; live ticks keep the user's pan/zoom */
  datasetKey?: string;
  /** candle length in ms; enables the close-countdown under the last-price label */
  intervalMs?: number;
}

export function ChartPanel({ candles, signals, events, strategy, showEma, showVolume, decimals = 2, height = 460, datasetKey, intervalMs }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const emaFastRef = useRef<ISeriesApi<'Line'> | null>(null);
  const emaSlowRef = useRef<ISeriesApi<'Line'> | null>(null);
  const volRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const priceLinesRef = useRef<IPriceLine[]>([]);
  const markersRef = useRef<ISeriesMarkersPluginApi<Time> | null>(null);
  const scrolledKeyRef = useRef<string | undefined>(undefined);
  const labelRef = useRef<HTMLDivElement>(null);
  const lastCandleRef = useRef<Candle | null>(null);
  const candlesRef = useRef<Candle[]>(candles);
  const decimalsRef = useRef(decimals); // initial value only; later changes go through applyOptions
  const fedRef = useRef<{ key?: string; len: number; firstT: number; lastT: number; showVolume: boolean; showEma: boolean; strategy: StrategyKind; decimals: number } | null>(null);
  const showVolumeRef = useRef(showVolume); // initial value only; later changes are applied in the data effect

  // create chart once
  useEffect(() => {
    if (!hostRef.current) return;
    const chart = createChart(hostRef.current, {
      autoSize: true,
      height,
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#7e8db0',
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 11,
        attributionLogo: false,
      },
      grid: {
        vertLines: { color: 'rgba(26,37,64,0.45)' },
        horzLines: { color: 'rgba(26,37,64,0.45)' },
      },
      rightPriceScale: {
        borderColor: '#1a2540',
        scaleMargins: showVolumeRef.current ? { top: 0.06, bottom: 0.22 } : { top: 0.06, bottom: 0.04 },
      },
      timeScale: {
        borderColor: '#1a2540',
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 6,
      },
      crosshair: {
        vertLine: { color: 'rgba(34,211,238,0.35)', labelBackgroundColor: '#16324a' },
        horzLine: { color: 'rgba(34,211,238,0.35)', labelBackgroundColor: '#16324a' },
      },
    });
    const cs = chart.addSeries(CandlestickSeries, {
      upColor: '#34d399',
      downColor: '#f87171',
      wickUpColor: '#34d399',
      wickDownColor: '#f87171',
      borderVisible: false,
      priceFormat: { type: 'price', precision: decimalsRef.current, minMove: 10 ** -decimalsRef.current },
    });
    markersRef.current = createSeriesMarkers(cs, []);
    chartRef.current = chart;
    seriesRef.current = cs;
    return () => {
      markersRef.current = null;
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
      emaFastRef.current = null;
      emaSlowRef.current = null;
      volRef.current = null;
      priceLinesRef.current = [];
      scrolledKeyRef.current = undefined;
      fedRef.current = null;
    };
  }, [height]);

  // price precision follows the coin (BTC 2 digits, DOGE 5, SHIB 8) without rebuilding the chart
  useEffect(() => {
    seriesRef.current?.applyOptions({ priceFormat: { type: 'price', precision: decimals, minMove: 10 ** -decimals } });
  }, [decimals, height]);

  // keep the latest candles reachable for the marker/price-line effect (declared before it, so it runs first)
  useEffect(() => {
    candlesRef.current = candles;
  }, [candles]);

  // feed data. A live tick only touches the last bar (series.update); anything else rebuilds the series.
  useEffect(() => {
    const chart = chartRef.current;
    const cs = seriesRef.current;
    if (!chart || !cs || !candles.length) return;
    lastCandleRef.current = candles[candles.length - 1];

    const bar = (c: Candle) => ({ time: Math.floor(c.t / 1000) as UTCTimestamp, open: c.o, high: c.h, low: c.l, close: c.c });
    const volBar = (c: Candle) => ({ time: Math.floor(c.t / 1000) as UTCTimestamp, value: c.v, color: c.c >= c.o ? 'rgba(52,211,153,0.32)' : 'rgba(248,113,113,0.32)' });

    const prev = fedRef.current;
    const fast =
      !!prev &&
      prev.key === datasetKey &&
      prev.showVolume === showVolume &&
      prev.showEma === showEma &&
      prev.strategy === strategy &&
      prev.decimals === decimals &&
      candles.length >= prev.len &&
      candles.length <= prev.len + 1 &&
      candles[0].t === prev.firstT &&
      candles[prev.len - 1].t === prev.lastT;
    const from = fast && prev ? prev.len - 1 : 0;

    if (fast) {
      for (let i = from; i < candles.length; i++) cs.update(bar(candles[i]));
    } else {
      cs.setData(candles.map(bar));
    }

    chart.priceScale('right').applyOptions({
      scaleMargins: showVolume ? { top: 0.06, bottom: 0.22 } : { top: 0.06, bottom: 0.04 },
    });
    if (showVolume) {
      if (!volRef.current) {
        volRef.current = chart.addSeries(HistogramSeries, { priceFormat: { type: 'volume' }, priceScaleId: '' });
        chart.priceScale('').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
      }
      if (fast) for (let i = from; i < candles.length; i++) volRef.current.update(volBar(candles[i]));
      else volRef.current.setData(candles.map(volBar));
    } else if (volRef.current) {
      chart.removeSeries(volRef.current);
      volRef.current = null;
    }

    if (showEma) {
      const cl = closes(candles);
      const [fastP, slowP] = strategy === 'scalp' ? [9, 21] : [20, 50];
      const ef = ema(cl, fastP);
      const es = ema(cl, slowP);
      const pt = (arr: number[], i: number) => ({ time: Math.floor(candles[i].t / 1000) as UTCTimestamp, value: arr[i] });
      const toLine = (arr: number[]) => candles.map((_, i) => pt(arr, i)).filter((p) => !Number.isNaN(p.value));
      const added = { f: false, s: false };
      if (!emaFastRef.current) {
        emaFastRef.current = chart.addSeries(LineSeries, { color: '#22d3ee', lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
        added.f = true;
      }
      if (!emaSlowRef.current) {
        emaSlowRef.current = chart.addSeries(LineSeries, { color: '#fbbf24', lineWidth: 1, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
        added.s = true;
      }
      const upd = (ref: ISeriesApi<'Line'>, arr: number[], justAdded: boolean) => {
        if (fast && !justAdded) {
          for (let i = from; i < candles.length; i++) if (!Number.isNaN(arr[i])) ref.update(pt(arr, i));
        } else ref.setData(toLine(arr));
      };
      upd(emaFastRef.current, ef, added.f);
      upd(emaSlowRef.current, es, added.s);
    } else {
      if (emaFastRef.current) { chart.removeSeries(emaFastRef.current); emaFastRef.current = null; }
      if (emaSlowRef.current) { chart.removeSeries(emaSlowRef.current); emaSlowRef.current = null; }
    }

    fedRef.current = { key: datasetKey, len: candles.length, firstT: candles[0].t, lastT: candles[candles.length - 1].t, showVolume, showEma, strategy, decimals };

    if (scrolledKeyRef.current !== datasetKey) {
      chart.timeScale().scrollToPosition(6, false);
      scrolledKeyRef.current = datasetKey;
    }
  }, [candles, strategy, showEma, showVolume, datasetKey, decimals]);

  // markers + entry/SL/TP lines: only when the (closed-candle based) analysis changes, never on a live tick
  useEffect(() => {
    const cs = seriesRef.current;
    const list = candlesRef.current;
    if (!cs || !list.length) return;
    const markers: SeriesMarker<Time>[] = [];
    let count = 0;
    for (let i = Math.min(list.length, signals.length) - 1; i >= 0 && count < 120; i--) {
      const s = signals[i];
      if (!s || !s.dir) continue;
      markers.unshift({
        time: Math.floor(list[i].t / 1000) as UTCTimestamp,
        position: s.dir === 'long' ? 'belowBar' : 'aboveBar',
        color: s.dir === 'long' ? '#34d399' : '#f87171',
        shape: s.dir === 'long' ? 'arrowUp' : 'arrowDown',
        text: s.dir === 'long' ? 'B' : 'S',
      });
      count++;
    }
    for (const ev of events.slice(-90)) {
      const color = ev.kind === 'CHoCH' ? '#fbbf24' : ev.kind === 'BOS' ? '#22d3ee' : ev.kind === 'SWEEP' ? '#e879f9' : '#94a3b8';
      markers.push({
        time: Math.floor(ev.t / 1000) as UTCTimestamp,
        position: ev.dir === 'long' ? 'belowBar' : 'aboveBar',
        color,
        shape: ev.kind === 'SWEEP' ? 'circle' : 'square',
        text: ev.text,
      });
    }
    markers.sort((a, b) => (a.time as number) - (b.time as number));
    markersRef.current?.setMarkers(markers);

    priceLinesRef.current.forEach((pl) => cs.removePriceLine(pl));
    priceLinesRef.current = [];
    const lastCandleT = list[list.length - 1].t;
    const fresh = [...signals].reverse().find((s) => s && s.dir && lastCandleT - s.time < 6 * 3_600_000);
    if (fresh && fresh.entry != null && fresh.sl != null && fresh.tp != null) {
      const mk = (price: number, color: string, title: string, style: LineStyle) =>
        cs.createPriceLine({ price, color, lineWidth: 1, lineStyle: style, axisLabelVisible: true, title });
      priceLinesRef.current.push(
        mk(fresh.entry, '#22d3ee', 'ورود', LineStyle.Solid),
        mk(fresh.sl, '#f87171', 'حد ضرر', LineStyle.Dashed),
        mk(fresh.tp, '#34d399', 'حد سود', LineStyle.Dashed)
      );
      if (fresh.tp2 != null) priceLinesRef.current.push(mk(fresh.tp2, '#34d39999', 'TP2', LineStyle.Dotted));
    }
  }, [signals, events, datasetKey]);

  // candle-close countdown, pinned under the last-price tag on the price axis (like TradingView)
  useEffect(() => {
    const el = labelRef.current;
    if (!el) return;
    const tick = () => {
      const chart = chartRef.current;
      const cs = seriesRef.current;
      const last = lastCandleRef.current;
      const sec = chart && cs && last && intervalMs ? secondsToClose(last.t, intervalMs, Date.now()) : null;
      const y = sec != null && cs && last ? cs.priceToCoordinate(last.c) : null;
      if (sec == null || y == null || !chart) {
        el.style.display = 'none';
        return;
      }
      el.textContent = fmtCountdown(sec);
      el.style.background = last && last.c >= last.o ? '#34d399' : '#f87171';
      el.style.width = `${chart.priceScale('right').width() || 64}px`;
      el.style.top = `${y + 11}px`;
      el.style.display = 'block';
    };
    tick();
    const id = window.setInterval(tick, 500);
    return () => window.clearInterval(id);
  }, [intervalMs, datasetKey, decimals]);

  return (
    <div className="relative h-full w-full">
      <div ref={hostRef} className="h-full w-full" dir="ltr" aria-label="نمودار قیمت" />
      <div
        ref={labelRef}
        dir="ltr"
        aria-hidden="true"
        className="pointer-events-none absolute right-0 z-10 hidden rounded-[2px] py-[1px] text-center font-mono text-[10px] font-semibold leading-[14px] text-[#06101f]"
      />
    </div>
  );
}
