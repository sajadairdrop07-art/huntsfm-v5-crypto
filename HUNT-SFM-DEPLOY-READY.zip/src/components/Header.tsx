import { useEffect, useState } from 'react';
import { LogoMark } from '@/components/Logo';
import type { ConnState } from '@/types';
import type { Transport } from '@/lib/liveCrypto';
import { fmtTime } from '@/lib/format';

const CONN: Record<ConnState, { label: string; cls: string }> = {
  live: { label: 'اتصال زنده', cls: 'bg-emerald-400' },
  stale: { label: 'داده با تأخیر · صرافی‌ها دیر پاسخ می‌دهند', cls: 'bg-amber-400' },
  offline: { label: 'قطع ارتباط با منبع زنده', cls: 'bg-rose-400' },
  connecting: { label: 'در حال اتصال', cls: 'bg-cyan-400' },
  snapshot: { label: 'اسنپ‌شات (سرور زنده در دسترس نیست)', cls: 'bg-amber-400' },
};

export function Header({ conn, transport }: { conn: ConnState; transport: Transport }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const c = CONN[conn];

  return (
    <header className="flex items-center justify-between gap-4 border-b hairline bg-[#0a0f1c] px-4 py-2.5">
      <div className="flex items-center gap-3">
        <LogoMark className="h-10 w-10 shrink-0" />
        <div dir="ltr" className="text-left">
          <h1 className="text-lg font-black leading-5 tracking-[0.14em]">
            <span className="text-[#f4f1ea]">HUNT</span> <span className="text-[#e8b64a]">SFM</span>
          </h1>
          <p className="label-en hidden whitespace-nowrap text-[8px] tracking-[0.2em] text-slate-400 sm:block">SMART MONEY · LIQUIDITY · STRUCTURE</p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <span className="num hidden text-[11px] text-slate-500 sm:block" dir="ltr">
          {fmtTime(now)} <span className="text-slate-600">local</span>
        </span>
        <div className="flex items-center gap-2 rounded-full border hairline bg-[#0c1220] px-3 py-1">
          <span className={`led led-pulse ${c.cls}`} aria-hidden />
          <span className="text-[11px] text-slate-300">{c.label}</span>
          {conn === 'live' && (
            <span className="num rounded bg-slate-800 px-1.5 text-[9px] text-slate-400" dir="ltr">
              {transport === 'ws' ? 'REALTIME' : 'POLLING'}
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
