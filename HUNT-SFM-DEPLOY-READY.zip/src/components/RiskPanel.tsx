import { useMemo, useState } from 'react';
import type { Signal } from '@/types';
import { fmtCompact, fmtPrice } from '@/lib/format';
import { symbolBase } from '@/lib/format';

export function RiskPanel({ signal, symbol }: { signal: Signal; symbol: string }) {
  const [account, setAccount] = useState(1000);
  const [riskPct, setRiskPct] = useState(1);
  const base = symbolBase(symbol);

  const calc = useMemo(() => {
    if (!signal.dir || signal.entry == null || signal.sl == null) return null;
    const stopDistance = Math.abs(signal.entry - signal.sl);
    const stopPct = stopDistance / signal.entry;
    const riskAmount = (account * riskPct) / 100;
    const qty = riskAmount / stopDistance;
    const notional = qty * signal.entry;
    return {
      stopPct: stopPct * 100,
      riskAmount,
      qty,
      notional,
      lev: notional / account,
    };
  }, [signal, account, riskPct]);

  return (
    <div className="panel-2 flex flex-col gap-3 p-4">
      <h2 className="label-en text-[10px] text-slate-500">RISK / مدیریت ریسک</h2>

      <div className="grid grid-cols-2 gap-2">
        <label className="block">
          <span className="mb-1 block text-[10px] text-slate-500">سرمایه (USD)</span>
          <input
            type="number"
            min={10}
            value={account || ''}
            onChange={(e) => setAccount(Number(e.target.value))}
            className="focus-ring num w-full rounded border hairline bg-[#0a0f1c] px-2 py-1.5 text-sm text-slate-200"
            dir="ltr"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-[10px] text-slate-500">ریسک هر معامله (٪)</span>
          <input
            type="number"
            min={0.1}
            max={10}
            step={0.1}
            value={riskPct || ''}
            onChange={(e) => setRiskPct(Number(e.target.value))}
            className="focus-ring num w-full rounded border hairline bg-[#0a0f1c] px-2 py-1.5 text-sm text-slate-200"
            dir="ltr"
          />
        </label>
      </div>

      {calc ? (
        <div className="space-y-1.5 rounded border hairline bg-[#0a0f1c] p-3 text-[11px]">
          <Row k="مبلغ ریسک" v={`${fmtPrice(calc.riskAmount, 2)} USD`} />
          <Row k="فاصله حد ضرر" v={`${calc.stopPct.toFixed(2)}٪`} />
          <Row k={`حجم مجاز (${base})`} v={fmtQty(calc.qty)} />
          <Row k="ارزش معامله" v={`${fmtCompact(calc.notional)} USD`} />
          <Row k="اهرم معادل" v={`${calc.lev.toFixed(1)}×`} warn={calc.lev > 5} />
          <p className="pt-1 text-[10px] leading-4 text-slate-600">
            با تنظیمات فعلی، ضربه حد ضرر فقط {riskPct}٪ سرمایه را کاهش می‌دهد.
          </p>
        </div>
      ) : (
        <div className="rounded border border-dashed hairline p-3 text-center text-[11px] text-slate-500">
          وقتی سیگنال فعال باشد، حجم دقیق معامله اینجا محاسبه می‌شود.
        </div>
      )}
    </div>
  );
}

/** coin amounts: 0.0123 BTC, 1,520 DOGE */
function fmtQty(q: number): string {
  if (q >= 1000) return fmtCompact(q);
  if (q >= 1) return q.toFixed(2);
  return q.toPrecision(3);
}

function Row({ k, v, warn }: { k: string; v: string; warn?: boolean }) {
  return (
    <div className="num flex items-center justify-between">
      <span className="text-slate-500">{k}</span>
      <span className={warn ? 'text-amber-400' : 'text-slate-200'}>{v}</span>
    </div>
  );
}
