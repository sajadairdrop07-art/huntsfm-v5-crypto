/** HUNT SFM mark: crosshair + candle on a rounded tile. Inline SVG so it needs no extra request. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="136 260 520 520" className={className} role="img" aria-label="HUNT SFM">
      <rect x="139" y="263" width="514" height="514" rx="104" fill="#111a2e" stroke="#e8b64a" strokeWidth="6" />
      <g fill="none" stroke="#e8b64a" strokeWidth="14" strokeLinecap="round">
        <circle cx="396" cy="520" r="156" />
        <path d="M396 321V407M396 633V719M197 520H283M509 520H595" />
      </g>
      <path d="M396 443V597" stroke="#f4f1ea" strokeWidth="11" strokeLinecap="round" />
      <rect x="366" y="478" width="60" height="90" rx="9" fill="#f4f1ea" />
    </svg>
  );
}
