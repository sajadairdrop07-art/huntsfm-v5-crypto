import { useEffect, useMemo, useState } from 'react';
import { CalendarClock, Flame, ShieldAlert } from 'lucide-react';
import type { Candle } from '@/types';
import { detectVolEvents } from '@/lib/strategies';
import { atr } from '@/lib/indicators';
import { fmtDateTime, fmtPrice } from '@/lib/format';

type Bias = 'bullish' | 'bearish' | 'straddle';

export function NewsPanel({ candles, symbol }: { candles: Candle[]; symbol: string }) {
  const events = useMemo(() => detectVolEvents(candles).slice(-12).reverse(), [candles]);

  const [eventTime, setEventTime] = useState(() => {
    const d = new Date(Date.now() + 2 * 3_600_000);
    d.setMinutes(0, 0, 0);
    // to datetime-local format
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  });
  const [bias, setBias] = useState<Bias>('straddle');
  const [windowN, setWindowN] = useState(20);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const plan = useMemo(() => {
    if (candles.length < windowN + 5) return null;
    const et = new Date(eventTime).getTime();
    const before = candles.filter((c) => c.t < et);
    const ref = before.length >= windowN ? before.slice(-windowN) : candles.slice(-windowN);
    const atrArr = atr(candles, 14);
    const a = atrArr[atrArr.length - 1];
    const rangeHigh = Math.max(...ref.map((c) => c.h));
    const rangeLow = Math.min(...ref.map((c) => c.l));
    const buf = 0.1 * a;
    const mk = (dir: 'long' | 'short') => {
      const entry = dir === 'long' ? rangeHigh + buf : rangeLow - buf;
      const sl = dir === 'long' ? rangeLow - 0.2 * a : rangeHigh + 0.2 * a;
      const risk = Math.abs(entry - sl);
      return { entry, sl, tp1: dir === 'long' ? entry + 1.5 * risk : entry - 1.5 * risk, tp2: dir === 'long' ? entry + 2.5 * risk : entry - 2.5 * risk };
    };
    const withinHistory = before.length >= windowN;
    return { et, rangeHigh, rangeLow, withinHistory, long: mk('long'), short: mk('short') };
  }, [candles, eventTime, windowN]);

  const countdown = plan ? plan.et - now : 0;
  const cd = {
    d: Math.floor(Math.max(0, countdown) / 86_400_000),
    h: Math.floor((Math.max(0, countdown) / 3_600_000) % 24),
    m: Math.floor((Math.max(0, countdown) / 60_000) % 60),
    s: Math.floor((Math.max(0, countdown) / 1000) % 60),
  };

  return (
    <div className="grid h-full grid-cols-1 gap-3 overflow-y-auto p-4 lg:grid-cols-2">
      {/* detected volatility shocks */}
      <section className="panel-2 p-3">
        <h3 className="mb-2 flex items-center gap-2 text-[11px] font-bold text-slate-300">
          <Flame className="h-3.5 w-3.5 text-fuchsia-400" />
          شوک‌های نوسان شناسایی‌شده ({symbol})
        </h3>
        {events.length === 0 ? (
          <p className="text-[11px] leading-5 text-slate-500">
            در داده‌های فعلی شوک نوسان معناداری (دامنه ≥ ۲× ATR و حجم ≥ ۲.۵× میانگین) یافت نشد.
          </p>
        ) : (
          <ul className="space-y-1.5">
            {events.map((e, i) => (
              <li key={i} className="flex items-center justify-between rounded border hairline bg-[#0a0f1c] px-2.5 py-1.5 text-[11px]">
                <span className="num text-slate-400">{fmtDateTime(e.t)}</span>
                <span className={`num ${e.dir === 'long' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {e.dir === 'long' ? 'صعودی' : 'نزولی'} @ {fmtPrice(e.price)}
                </span>
                <span className="num text-fuchsia-300/90">
                  {e.rangeX.toFixed(1)}×R / {e.volX.toFixed(1)}×V
                </span>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-2 text-[10px] leading-4 text-slate-600">
          این شوک‌ها معمولاً منتشر شدن خبرهای اقتصادی یا رویدادهای شبکه هستند. الگوی معامله: شکست محدوده پیش از خبر.
        </p>
      </section>

      {/* event planner */}
      <section className="panel-2 p-3">
        <h3 className="mb-2 flex items-center gap-2 text-[11px] font-bold text-slate-300">
          <CalendarClock className="h-3.5 w-3.5 text-cyan-300" />
          برنامه‌ریز معامله رویداد
        </h3>

        <div className="grid grid-cols-2 gap-2">
          <label className="block">
            <span className="mb-1 block text-[10px] text-slate-500">زمان خبر</span>
            <input
              type="datetime-local"
              value={eventTime}
              onChange={(e) => setEventTime(e.target.value)}
              className="focus-ring num w-full rounded border hairline bg-[#0a0f1c] px-2 py-1.5 text-[11px] text-slate-200"
              dir="ltr"
            />
          </label>
          <label className="block">
            <span className="mb-1 block text-[10px] text-slate-500">جهت‌گیری</span>
            <select
              value={bias}
              onChange={(e) => setBias(e.target.value as Bias)}
              className="focus-ring w-full rounded border hairline bg-[#0a0f1c] px-2 py-1.5 text-[11px] text-slate-200"
            >
              <option value="bullish">صعودی</option>
              <option value="bearish">نزولی</option>
              <option value="straddle">دوسویه (استرادل)</option>
            </select>
          </label>
          <label className="col-span-2 block">
            <span className="mb-1 block text-[10px] text-slate-500">پنجره محاسبه محدوده: {windowN} کندل اخیر</span>
            <input
              type="range" min={8} max={60} value={windowN}
              onChange={(e) => setWindowN(Number(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </label>
        </div>

        {plan && (
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between rounded border border-cyan-500/30 bg-cyan-500/5 px-3 py-2">
              <span className="text-[11px] text-cyan-200/90">
                {countdown > 0 ? 'مانده تا خبر:' : countdown > -3_600_000 ? 'رویداد در حال وقوع است' : 'رویداد گذشته است'}
              </span>
              <span className="num text-sm font-bold text-cyan-300" dir="ltr">
                {countdown > 0 ? `${cd.d > 0 ? cd.d + 'd ' : ''}${String(cd.h).padStart(2, '0')}:${String(cd.m).padStart(2, '0')}:${String(cd.s).padStart(2, '0')}` : '—'}
              </span>
            </div>

            {!plan.withinHistory && (
              <p className="flex items-start gap-1.5 text-[10px] leading-4 text-amber-200/80">
                <ShieldAlert className="mt-0.5 h-3 w-3 shrink-0" />
                زمان خبر در آینده است؛ محدوده با {windowN} کندل اخیر {symbol} محاسبه شده (تقریب).
              </p>
            )}

            <div className="rounded border hairline bg-[#0a0f1c] p-2.5 text-[11px]">
              <div className="num mb-2 flex justify-between text-slate-500">
                <span>محدوده مرجع</span>
                <span className="text-slate-300">
                  {fmtPrice(plan.rangeHigh)} — {fmtPrice(plan.rangeLow)}
                </span>
              </div>

              {(bias === 'bullish' || bias === 'straddle') && (
                <PlanCard title=" سناریوی صعودی — خرید شکست بالای محدوده" plan={plan.long} color="emerald" />
              )}
              {(bias === 'bearish' || bias === 'straddle') && (
                <PlanCard title=" سناریوی نزولی — فروش شکست زیر محدوده" plan={plan.short} color="rose" />
              )}
            </div>

            <ul className="list-inside list-disc space-y-1 text-[10px] leading-4 text-slate-500">
              <li>حداکثر ۱ تا ۲ دقیقه پس از انتشار خبر وارد نشوید — اسپرد و لغزش شدید است.</li>
              <li>سفارش استاپ ورود بالای/زیر محدوده را «از قبل» ثبت کنید، نه بعد از خبر.</li>
              <li>اگر هر دو سو شکسته شد، جهت با حجم بیشتر معتبر است (استرادل).</li>
              <li>حد ضرر باید «از قبل» تعیین شده باشد؛ معامله خبری بدون SL ممنوع.</li>
            </ul>
          </div>
        )}
      </section>
    </div>
  );
}

function PlanCard({
  title,
  plan,
  color,
}: {
  title: string;
  plan: { entry: number; sl: number; tp1: number; tp2: number };
  color: 'emerald' | 'rose';
}) {
  const c = color === 'emerald' ? 'text-emerald-400' : 'text-rose-400';
  return (
    <div className="mb-2 border-t hairline pt-2 last:mb-0">
      <div className={`mb-1.5 text-[10px] font-bold ${c}`}>{title}</div>
      <div className="num grid grid-cols-4 gap-1 text-center">
        {[
          { l: 'ورود استاپ', v: plan.entry, cls: 'text-cyan-300' },
          { l: 'حد ضرر', v: plan.sl, cls: 'text-rose-400' },
          { l: 'TP1', v: plan.tp1, cls: 'text-emerald-400' },
          { l: 'TP2', v: plan.tp2, cls: 'text-emerald-400' },
        ].map((x) => (
          <div key={x.l}>
            <div className="text-[9px] text-slate-500">{x.l}</div>
            <div className={`text-[11px] font-semibold ${x.cls}`}>{fmtPrice(x.v)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
