export interface Candle {
  t: number; // open time ms
  o: number;
  h: number;
  l: number;
  c: number;
  v: number; // quote volume
}

export type Dir = 'long' | 'short';

export type StrategyKind = 'scalp' | 'swing' | 'news' | 'rtmSmc';

export interface Reason {
  label: string;
  ok: boolean;
}

export interface Signal {
  dir: Dir | null;
  entry: number | null;
  sl: number | null;
  tp: number | null;
  tp2?: number | null;
  score: number; // 0..100
  reasons: Reason[];
  time: number;
  atr: number;
  note?: string;
}

export interface VolEvent {
  t: number;
  symbol?: string;
  rangeX: number; // candle range / ATR
  volX: number; // volume / average
  dir: Dir;
  price: number;
}

export interface Trade {
  dir: Dir;
  entryTime: number;
  exitTime: number;
  entry: number;
  exit: number;
  sl: number;
  tp: number;
  resultR: number;
  pnlPct: number;
  exitReason: 'tp' | 'sl' | 'time';
}

export interface BacktestResult {
  trades: Trade[];
  total: number;
  wins: number;
  winRate: number;
  profitFactor: number;
  netR: number;
  avgR: number;
  maxDrawdownR: number;
  equity: { t: number; r: number }[];
}

export interface TickerInfo {
  symbol: string;
  price: number;
  changePct: number; // 24h
  high: number;
  low: number;
  volume: number;
}

/** one coin of the live universe (top-N by market cap), from /api/live/universe */
export interface Coin {
  symbol: string; // BTCUSDT
  base: string; // BTC
  name: string; // Bitcoin
  rank: number; // rank inside the app's list (1..N, stablecoins removed)
  mcapRank: number; // real market-cap rank
  mcap: number;
  image: string;
}

export type CoinTicker = TickerInfo & { base: string; name: string; rank: number; mcap: number; image: string };

export type ConnState = 'live' | 'stale' | 'offline' | 'connecting' | 'snapshot';
