import type { Candle } from '@/types';

/** All indicator functions return arrays aligned with input length, NaN during warmup. */

export function closes(cs: Candle[]): number[] {
  return cs.map((c) => c.c);
}

export function sma(src: number[], period: number): number[] {
  const out = new Array<number>(src.length).fill(NaN);
  let sum = 0;
  for (let i = 0; i < src.length; i++) {
    sum += src[i];
    if (i >= period) sum -= src[i - period];
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

export function ema(src: number[], period: number): number[] {
  const out = new Array<number>(src.length).fill(NaN);
  if (src.length < period) return out;
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) sum += src[i];
  let prev = sum / period;
  out[period - 1] = prev;
  for (let i = period; i < src.length; i++) {
    prev = src[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

export function rsi(cl: number[], period = 14): number[] {
  const out = new Array<number>(cl.length).fill(NaN);
  if (cl.length <= period) return out;
  let g = 0;
  let l = 0;
  for (let i = 1; i <= period; i++) {
    const d = cl[i] - cl[i - 1];
    if (d > 0) g += d;
    else l -= d;
  }
  let avgG = g / period;
  let avgL = l / period;
  out[period] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  for (let i = period + 1; i < cl.length; i++) {
    const d = cl[i] - cl[i - 1];
    avgG = (avgG * (period - 1) + Math.max(d, 0)) / period;
    avgL = (avgL * (period - 1) + Math.max(-d, 0)) / period;
    out[i] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  }
  return out;
}

export interface MacdResult {
  macd: number[];
  signal: number[];
  hist: number[];
}

export function macd(cl: number[], fast = 12, slow = 26, signalP = 9): MacdResult {
  const ef = ema(cl, fast);
  const es = ema(cl, slow);
  const macdLine = cl.map((_, i) => ef[i] - es[i]);
  const sig = ema(macdLine.map((v) => (Number.isNaN(v) ? 0 : v)), signalP);
  return {
    macd: macdLine,
    signal: sig,
    hist: macdLine.map((v, i) => v - sig[i]),
  };
}

export interface BollingerResult {
  mid: number[];
  upper: number[];
  lower: number[];
}

export function bollinger(cl: number[], period = 20, mult = 2): BollingerResult {
  const mid = sma(cl, period);
  const upper = new Array<number>(cl.length).fill(NaN);
  const lower = new Array<number>(cl.length).fill(NaN);
  for (let i = period - 1; i < cl.length; i++) {
    const m = mid[i];
    let s = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const d = cl[j] - m;
      s += d * d;
    }
    const sd = Math.sqrt(s / period);
    upper[i] = m + mult * sd;
    lower[i] = m - mult * sd;
  }
  return { mid, upper, lower };
}

export function atr(cs: Candle[], period = 14): number[] {
  const out = new Array<number>(cs.length).fill(NaN);
  if (cs.length <= period) return out;
  const trs: number[] = [0];
  for (let i = 1; i < cs.length; i++) {
    const tr = Math.max(
      cs[i].h - cs[i].l,
      Math.abs(cs[i].h - cs[i - 1].c),
      Math.abs(cs[i].l - cs[i - 1].c)
    );
    trs.push(tr);
  }
  let sum = 0;
  for (let i = 1; i <= period; i++) sum += trs[i];
  let prev = sum / period;
  out[period] = prev;
  for (let i = period + 1; i < cs.length; i++) {
    prev = (prev * (period - 1) + trs[i]) / period;
    out[i] = prev;
  }
  return out;
}

export function lowest(cs: Candle[], period: number, upto: number): number {
  let m = Infinity;
  const from = Math.max(0, upto - period + 1);
  for (let i = from; i <= upto; i++) m = Math.min(m, cs[i].l);
  return m;
}

export function highest(cs: Candle[], period: number, upto: number): number {
  let m = -Infinity;
  const from = Math.max(0, upto - period + 1);
  for (let i = from; i <= upto; i++) m = Math.max(m, cs[i].h);
  return m;
}

/** true range series (for spike detection) */
export function ranges(cs: Candle[]): number[] {
  return cs.map((c) => c.h - c.l);
}
