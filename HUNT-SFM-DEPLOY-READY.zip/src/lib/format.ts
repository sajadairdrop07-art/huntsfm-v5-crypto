const faFmt = new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 0 });
const enFmt = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
const enFmt2 = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Price precision that keeps ~5 significant digits: BTC 2, SOL 3, XRP 4, DOGE 5, SHIB 8 */
export function decimalsFor(price: number): number {
  if (!(price > 0)) return 2;
  if (price >= 1000) return 2;
  if (price >= 100) return 2;
  if (price >= 10) return 3;
  if (price >= 1) return 4;
  if (price >= 0.1) return 5;
  if (price >= 0.01) return 6;
  if (price >= 0.001) return 7;
  return 8;
}

/** Format a price. Without `decimals` the precision follows the price itself. */
export function fmtPrice(p: number, decimals?: number): string {
  const d = decimals ?? decimalsFor(p);
  if (d <= 2 && Math.abs(p) >= 1000) return enFmt2.format(p);
  return p.toFixed(d);
}

export function fmtInt(n: number): string {
  return enFmt.format(n);
}

/** large volumes: 12.4M / 3.1B */
export function fmtCompact(n: number): string {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return n.toFixed(0);
}

export function fmtPct(p: number, signed = true): string {
  const s = signed && p > 0 ? '+' : '';
  return s + p.toFixed(2) + '%';
}

export function fmtTime(t: number): string {
  // compact HH:MM
  const d = new Date(t);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function fmtTimeSec(t: number): string {
  const d = new Date(t);
  return `${fmtTime(t)}:${String(d.getSeconds()).padStart(2, '0')}`;
}

export function fmtDateTime(t: number): string {
  const d = new Date(t);
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')} ${fmtTime(t)}`;
}

export function faInt(n: number): string {
  return faFmt.format(n);
}

export function symbolBase(symbol: string): string {
  return symbol.replace(/USDT$/, '');
}

/** market cap / volume in dollars: $1.23T, $45.6B */
export function fmtUsd(n: number): string {
  if (!(n > 0)) return '—';
  if (n >= 1e12) return '$' + (n / 1e12).toFixed(2) + 'T';
  return '$' + fmtCompact(n);
}
