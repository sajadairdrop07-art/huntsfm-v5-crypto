import type { Candle, Dir, Signal } from '@/types';
import { atr, highest, lowest } from './indicators';

export type SmartMarkerKind = 'BOS' | 'CHoCH' | 'SWEEP' | 'OB' | 'FVG';

export interface SmartMarker {
  t: number;
  dir: Dir;
  kind: SmartMarkerKind;
  text: string;
}

export interface SmartZone {
  id: number;
  dir: Dir;
  kind: 'OB' | 'FVG';
  start: number;
  created: number;
  top: number;
  bottom: number;
  strength: number;
  active: boolean;
  used: boolean;
}

export interface SmartStructure {
  idx: number;
  t: number;
  dir: Dir;
  kind: 'BOS' | 'CHoCH';
  price: number;
}

export interface SmartAnalysis {
  signals: (Signal | null)[];
  markers: SmartMarker[];
  zones: SmartZone[];
  structures: SmartStructure[];
  trend: Dir | null;
  premiumRatio: number;
  rangeHigh: number;
  rangeLow: number;
}

interface SwingPoint {
  idx: number;
  t: number;
  price: number;
}

interface SweepEvent {
  dir: Dir;
  idx: number;
  t: number;
  price: number;
  used: boolean;
}

interface RecentRange {
  high: number;
  low: number;
  mid: number;
  ratio: number;
}

const SWING_LEFT = 3;
const SWING_RIGHT = 3;
const STRUCTURE_LOOKBACK = 90;
const SWEEP_LOOKBACK = 14;
const ZONE_MAX_AGE = 220;

function range(c: Candle): number {
  return c.h - c.l;
}

function body(c: Candle): number {
  return Math.abs(c.c - c.o);
}

function isBullish(c: Candle): boolean {
  return c.c >= c.o;
}

function isBearish(c: Candle): boolean {
  return c.c < c.o;
}

function findSwings(cs: Candle[]): { highs: SwingPoint[]; lows: SwingPoint[] } {
  const highs: SwingPoint[] = [];
  const lows: SwingPoint[] = [];
  for (let i = SWING_LEFT; i < cs.length - SWING_RIGHT; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = i - SWING_LEFT; j <= i + SWING_RIGHT; j++) {
      if (j === i) continue;
      if (cs[j].h >= cs[i].h) isHigh = false;
      if (cs[j].l <= cs[i].l) isLow = false;
      if (!isHigh && !isLow) break;
    }
    if (isHigh) highs.push({ idx: i, t: cs[i].t, price: cs[i].h });
    if (isLow) lows.push({ idx: i, t: cs[i].t, price: cs[i].l });
  }
  return { highs, lows };
}

function recentRange(cs: Candle[], i: number, lookback = 90): RecentRange {
  const from = Math.max(0, i - lookback + 1);
  let high = -Infinity;
  let low = Infinity;
  for (let j = from; j <= i; j++) {
    high = Math.max(high, cs[j].h);
    low = Math.min(low, cs[j].l);
  }
  if (!Number.isFinite(high) || !Number.isFinite(low) || high === low) {
    const c = cs[i];
    return { high: c.h, low: c.l, mid: c.c, ratio: 0.5 };
  }
  const mid = (high + low) / 2;
  const ratio = (cs[i].c - low) / (high - low);
  return { high, low, mid, ratio };
}

function lastStructure(structures: SmartStructure[], i: number, dir?: Dir): SmartStructure | null {
  for (let j = structures.length - 1; j >= 0; j--) {
    const s = structures[j];
    if (s.idx > i) continue;
    if (i - s.idx > STRUCTURE_LOOKBACK) break;
    if (!dir || s.dir === dir) return s;
  }
  return null;
}

function sessionLabel(t: number): { label: string; highProb: boolean } {
  const h = new Date(t).getUTCHours();
  if (h >= 7 && h < 11) return { label: 'لندن', highProb: true };
  if (h >= 12 && h < 16) return { label: 'نیویورک', highProb: true };
  if (h >= 0 && h < 7) return { label: 'آسیایی', highProb: false };
  return { label: 'بین‌جلسه', highProb: false };
}

function createOrderBlock(cs: Candle[], i: number, dir: Dir, at: number[]): SmartZone | null {
  const a = at[i];
  if (Number.isNaN(a) || a <= 0) return null;
  const maxBack = Math.min(12, i);
  for (let j = i - 1; j >= i - maxBack; j--) {
    const base = cs[j];
    const opposite = dir === 'long' ? isBearish(base) : isBullish(base);
    if (!opposite) continue;

    let maxImpulseRange = 0;
    let travel = 0;
    for (let k = j + 1; k <= i; k++) {
      maxImpulseRange = Math.max(maxImpulseRange, range(cs[k]));
      if (dir === 'long') travel = Math.max(travel, cs[k].c - base.c);
      else travel = Math.max(travel, base.c - cs[k].c);
    }
    const strongDeparture = maxImpulseRange >= a * 1.15 && travel >= a * 0.85;
    if (!strongDeparture) continue;

    const strength = Math.min(5, maxImpulseRange / a + body(base) / Math.max(range(base), 1e-10));
    return {
      id: -1,
      dir,
      kind: 'OB',
      start: j,
      created: i,
      top: dir === 'long' ? Math.max(base.o, base.c) : base.h,
      bottom: dir === 'long' ? base.l : Math.min(base.o, base.c),
      strength,
      active: true,
      used: false,
    };
  }
  return null;
}

function createFvgZone(cs: Candle[], i: number, at: number[]): SmartZone | null {
  if (i < 2) return null;
  const a = at[i];
  if (Number.isNaN(a) || a <= 0) return null;
  const left = cs[i - 2];
  const right = cs[i];
  const gapUp = right.l - left.h;
  const gapDown = left.l - right.h;
  if (gapUp > a * 0.12) {
    return {
      id: -1,
      dir: 'long',
      kind: 'FVG',
      start: i - 1,
      created: i,
      top: right.l,
      bottom: left.h,
      strength: Math.min(5, gapUp / a + range(cs[i - 1]) / a),
      active: true,
      used: false,
    };
  }
  if (gapDown > a * 0.12) {
    return {
      id: -1,
      dir: 'short',
      kind: 'FVG',
      start: i - 1,
      created: i,
      top: left.l,
      bottom: right.h,
      strength: Math.min(5, gapDown / a + range(cs[i - 1]) / a),
      active: true,
      used: false,
    };
  }
  return null;
}

function liquidityTarget(swings: SwingPoint[], i: number, dir: Dir, entry: number): number | null {
  let target: number | null = null;
  for (const s of swings) {
    if (s.idx > i) continue;
    if (dir === 'long' && s.price > entry) {
      target = target === null ? s.price : Math.min(target, s.price);
    }
    if (dir === 'short' && s.price < entry) {
      target = target === null ? s.price : Math.max(target, s.price);
    }
  }
  return target;
}

function zoneTouch(zone: SmartZone, c: Candle): boolean {
  return c.l <= zone.top && c.h >= zone.bottom;
}

function zoneRejected(zone: SmartZone, cs: Candle[], i: number): boolean {
  const cur = cs[i];
  const prev = cs[i - 1];
  if (!prev) return false;
  if (zone.dir === 'long') {
    const wickReclaim = cur.l < zone.top && cur.c > zone.top && isBullish(cur);
    const engulf = isBearish(prev) && cur.c >= prev.o && cur.o <= prev.c && isBullish(cur);
    return wickReclaim || engulf;
  }
  const wickReject = cur.h > zone.bottom && cur.c < zone.bottom && isBearish(cur);
  const engulf = isBullish(prev) && cur.c <= prev.o && cur.o >= prev.c && isBearish(cur);
  return wickReject || engulf;
}

function invalidateZones(zones: SmartZone[], c: Candle, i: number): void {
  for (const z of zones) {
    if (!z.active) continue;
    if (i - z.created > ZONE_MAX_AGE) z.active = false;
    if (z.dir === 'long' && c.c < z.bottom) z.active = false;
    if (z.dir === 'short' && c.c > z.top) z.active = false;
  }
}

function makeSignal(
  cs: Candle[],
  i: number,
  dir: Dir,
  setup: string,
  zone: SmartZone | null,
  sweep: SweepEvent | null,
  structures: SmartStructure[],
  highs: SwingPoint[],
  lows: SwingPoint[],
  at: number[]
): Signal | null {
  const cur = cs[i];
  const a = Number.isNaN(at[i]) ? range(cur) : at[i];
  if (!Number.isFinite(a) || a <= 0) return null;

  const rr = recentRange(cs, i, 90);
  const session = sessionLabel(cur.t);
  const structure = lastStructure(structures, i, dir);
  const locationOk = dir === 'long' ? cur.c <= rr.mid * 1.002 : cur.c >= rr.mid * 0.998;

  const slBase = sweep
    ? sweep.price
    : zone
      ? dir === 'long'
        ? zone.bottom
        : zone.top
      : dir === 'long'
        ? lowest(cs, 5, i)
        : highest(cs, 5, i);
  const buffer = Math.max(a * 0.16, cur.c * 0.00002);
  const sl = dir === 'long' ? slBase - buffer : slBase + buffer;
  const entry = cur.c;
  const risk = Math.abs(entry - sl);
  if (risk <= 0 || risk / entry < 0.00003) return null;

  const rawTarget = liquidityTarget(dir === 'long' ? highs : lows, i, dir, entry);
  let tp = rawTarget ?? (dir === 'long' ? entry + risk * 2.2 : entry - risk * 2.2);
  const rawR = Math.abs(tp - entry) / risk;
  if (rawR < 1.45) tp = dir === 'long' ? entry + risk * 2.2 : entry - risk * 2.2;
  const tp2 = dir === 'long' ? entry + risk * 3.1 : entry - risk * 3.1;

  const targetR = Math.abs(tp - entry) / risk;
  let score = 44;
  if (structure) score += 18;
  if (zone) score += 12;
  if (sweep) score += 12;
  if (locationOk) score += 8;
  if (session.highProb) score += 4;
  if (targetR >= 2) score += 4;
  score = Math.max(35, Math.min(96, score));

  const reasons: Signal['reasons'] = [
    { label: `${setup} روی ${dir === 'long' ? 'تقاضا/نقدینگی پایین' : 'عرضه/نقدینگی بالا'}`, ok: true },
    { label: structure ? `${structure.kind === 'CHoCH' ? 'تغییر ماهیت' : 'شکست ساختار'} ${structure.dir === 'long' ? 'صعودی' : 'نزولی'} در ${sessionLabel(structure.t).label}` : 'ساختار هم‌جهت هنوز تازه تأیید نشده', ok: !!structure },
    { label: zone ? `${zone.kind === 'OB' ? 'Order Block' : 'Fair Value Gap'} فعال با قدرت ${zone.strength.toFixed(1)}` : 'زون فعال برای ورود پیدا نشد', ok: !!zone },
    { label: sweep ? 'Stop Hunt / جمع‌کردن نقدینگی قبل از حرکت' : 'سوییپ نقدینگی در این ستاپ دیده نشد', ok: !!sweep },
    { label: `موقعیت ${dir === 'long' ? 'دیسکانت' : 'پریمیوم'} (${(rr.ratio * 100).toFixed(0)}٪ محدوده)`, ok: locationOk },
    { label: `جلسه ${session.label}${session.highProb ? ' با احتمال بالاتر' : ''}`, ok: session.highProb },
    { label: `R:R هدف اصلی ${targetR.toFixed(1)}`, ok: targetR >= 1.8 },
  ];

  return {
    dir,
    entry,
    sl,
    tp,
    tp2,
    score,
    reasons,
    time: cur.t,
    atr: a,
    note: `${setup} — ورود با بستن کندل تأیید؛ عبور قیمت از لبه زون، ستاپ را باطل می‌کند.`,
  };
}

export function analyzeSmartMoney(cs: Candle[]): SmartAnalysis {
  const n = cs.length;
  const signals: (Signal | null)[] = new Array(n).fill(null);
  if (n === 0) {
    return {
      signals,
      markers: [],
      zones: [],
      structures: [],
      trend: null,
      premiumRatio: 0.5,
      rangeHigh: 0,
      rangeLow: 0,
    };
  }

  const markers: SmartMarker[] = [];
  const structures: SmartStructure[] = [];
  const zones: SmartZone[] = [];
  const { highs, lows } = findSwings(cs);
  const at = atr(cs, 14);

  let nextHigh = 0;
  let nextLow = 0;
  let curHigh: SwingPoint | null = null;
  let curLow: SwingPoint | null = null;
  let trend: Dir | null = null;
  let zoneId = 1;
  let lastSignalIdx = -20;
  let sweeps: SweepEvent[] = [];

  for (let i = 0; i < n; i++) {
    const cur = cs[i];
    while (nextHigh < highs.length && highs[nextHigh].idx + SWING_RIGHT <= i) {
      curHigh = highs[nextHigh];
      nextHigh++;
    }
    while (nextLow < lows.length && lows[nextLow].idx + SWING_RIGHT <= i) {
      curLow = lows[nextLow];
      nextLow++;
    }

    const fvg = createFvgZone(cs, i, at);
    if (fvg) {
      fvg.id = zoneId++;
      zones.push(fvg);
      if (fvg.strength >= 1.2) {
        markers.push({ t: cur.t, dir: fvg.dir, kind: 'FVG', text: 'FVG' });
      }
    }

    invalidateZones(zones, cur, i);
    sweeps = sweeps.filter((s) => !s.used && i - s.idx <= SWEEP_LOOKBACK);

    let sweepNow: SweepEvent | null = null;
    if (curLow && cur.l < curLow.price && cur.c > curLow.price && isBullish(cur)) {
      sweepNow = { dir: 'long', idx: i, t: cur.t, price: cur.l, used: false };
      sweeps.push(sweepNow);
      markers.push({ t: cur.t, dir: 'long', kind: 'SWEEP', text: 'Sweep' });
    } else if (curHigh && cur.h > curHigh.price && cur.c < curHigh.price && isBearish(cur)) {
      sweepNow = { dir: 'short', idx: i, t: cur.t, price: cur.h, used: false };
      sweeps.push(sweepNow);
      markers.push({ t: cur.t, dir: 'short', kind: 'SWEEP', text: 'Sweep' });
    }

    let structureNow: SmartStructure | null = null;
    const candleDir: Dir = isBullish(cur) ? 'long' : 'short';
    if (candleDir === 'long' && curHigh && cur.c > curHigh.price && (i === 0 || cs[i - 1].c <= curHigh.price)) {
      const kind = trend === 'short' ? 'CHoCH' : 'BOS';
      structureNow = { idx: i, t: cur.t, dir: 'long', kind, price: curHigh.price };
      structures.push(structureNow);
      trend = 'long';
      markers.push({ t: cur.t, dir: 'long', kind, text: kind });
      curHigh = null;
    } else if (candleDir === 'short' && curLow && cur.c < curLow.price && (i === 0 || cs[i - 1].c >= curLow.price)) {
      const kind = trend === 'long' ? 'CHoCH' : 'BOS';
      structureNow = { idx: i, t: cur.t, dir: 'short', kind, price: curLow.price };
      structures.push(structureNow);
      trend = 'short';
      markers.push({ t: cur.t, dir: 'short', kind, text: kind });
      curLow = null;
    }

    let ob: SmartZone | null = null;
    if (structureNow) {
      ob = createOrderBlock(cs, i, structureNow.dir, at);
      if (ob) {
        ob.id = zoneId++;
        zones.push(ob);
        markers.push({ t: cur.t, dir: ob.dir, kind: 'OB', text: 'OB' });
      }

      const matchedSweep = sweeps.find((s) => s.dir === structureNow.dir && i - s.idx <= SWEEP_LOOKBACK);
      if (matchedSweep && i - lastSignalIdx > 3) {
        const sig = makeSignal(cs, i, structureNow.dir, 'Sweep + CHoCH', ob, matchedSweep, structures, highs, lows, at);
        if (sig) {
          signals[i] = sig;
          matchedSweep.used = true;
          lastSignalIdx = i;
        }
      }
    }

    if (signals[i] || i - lastSignalIdx <= 3) continue;

    let bestZone: SmartZone | null = null;
    let bestStrength = -Infinity;
    for (const z of zones) {
      if (!z.active || z.used || z.dir !== (trend ?? z.dir)) continue;
      if (!zoneTouch(z, cur) || !zoneRejected(z, cs, i)) continue;
      const structural = lastStructure(structures, i, z.dir);
      if (!structural) continue;
      const strength = z.strength + (z.kind === 'OB' ? 0.35 : 0) - Math.abs(i - z.created) / 180;
      if (strength > bestStrength) {
        bestStrength = strength;
        bestZone = z;
      }
    }
    if (bestZone) {
      const setup = bestZone.kind === 'OB' ? 'RTM Order Block' : 'SMC FVG Retest';
      const sig = makeSignal(cs, i, bestZone.dir, setup, bestZone, null, structures, highs, lows, at);
      if (sig) {
        signals[i] = sig;
        bestZone.used = true;
        lastSignalIdx = i;
        markers.push({ t: cur.t, dir: bestZone.dir, kind: bestZone.kind, text: bestZone.kind });
      }
    }
  }

  const lastR = recentRange(cs, n - 1, Math.min(120, n));
  return {
    signals,
    markers,
    zones: zones.filter((z) => z.active && !z.used).slice(-14).reverse(),
    structures: structures.slice(-14).reverse(),
    trend,
    premiumRatio: lastR.ratio,
    rangeHigh: lastR.high,
    rangeLow: lastR.low,
  };
}

export function scanRtmSmc(cs: Candle[]): (Signal | null)[] {
  return analyzeSmartMoney(cs).signals;
}

export function evalRtmSmc(cs: Candle[]): Signal {
  const a = analyzeSmartMoney(cs);
  const last = a.signals[a.signals.length - 1];
  if (last) return last;
  if (cs.length === 0) {
    return {
      dir: null,
      entry: null,
      sl: null,
      tp: null,
      score: 0,
      reasons: [
        { label: 'در انتظار بارگذاری داده‌های بازار', ok: false },
        { label: 'پس از آماده‌شدن داده، ساختار و زون‌های اسمارت مانی بررسی می‌شوند', ok: false },
      ],
      time: Date.now(),
      atr: 0,
      note: 'داده هنوز بارگذاری نشده است؛ لطفاً چند لحظه صبر کنید.',
    };
  }
  const i = cs.length - 1;
  const cur = cs[i];
  const at = atr(cs, 14);
  const rr = recentRange(cs, i, Math.min(120, cs.length));
  const session = sessionLabel(cur.t);
  const zone = a.zones[0];
  const structure = a.structures[0];
  return {
    dir: null,
    entry: null,
    sl: null,
    tp: null,
    score: 0,
    reasons: [
      { label: structure ? `آخرین ساختار: ${structure.kind} ${structure.dir === 'long' ? 'صعودی' : 'نزولی'}` : 'ساختار واضح هنوز شکل نگرفته', ok: !!structure },
      { label: zone ? `نزدیک‌ترین زون: ${zone.kind} ${zone.dir === 'long' ? 'تقاضا' : 'عرضه'}` : 'زون فعال نزدیک قیمت نیست', ok: !!zone },
      { label: `موقعیت فعلی ${a.trend === 'long' ? 'با روند صعودی' : a.trend === 'short' ? 'با روند نزولی' : 'خنثی'} و ${cur.c <= rr.mid ? 'در بخش پایین محدوده' : 'در بخش بالای محدوده'}`, ok: cur.c <= rr.mid },
      { label: `جلسه ${session.label}${session.highProb ? ' — برای تعقیب نقدینگی مناسب‌تر' : ''}`, ok: session.highProb },
      { label: 'در انتظار سوییپ نقدینگی یا ریتست تأییدشده زون', ok: false },
    ],
    time: cur.t,
    atr: Number.isNaN(at[i]) ? 0 : at[i],
    note: 'هنوز ستاپ کامل RTM/SMC نیست؛ ورود زودهنگام فیلتر شده است.',
  };
}
