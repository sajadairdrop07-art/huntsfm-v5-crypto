import type { Candle, Dir, Signal, StrategyKind, VolEvent } from '@/types';
import { atr, bollinger, closes, ema, highest, lowest, macd, ranges, rsi, sma } from './indicators';
import { evalRtmSmc, scanRtmSmc } from './smartMoney';

/**
 * Each strategy exposes `scan(candles)` -> (Signal|null)[] aligned by index.
 * A signal at index i means: detected on the CLOSE of candle i, executable at open of i+1.
 * Levels are computed from data up to and including candle i only (no lookahead).
 */

export const STRATEGY_META: Record<
  StrategyKind,
  { label: string; desc: string; intervals: string[] }
> = {
  rtmSmc: {
    label: 'RTM / SMC',
    desc: 'خواندن ساختار بازار، شکار نقدینگی و ریتست Order Block / FVG در زون‌های اسمارت مانی',
    intervals: ['1m', '5m', '15m', '1h', '4h'],
  },
  scalp: {
    label: 'اسکالپ',
    desc: 'پولبک از EMA در جهت روند کوتاه‌مدت + تأیید حجم و RSI — تایم‌فریم ۱ تا ۱۵ دقیقه',
    intervals: ['1m', '5m', '15m'],
  },
  swing: {
    label: 'سویینگ',
    desc: 'معامله پولبک در روند میان‌مدت با تأیید مومنتوم MACD و RSI — تایم‌فریم ۱ ساعت تا روزانه',
    intervals: ['1h', '4h', '1d'],
  },
  news: {
    label: 'اخبار',
    desc: 'تشخیص شوک نوسان و برنامه‌ریزی معامله رویداد با سطوح شکست — روی هر تایم‌فریم',
    intervals: ['1m', '5m', '15m', '1h', '4h'],
  },
};

export const ACTIVE_STRATEGIES: StrategyKind[] = ['rtmSmc'];

const WARM = 60;

function baseSignal(cs: Candle[], i: number): Pick<Signal, 'time' | 'atr'> {
  const a = atr(cs.slice(Math.max(0, i - 80), i + 1), 14);
  return { time: cs[i].t, atr: a[a.length - 1] };
}

// ---------------------------------------------------------------- scalp
export function scanScalp(cs: Candle[]): (Signal | null)[] {
  const n = cs.length;
  const out: (Signal | null)[] = new Array(n).fill(null);
  if (n < WARM) return out;
  const cl = closes(cs);
  const e9 = ema(cl, 9);
  const e21 = ema(cl, 21);
  const r = rsi(cl, 14);
  const vAvg = sma(cs.map((c) => c.v), 20);
  const at = atr(cs, 14);

  for (let i = WARM; i < n; i++) {
    if ([e9[i], e21[i], r[i], vAvg[i], at[i]].some(Number.isNaN)) continue;
    const prev = cs[i - 1];
    const cur = cs[i];
    const volSpike = cur.v > 1.35 * vAvg[i];
    const a = at[i];

    // long: uptrend, pullback below EMA9 on previous candle, reclaim with bullish close
    const longTrend = e9[i] > e21[i];
    const longPullback = prev.l < e9[i - 1] || prev.c < e9[i - 1];
    const longReclaim = cur.c > e9[i] && cur.c > cur.o;
    const longRsi = r[i] >= 48 && r[i] <= 72;
    const longOk = longTrend && longPullback && longReclaim && longRsi && volSpike;

    // short mirror
    const shortTrend = e9[i] < e21[i];
    const shortPullback = prev.h > e9[i - 1] || prev.c > e9[i - 1];
    const shortReclaim = cur.c < e9[i] && cur.c < cur.o;
    const shortRsi = r[i] <= 52 && r[i] >= 28;
    const shortOk = shortTrend && shortPullback && shortReclaim && shortRsi && volSpike;

    if (!longOk && !shortOk) continue;
    const dir: Dir = longOk ? 'long' : 'short';
    const reasons = [
      { label: dir === 'long' ? 'روند کوتاه‌مدت صعودی (EMA9>EMA21)' : 'روند کوتاه‌مدت نزولی (EMA9<EMA21)', ok: dir === 'long' ? longTrend : shortTrend },
      { label: 'پولبک به EMA9 و برگشت قیمت', ok: dir === 'long' ? longPullback && longReclaim : shortPullback && shortReclaim },
      { label: `RSI تأییدکننده (${r[i].toFixed(0)})`, ok: dir === 'long' ? longRsi : shortRsi },
      { label: `جهش حجم (${(cur.v / vAvg[i]).toFixed(1)}× میانگین)`, ok: volSpike },
    ];
    const swing = dir === 'long' ? lowest(cs, 4, i) : highest(cs, 4, i);
    const entry = cur.c;
    const sl = dir === 'long' ? swing - 0.25 * a : swing + 0.25 * a;
    const risk = Math.abs(entry - sl);
    if (risk / entry < 0.0002) continue;
    const tp = dir === 'long' ? entry + 1.5 * risk : entry - 1.5 * risk;
    const okCount = reasons.filter((x) => x.ok).length;
    out[i] = {
      dir,
      entry,
      sl,
      tp,
      score: Math.round((okCount / reasons.length) * 100),
      reasons,
      ...baseSignal(cs, i),
    };
  }
  return out;
}

// ---------------------------------------------------------------- swing
export function scanSwing(cs: Candle[]): (Signal | null)[] {
  const n = cs.length;
  const out: (Signal | null)[] = new Array(n).fill(null);
  if (n < 210) return out;
  const cl = closes(cs);
  const e20 = ema(cl, 20);
  const e50 = ema(cl, 50);
  const e200 = ema(cl, 200);
  const m = macd(cl);
  const r = rsi(cl, 14);
  const at = atr(cs, 14);

  for (let i = 210; i < n; i++) {
    if ([e20[i], e50[i], e200[i], r[i], at[i]].some(Number.isNaN)) continue;
    const cur = cs[i];
    const a = at[i];
    const histRising = m.hist[i] > m.hist[i - 1] && m.hist[i - 1] > m.hist[i - 2];
    const histFalling = m.hist[i] < m.hist[i - 1] && m.hist[i - 1] < m.hist[i - 2];

    // long: bull regime (price above EMA200, EMA50 rising), pullback touched EMA20, momentum back up
    const bullRegime = e50[i] > e200[i] && cur.c > e200[i];
    const pulledBackLong = cs[i - 1].l <= e20[i - 1] || cur.l <= e20[i];
    const reclaimLong = cur.c > e20[i] && histRising;
    const rsiLong = r[i] > 48;
    const longOk = bullRegime && pulledBackLong && reclaimLong && rsiLong;

    const bearRegime = e50[i] < e200[i] && cur.c < e200[i];
    const pulledBackShort = cs[i - 1].h >= e20[i - 1] || cur.h >= e20[i];
    const reclaimShort = cur.c < e20[i] && histFalling;
    const rsiShort = r[i] < 52;
    const shortOk = bearRegime && pulledBackShort && reclaimShort && rsiShort;

    if (!longOk && !shortOk) continue;
    const dir: Dir = longOk ? 'long' : 'short';
    const swing = dir === 'long' ? lowest(cs, 10, i) : highest(cs, 10, i);
    const entry = cur.c;
    const sl = dir === 'long' ? Math.min(swing, entry - 1.6 * a) : Math.max(swing, entry + 1.6 * a);
    const risk = Math.abs(entry - sl);
    if (risk / entry < 0.002) continue;
    const tp = dir === 'long' ? entry + 2.5 * risk : entry - 2.5 * risk;
    const reasons = [
      { label: dir === 'long' ? 'رژیم صعودی (EMA50>EMA200)' : 'رژیم نزولی (EMA50<EMA200)', ok: dir === 'long' ? bullRegime : bearRegime },
      { label: 'پولبک به EMA20', ok: dir === 'long' ? pulledBackLong : pulledBackShort },
      { label: 'مومنتوم MACD در جهت معامله', ok: dir === 'long' ? reclaimLong : reclaimShort },
      { label: `RSI (${r[i].toFixed(0)})`, ok: dir === 'long' ? rsiLong : rsiShort },
    ];
    out[i] = {
      dir,
      entry,
      sl,
      tp,
      score: Math.round((reasons.filter((x) => x.ok).length / reasons.length) * 100),
      reasons,
      ...baseSignal(cs, i),
    };
  }
  return out;
}

// ---------------------------------------------------------------- news
/** Detect candles that ARE the news candle: huge range + volume explosion. */
export function detectVolEvents(cs: Candle[], rangeMult = 2.0, volMult = 2.5): VolEvent[] {
  const n = cs.length;
  const events: VolEvent[] = [];
  if (n < 60) return events;
  const at = atr(cs, 14);
  const vAvg = sma(cs.map((c) => c.v), 20);
  for (let i = 20; i < n; i++) {
    if (Number.isNaN(at[i]) || Number.isNaN(vAvg[i]) || vAvg[i] === 0) continue;
    const rangeX = (cs[i].h - cs[i].l) / at[i];
    const volX = cs[i].v / vAvg[i];
    if (rangeX >= rangeMult && volX >= volMult) {
      events.push({
        t: cs[i].t,
        rangeX,
        volX,
        dir: cs[i].c >= cs[i].o ? 'long' : 'short',
        price: cs[i].c,
      });
    }
  }
  return events;
}

/**
 * News trading scan: two setups —
 *  1) fresh spike candle (the "news candle") -> momentum entry with SL beyond its midpoint,
 *  2) post-spike retest: price returns to the body of the most recent spike candle and holds.
 */
export function scanNews(cs: Candle[]): (Signal | null)[] {
  const n = cs.length;
  const out: (Signal | null)[] = new Array(n).fill(null);
  if (n < 60) return out;
  const at = atr(cs, 14);
  const vAvg = sma(cs.map((c) => c.v), 20);

  const events = detectVolEvents(cs);
  let evIdx = 0;

  for (let i = 60; i < n; i++) {
    if (Number.isNaN(at[i]) || Number.isNaN(vAvg[i])) continue;
    const cur = cs[i];
    const a = at[i];

    // advance event pointer to latest event strictly before i
    while (evIdx < events.length && events[evIdx].t < cs[i].t) evIdx++;
    const lastEvent = evIdx > 0 ? events[evIdx - 1] : null;
    const lastEventIdx = lastEvent ? cs.findIndex((c) => c.t === lastEvent.t) : -1;

    let dir: Dir | null = null;
    let note: string | undefined;
    let slBase: number | null = null;
    let reasons: Signal['reasons'] = [];

    // setup 1: current candle is itself a spike
    const rangeX = (cur.h - cur.l) / a;
    const volX = cur.v / vAvg[i];
    const isSpike = rangeX >= 2.0 && volX >= 2.5;
    if (isSpike) {
      dir = cur.c >= cur.o ? 'long' : 'short';
      const mid = (cur.h + cur.l) / 2;
      slBase = dir === 'long' ? mid : mid;
      note = 'کندل شوک خبری — ورود مومنتومی با حد ضرر میان‌کندل';
      reasons = [
        { label: `دامنه ${rangeX.toFixed(1)}× ATR`, ok: true },
        { label: `حجم ${volX.toFixed(1)}× میانگین`, ok: true },
        { label: 'جهت شوک با بدنه کندل هم‌جهت است', ok: true },
      ];
    } else if (lastEvent && lastEventIdx >= 0 && i - lastEventIdx <= 12) {
      // setup 2: retest of the spike candle body
      const ev = cs[lastEventIdx];
      const bodyTop = Math.max(ev.o, ev.c);
      const bodyBottom = Math.min(ev.o, ev.c);
      const evDir = ev.c >= ev.o ? 'long' : 'short';
      if (evDir === 'long' && cur.l <= bodyTop && cur.c > bodyTop && cur.c > cur.o) {
        dir = 'long';
        slBase = bodyBottom - 0.3 * a;
        note = 'ریتست موفق بدنه کندل خبری صعودی';
        reasons = [
          { label: 'برگشت قیمت به بدنه شوک', ok: true },
          { label: 'تأیید با کندل صعودی', ok: true },
          { label: `حجم جاری ${volX.toFixed(1)}× میانگین`, ok: cur.v > vAvg[i] },
        ];
      } else if (evDir === 'short' && cur.h >= bodyBottom && cur.c < bodyBottom && cur.c < cur.o) {
        dir = 'short';
        slBase = bodyTop + 0.3 * a;
        note = 'ریتست موفق بدنه کندل خبری نزولی';
        reasons = [
          { label: 'برگشت قیمت به بدنه شوک', ok: true },
          { label: 'تأیید با کندل نزولی', ok: true },
          { label: `حجم جاری ${volX.toFixed(1)}× میانگین`, ok: cur.v > vAvg[i] },
        ];
      }
    }

    if (!dir || slBase === null) continue;
    const entry = cur.c;
    const risk = Math.abs(entry - slBase);
    if (risk / entry < 0.0003) continue;
    const tp = dir === 'long' ? entry + 1.6 * risk : entry - 1.6 * risk;
    out[i] = {
      dir,
      entry,
      sl: slBase,
      tp,
      score: Math.round((reasons.filter((x) => x.ok).length / reasons.length) * 100),
      reasons,
      note,
      ...baseSignal(cs, i),
    };
  }
  return out;
}

// ---------------------------------------------------------------- registry
export function scanStrategy(kind: StrategyKind, cs: Candle[]): (Signal | null)[] {
  switch (kind) {
    case 'rtmSmc':
      return scanRtmSmc(cs);
    case 'scalp':
      return scanScalp(cs);
    case 'swing':
      return scanSwing(cs);
    case 'news':
      return scanNews(cs);
  }
}

export function evalNow(kind: StrategyKind, cs: Candle[]): Signal {
  if (cs.length < 2) {
    return {
      dir: null,
      entry: null,
      sl: null,
      tp: null,
      score: 0,
      reasons: [{ label: 'در انتظار دریافت داده…', ok: false }],
      time: Date.now(),
      atr: 0,
    };
  }
  const scanned = scanStrategy(kind, cs);
  const last = scanned[scanned.length - 1];
  if (last) return last;
  if (kind === 'rtmSmc') return evalRtmSmc(cs);
  const i = cs.length - 1;
  const cl = closes(cs);
  const a = atr(cs, 14);
  const reasons: Signal['reasons'] = [];
  if (kind === 'scalp') {
    const e9 = ema(cl, 9);
    const e21 = ema(cl, 21);
    const r = rsi(cl, 14);
    reasons.push(
      { label: e9[i] > e21[i] ? 'روند کوتاه‌مدت صعودی است' : 'روند کوتاه‌مدت نزولی است', ok: true },
      { label: 'پولبک و برگشت از EMA9 هنوز رخ نداده', ok: false },
      { label: `RSI فعلی ${Number.isNaN(r[i]) ? '—' : r[i].toFixed(0)}`, ok: !Number.isNaN(r[i]) && r[i] > 48 && r[i] < 72 }
    );
  } else if (kind === 'swing') {
    const e50 = ema(cl, 50);
    const e200 = ema(cl, 200);
    reasons.push(
      { label: e50[i] > e200[i] ? 'رژیم میان‌مدت صعودی است' : 'رژیم میان‌مدت نزولی است', ok: true },
      { label: 'پولبک به EMA20 و تأیید مومنتوم هنوز رخ نداده', ok: false }
    );
  } else {
    const vAvg = sma(cs.map((c) => c.v), 20);
    const volX = Number.isNaN(vAvg[i]) ? 0 : cs[i].v / vAvg[i];
    reasons.push(
      { label: 'در انتظار شوک نوسان یا ریتست کندل خبری', ok: false },
      { label: `حجم فعلی ${volX.toFixed(1)}× میانگین`, ok: volX > 1.5 }
    );
  }
  return {
    dir: null,
    entry: null,
    sl: null,
    tp: null,
    score: 0,
    reasons,
    time: cs[i].t,
    atr: Number.isNaN(a[i]) ? 0 : a[i],
  };
}

export { bollinger, ranges };
