import type { BacktestResult, Candle, StrategyKind, Trade } from '@/types';
import { scanStrategy } from './strategies';

export interface BacktestOptions {
  feePct?: number; // fee per side on notional in %, e.g. 0.05 => 0.05% in + 0.05% out
  maxBars?: number; // time-based exit
  riskReward?: number; // override TP distance in R
}

/**
 * Walk-forward backtest: signal on close of candle i -> enter at open of i+1.
 * Intra-candle SL/TP resolution is conservative: if both are hit inside one candle, SL wins.
 */
export function runBacktest(
  kind: StrategyKind,
  candles: Candle[],
  opts: BacktestOptions = {}
): BacktestResult {
  const feePct = (opts.feePct ?? 0.05) / 100;
  const maxBars = opts.maxBars ?? (kind === 'scalp' ? 40 : kind === 'swing' ? 90 : kind === 'rtmSmc' ? 72 : 30);
  const rr = opts.riskReward;

  const signals = scanStrategy(kind, candles);
  const trades: Trade[] = [];
  const equity: { t: number; r: number }[] = [];
  let cumR = 0;
  let peak = 0;
  let maxDD = 0;
  let i = 0;
  const n = candles.length;

  while (i < n - 2) {
    const sig = signals[i];
    if (!sig || !sig.dir || sig.entry == null || sig.sl == null) {
      i++;
      continue;
    }
    const entry = candles[i + 1].o;
    const dir = sig.dir;
    const sl = sig.sl;
    let tp = sig.tp ?? entry;
    if (rr) {
      const risk = Math.abs(entry - sl);
      tp = dir === 'long' ? entry + rr * risk : entry - rr * risk;
    }
    // skip if already past SL at entry
    if (dir === 'long' ? entry <= sl : entry >= sl) {
      i++;
      continue;
    }

    let exit = 0;
    let exitReason: Trade['exitReason'] = 'time';
    let exitIdx = n - 1;
    const from = i + 1;
    const to = Math.min(n - 1, i + 1 + maxBars);
    for (let j = from; j <= to; j++) {
      const c = candles[j];
      if (dir === 'long') {
        if (c.l <= sl) {
          exit = sl;
          exitReason = 'sl';
          exitIdx = j;
          break;
        }
        if (c.h >= tp) {
          exit = tp;
          exitReason = 'tp';
          exitIdx = j;
          break;
        }
      } else {
        if (c.h >= sl) {
          exit = sl;
          exitReason = 'sl';
          exitIdx = j;
          break;
        }
        if (c.l <= tp) {
          exit = tp;
          exitReason = 'tp';
          exitIdx = j;
          break;
        }
      }
      exit = c.c;
      exitIdx = j;
    }

    const grossPct = dir === 'long' ? (exit - entry) / entry : (entry - exit) / entry;
    const pnlPct = grossPct - 2 * feePct;
    const riskDist = Math.abs(entry - sl);
    const grossR = riskDist > 0 ? (grossPct * entry) / riskDist : 0;
    const resultR = grossR - (2 * feePct * entry) / riskDist;
    cumR += resultR;
    peak = Math.max(peak, cumR);
    maxDD = Math.max(maxDD, peak - cumR);
    trades.push({
      dir,
      entryTime: candles[i + 1].t,
      exitTime: candles[exitIdx].t,
      entry,
      exit,
      sl,
      tp,
      resultR,
      pnlPct,
      exitReason,
    });
    equity.push({ t: candles[exitIdx].t, r: cumR });
    i = Math.max(exitIdx + 1, i + 2);
  }

  const wins = trades.filter((t) => t.resultR > 0);
  const grossWin = wins.reduce((s, t) => s + t.resultR, 0);
  const grossLoss = Math.abs(trades.filter((t) => t.resultR <= 0).reduce((s, t) => s + t.resultR, 0));
  return {
    trades,
    total: trades.length,
    wins: wins.length,
    winRate: trades.length ? (wins.length / trades.length) * 100 : 0,
    profitFactor: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : 0,
    netR: cumR,
    avgR: trades.length ? cumR / trades.length : 0,
    maxDrawdownR: maxDD,
    equity,
  };
}
