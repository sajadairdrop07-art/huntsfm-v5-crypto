/** Seconds until the candle that opened at `openMs` closes (null = nothing sensible to show). */
export function secondsToClose(openMs: number, intervalMs: number, nowMs: number, graceMs = 60_000): number | null {
  const end = openMs + intervalMs;
  if (nowMs < end) return Math.min(Math.ceil((end - nowMs) / 1000), Math.ceil(intervalMs / 1000));
  // the next candle has not reached us yet (poll delay): keep counting along the same candle grid.
  // Beyond the grace window the market is closed or the feed is down -> hide the timer.
  if (nowMs - end < Math.min(graceMs, intervalMs)) return Math.ceil((end + intervalMs - nowMs) / 1000);
  return null;
}

export function fmtCountdown(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const p = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p(m)}:${p(s % 60)}` : `${p(m)}:${p(s % 60)}`;
}
