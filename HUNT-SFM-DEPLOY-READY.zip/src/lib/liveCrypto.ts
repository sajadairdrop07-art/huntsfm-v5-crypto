import type { Candle, Coin, TickerInfo } from '@/types';

/**
 * Client of the live crypto hub (server/crypto.mjs, served by `npm run dev` and `npm start`).
 * The browser never talks to an exchange: it uses REST for history and Server-Sent Events for the real-time feed.
 * Set VITE_LIVE_API to use another deployment of the same API (e.g. https://api.example.com/api/live).
 */
const BASE: string = (import.meta.env?.VITE_LIVE_API as string | undefined) ?? '/api/live';

export const INTERVALS = ['1m', '5m', '15m', '1h', '4h', '1d'] as const;

export const INTERVAL_MS: Record<string, number> = {
  '1m': 60_000,
  '5m': 300_000,
  '15m': 900_000,
  '1h': 3_600_000,
  '4h': 14_400_000,
  '1d': 86_400_000,
};

export type Transport = 'ws' | 'rest';

export interface LiveResult {
  candles: Candle[];
  price: number | null;
  /** exchange that delivered the history (binance / bybit / okx / gate.io) */
  source: string;
  /** server is serving cached data because every exchange failed */
  stale: boolean;
  transport: Transport;
  quoteTime: number | null;
}

type Row = [number, number, number, number, number, number];

async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const res = await fetch(`${BASE}${path}`, { signal, cache: 'no-store' });
  if (!res.ok) {
    let msg = `live ${res.status}`;
    try {
      const body = (await res.json()) as { error?: string };
      if (body?.error) msg += `: ${body.error}`;
    } catch {
      /* non-JSON error body */
    }
    throw new Error(msg);
  }
  return (await res.json()) as T;
}

/**
 * Candles of one coin. Without `sinceT` a full history window (1000 bars) is returned;
 * with it only the bars from about that time on, so a gap after a hidden tab is always back-filled.
 */
export async function fetchCandles(symbol: string, interval: string, signal: AbortSignal, sinceT?: number): Promise<LiveResult> {
  const qs = new URLSearchParams({ symbol, interval });
  if (sinceT != null) qs.set('since', String(Math.floor(sinceT)));
  const j = await getJson<{ candles: Row[]; price: number | null; quoteTime: number | null; source: string; stale?: boolean; transport?: Transport }>(`/candles?${qs}`, signal);
  return {
    candles: j.candles.map(([t, o, h, l, c, v]) => ({ t, o, h, l, c, v })),
    price: j.price,
    quoteTime: j.quoteTime,
    source: j.source,
    stale: !!j.stale,
    transport: j.transport ?? 'rest',
  };
}

export async function fetchUniverse(signal: AbortSignal): Promise<{ coins: Coin[]; rankSource: string; updatedAt: number }> {
  return getJson('/universe', signal);
}

export interface TickerSnapshot {
  tickers: TickerInfo[];
  source: string | null;
  transport: Transport;
  t: number;
}

export async function fetchTickers(signal: AbortSignal): Promise<TickerSnapshot> {
  const j = await getJson<{ tickers: TickerInfo[]; source: string | null; transport?: Transport; t?: number }>('/tickers', signal);
  return { tickers: j.tickers, source: j.source, transport: j.transport ?? 'rest', t: j.t ?? Date.now() };
}

/* ------------------------------------------------------------------ real-time streams (SSE) */

export interface StreamHandle {
  close: () => void;
}

/** all tickers, about one update per second. `onState(true)` while the connection is open. */
export function openTickerStream(onData: (s: TickerSnapshot) => void, onState: (open: boolean) => void): StreamHandle {
  if (typeof EventSource === 'undefined') {
    onState(false);
    return { close() {} };
  }
  const es = new EventSource(`${BASE}/stream/tickers`);
  es.onopen = () => onState(true);
  es.onerror = () => onState(false); // EventSource reconnects by itself
  es.addEventListener('tickers', (ev) => {
    try {
      const j = JSON.parse((ev as MessageEvent<string>).data) as { tickers: [string, number, number, number, number, number][]; source: string | null; transport?: Transport; t?: number };
      onState(true);
      onData({
        tickers: j.tickers.map(([symbol, price, changePct, high, low, volume]) => ({ symbol, price, changePct, high, low, volume })),
        source: j.source,
        transport: j.transport ?? 'ws',
        t: j.t ?? Date.now(),
      });
    } catch {
      /* ignore a malformed frame */
    }
  });
  return { close: () => es.close() };
}

/** the forming candle of one chart, pushed by the server as soon as the exchange reports a trade */
export function openCandleStream(
  symbol: string,
  interval: string,
  onCandle: (c: Candle, closed: boolean, source: string) => void,
  onState: (open: boolean) => void,
): StreamHandle {
  if (typeof EventSource === 'undefined') {
    onState(false);
    return { close() {} };
  }
  const es = new EventSource(`${BASE}/stream/candles?${new URLSearchParams({ symbol, interval })}`);
  es.onopen = () => onState(true);
  es.onerror = () => onState(false);
  es.addEventListener('candle', (ev) => {
    try {
      const j = JSON.parse((ev as MessageEvent<string>).data) as { symbol: string; interval: string; source: string; closed: boolean; c: Row };
      if (j.symbol !== symbol || j.interval !== interval) return;
      const [t, o, h, l, c, v] = j.c;
      onState(true);
      onCandle({ t, o, h, l, c, v }, j.closed, j.source);
    } catch {
      /* ignore a malformed frame */
    }
  });
  return { close: () => es.close() };
}

/* ------------------------------------------------------------------ helpers */

/** merge by open time; `live` wins on overlap */
export function mergeCandles(base: Candle[], live: Candle[]): Candle[] {
  if (!live.length) return base;
  if (!base.length) return live;
  const map = new Map<number, Candle>();
  for (const c of base) map.set(c.t, c);
  for (const c of live) map.set(c.t, c);
  return [...map.values()].sort((a, b) => a.t - b.t);
}

/** apply one pushed candle: replace the last bar, append a newer one, ignore anything older than the tail */
export function applyCandle(list: Candle[], c: Candle): Candle[] {
  const last = list[list.length - 1];
  if (!last) return [c];
  if (c.t === last.t) return [...list.slice(0, -1), c];
  if (c.t > last.t) return [...list, c];
  // a late update for an earlier bar (rare): patch it in place
  const i = list.findIndex((x) => x.t === c.t);
  if (i < 0) return list;
  const out = list.slice();
  out[i] = c;
  return out;
}

export function sameTail(a: Candle[], b: Candle[]): boolean {
  if (a.length !== b.length || !a.length) return false;
  const x = a[a.length - 1];
  const y = b[b.length - 1];
  return x.t === y.t && x.o === y.o && x.h === y.h && x.l === y.l && x.c === y.c && x.v === y.v;
}
