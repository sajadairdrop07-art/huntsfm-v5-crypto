// Production server: serves ./dist and the live crypto-data API (/api/live/*).
//   cp .env.example .env      # optional: TOP_N, proxies, mirrors ... (no API key is needed)
//   npm run build && npm start        ->  http://localhost:8080
// Zero runtime dependencies (Node 22+: built-in fetch and WebSocket).
import http from 'node:http';
import { readFileSync } from 'node:fs';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { createCryptoApi } from './server/crypto.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(__dirname, 'dist');

function loadDotEnv(file) {
  const out = {};
  try {
    for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
      if (line.trim().startsWith('#')) continue;
      const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (m) out[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
    }
  } catch {
    /* no .env file: fine */
  }
  return out;
}

const env = { ...loadDotEnv(path.join(__dirname, '.env')), ...process.env };
const PORT = Number(env.PORT) || 8080;
const api = createCryptoApi(env, { cacheFile: env.UNIVERSE_CACHE || path.join(__dirname, '.cache', 'universe.json') });

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.css', '.json', '.svg', '.webmanifest', '.txt']);
const gzCache = new Map(); // file -> { mtimeMs, buf }

async function serveStatic(req, url, res) {
  let rel;
  try {
    rel = decodeURIComponent(url.pathname);
  } catch {
    res.writeHead(400);
    return res.end();
  }
  if (rel.endsWith('/')) rel += 'index.html';
  let file = path.normalize(path.join(DIST, rel));
  if (file !== DIST && !file.startsWith(DIST + path.sep)) {
    res.writeHead(403);
    return res.end();
  }
  let st;
  try {
    st = await stat(file);
    if (!st.isFile()) throw new Error('not file');
  } catch {
    file = path.join(DIST, 'index.html'); // SPA fallback
    try {
      st = await stat(file);
    } catch {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      return res.end('dist not found — run `npm run build` first');
    }
  }
  const ext = path.extname(file);
  const headers = {
    'content-type': MIME[ext] || 'application/octet-stream',
    // hashed assets never change; everything else (index.html, sw.js, manifest) must be revalidated
    'cache-control': rel.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache',
  };
  let data = await readFile(file);
  if (COMPRESSIBLE.has(ext) && /\bgzip\b/.test(String(req.headers['accept-encoding'] ?? ''))) {
    let hit = gzCache.get(file);
    if (!hit || hit.mtimeMs !== st.mtimeMs) {
      hit = { mtimeMs: st.mtimeMs, buf: zlib.gzipSync(data, { level: 9 }) };
      gzCache.set(file, hit);
    }
    data = hit.buf;
    headers['content-encoding'] = 'gzip';
    headers.vary = 'Accept-Encoding';
  }
  res.writeHead(200, headers);
  res.end(data);
}

const server = http.createServer(async (req, res) => {
  try {
    if (await api.handle(req, res)) return;
    await serveStatic(req, new URL(req.url, 'http://localhost'), res);
  } catch {
    if (!res.headersSent) res.writeHead(500);
    res.end();
  }
});
server.keepAliveTimeout = 65_000;

server.listen(PORT, () => {
  api.start();
  const s = api.status();
  console.log(`HUNT SFM live → http://localhost:${PORT}  (top ${env.TOP_N || 60} coins · ${s.provider})`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    api.close();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 1500).unref();
  });
}
