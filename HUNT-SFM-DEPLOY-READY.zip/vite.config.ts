import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig, loadEnv, type Plugin } from "vite"
import { VitePWA } from "vite-plugin-pwa"
import { inspectAttr } from 'kimi-plugin-inspect-react'
import { createCryptoApi } from './server/crypto.mjs'

// Serves /api/live/* (live crypto hub) in `vite` and `vite preview`. Free, no API key.
function liveApi(env: Record<string, string>): Plugin {
  const api = createCryptoApi(env)
  const mw = (req: Parameters<typeof api.handle>[0], res: Parameters<typeof api.handle>[1], next: (e?: unknown) => void) => {
    api.handle(req, res).then((done) => { if (!done) next() }).catch(next)
  }
  return {
    name: 'huntsfm-live-api',
    configureServer(server) { server.middlewares.use(mw) },
    configurePreviewServer(server) { server.middlewares.use(mw) },
  }
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = { ...loadEnv(mode, process.cwd(), ''), ...process.env } as Record<string, string>
  return {
  base: './',
  plugins: [
    liveApi(env),
    inspectAttr(),
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.png', 'icons/favicon-32.png'],
      manifest: {
        name: 'HUNT SFM — Smart Money · Liquidity · Structure',
        short_name: 'HUNT SFM',
        description: 'ترمینال تحلیل ارزهای دیجیتال RTM/SMC با داده زنده ۶۰ ارز برتر بازار: BOS/CHoCH، شکار نقدینگی، Order Block، FVG، مدیریت ریسک و بک‌تست.',
        lang: 'fa',
        dir: 'rtl',
        theme_color: '#0b1220',
        background_color: '#0b1220',
        display: 'standalone',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        navigateFallback: null,
        maximumFileSizeToCacheInBytes: 3_000_000,
      },
    }),
  ],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id: string) {
          if (!id.includes('node_modules')) return undefined
          if (id.includes('lightweight-charts') || id.includes('fancy-canvas')) return 'charts-lw'
          if (id.includes('recharts') || id.includes('d3-') || id.includes('victory-vendor')) return 'charts-recharts'
          if (id.includes('@radix-ui')) return 'radix'
          if (id.includes('react-dom') || id.includes('/react/') || id.includes('scheduler')) return 'react'
          return 'vendor'
        },
      },
    },
  },
  server: {
    port: 3000,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  }
});
