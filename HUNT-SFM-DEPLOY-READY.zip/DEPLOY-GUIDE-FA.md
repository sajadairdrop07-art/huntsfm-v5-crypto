# راهنمای ساده انتشار HUNT SFM

این پروژه دو بخش دارد:
- **Frontend**: روی Vercel منتشر می‌شود.
- **Backend زنده**: روی Railway اجرا می‌شود؛ چون سرور پروژه یک Node.js server دائمی و استریم زنده (SSE/WebSocket) دارد.

## ۱) ساخت Repository در GitHub
1. فایل `HUNT-SFM-DEPLOY-READY.zip` را از حالت فشرده خارج کنید.
2. یک Repository جدید در GitHub بسازید.
3. **محتویات داخل ZIP** را مستقیماً در ریشه Repository آپلود کنید؛ پوشه‌ی اضافه‌ای مثل `app/` نسازید.
4. فایل‌های `.env`، `node_modules/` و `dist/` را آپلود نکنید. فایل `.env.example` امن است و داخل پروژه قرار دارد.

## ۲) انتشار Backend روی Railway
1. در Railway یک پروژه جدید بسازید و گزینه Deploy from GitHub Repo را انتخاب کنید.
2. همان Repository را متصل کنید.
3. در تنظیمات سرویس، این مقادیر را بگذارید:
   - Root Directory: `/` یا خالی (ریشه Repository)
   - Build Command: `npm ci`
   - Start Command: `npm start`
4. نسخه Node را روی **22 یا بالاتر** قرار دهید.
5. Deploy کنید و دامنه عمومی سرویس را از Railway بسازید/کپی کنید.

> این پروژه برای داده‌های عمومی بازار به API Key نیاز ندارد. متغیرهای نمونه در `.env.example` اختیاری‌اند.

## ۳) انتشار Frontend روی Vercel
1. در Vercel گزینه Add New → Project را بزنید و همان GitHub Repository را Import کنید.
2. تنظیمات Build:
   - Framework Preset: `Vite`
   - Root Directory: `./`
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm ci`
3. در Environment Variables این متغیر را اضافه کنید:
   - Name: `VITE_LIVE_API`
   - Value: `https://YOUR-RAILWAY-DOMAIN/api/live`

   آدرس بالا را با دامنه واقعی Railway جایگزین کنید؛ انتهای `/api/live` را نگه دارید.
4. Deploy کنید. اگر متغیر محیطی را بعد از Deploy اضافه کردید، یک Redeploy انجام دهید.

## ۴) بررسی نهایی
- سایت Vercel را باز کنید و مطمئن شوید اطلاعات بازار بارگذاری می‌شود.
- Backend باید روی Railway در حال اجرا بماند؛ API و استریم زنده از آن سرو می‌شوند.
- در صورت تغییر کد، با Push به GitHub، هر دو سرویس می‌توانند دوباره Deploy شوند.

## نکته مهم
قرار دادن کل پروژه فقط روی Vercel کافی نیست؛ `server.mjs` سرور Node دائمی پروژه و API زنده را اجرا می‌کند. به همین دلیل این راهنما Frontend را روی Vercel و Backend را روی Railway قرار می‌دهد.
